/** Known secret values become `[REDACTED:NAME]`, longest first so a secret containing another is replaced whole. */
export declare function redactor(secrets: Readonly<Record<string, string>>): (text: string) => string;
/**
 * A copy of a JSON-shaped value with `redact` applied to every string and every object key. Anything else, a
 * non-plain object included, comes back as it is. A key that redacts to a name its object already holds takes the
 * next free `<name>_<n>`, so no value drops out.
 */
export declare function redactJson<T>(value: T, redact: (text: string) => string): T;
