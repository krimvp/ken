// The session plugin: one read-only tool that tells the model what the engine knows about its session. Like any
// plugin it imports only the plugin contract. The engine builds it with a SessionView, and this file turns views into
// text. The view never holds plugin state, tool arguments, tool results or secrets.
/** The tool's local name. The model sees `session__inspect`. */
export const INSPECT = 'inspect';
/** The `calls` lines without a `limit`. At the 1000-character denial reason cap, they stay near the default result cap. */
const CALLS_SHOWN = 50;
const topics = {
    config: (view) => {
        const c = view.config();
        return [
            `model: ${c.modelId}`,
            `provider: ${c.provider}`,
            `tool mode: ${c.toolMode}`,
            `max turns per prompt: ${c.maxTurns}`,
            `hook timeout: ${c.hookTimeoutMs} ms`,
            `context window: ${c.contextWindow} tokens`,
            `max output tokens: ${c.maxOutputTokens}`,
        ].join('\n');
    },
    calls: (view, args) => {
        const calls = view.calls();
        const shown = calls.slice(-(typeof args.limit === 'number' ? args.limit : CALLS_SHOWN));
        const left = calls.length - shown.length;
        const head = left > 0 ? `finished calls: ${calls.length}, newest ${shown.length} shown, ${left} older left out (pass a larger limit to see them)` : `finished calls: ${calls.length}`;
        return [head, ...shown.map((c) => `- ${c.name}: ${c.outcome === 'denied' ? `denied by ${c.denials.map((d) => `${d.plugin}: ${d.reason}`).join('; ')}` : c.outcome}`)].join('\n');
    },
    plugins: (view) => {
        const p = view.plugins();
        return [
            ...section('enabled', p.enabled.map((e) => `${e.name}: ${typeof e.cause === 'object' ? `dependency of ${e.cause.dependencyOf}` : e.cause}`)),
            ...section('catalog only', p.catalogOnly.map((c) => `${c.name}: ${c.description}`)),
            ...section('skills', p.skills.map((s) => `${s.name}: ${s.loaded ? 'loaded' : 'not loaded'}`)),
        ].join('\n');
    },
    budget: (view) => {
        const { requests, tokens, cachedRatio, context, turns, delegated } = view.budget();
        const ratio = (r) => (r === undefined ? 'none' : r.toFixed(2));
        return [
            `model requests: ${requests}`,
            `prompt tokens: ${tokens.prompt} (input ${tokens.input}, cache read ${tokens.cacheRead}, cache write ${tokens.cacheWrite})`,
            `output tokens: ${tokens.output}`,
            `cached ratio: ${ratio(cachedRatio.session)} this session, ${ratio(cachedRatio.last)} last request`,
            context
                ? `context used: ${context.used} of ${context.window} tokens, ${Math.max(0, context.window - context.used)} left, as of the last model request`
                : 'context used: unknown, no model request reported usage',
            `turns used: ${turns.used} of ${turns.max} in this prompt, ${Math.max(0, turns.max - turns.used)} left`,
            ...(delegated ? [`delegations: ${delegated.calls} (model requests ${delegated.requests}, prompt tokens ${delegated.tokens.prompt}, output tokens ${delegated.tokens.output})`] : []),
        ].join('\n');
    },
};
export function createSessionPlugin(view) {
    return {
        name: 'session',
        description: 'Facts about this session: its config, tool calls, plugins and budget.',
        instructions: 'Call session__inspect instead of guessing what happened earlier in this session or how much budget is left.',
        tools: [
            {
                name: INSPECT,
                description: `Read facts about this session. config: model, tool mode and limits. calls: finished tool calls, newest last, with each denial and its reason, the newest ${CALLS_SHOWN} unless you pass limit. plugins: enabled plugins and why, plugins you could enable, and skills loaded. budget: tokens, context used and left, cached ratio, and turns left in this prompt.`,
                parameters: {
                    type: 'object',
                    properties: {
                        topic: { type: 'string', enum: Object.keys(topics), description: 'Which facts to read.' },
                        limit: { type: 'integer', minimum: 1, description: `calls only: show the newest this many. Default ${CALLS_SHOWN}.` },
                    },
                    required: ['topic'],
                    additionalProperties: false,
                },
                async execute(args) {
                    const topic = String(args.topic);
                    if (!Object.hasOwn(topics, topic))
                        return { content: [{ type: 'text', text: `No topic "${topic}". Topics: ${Object.keys(topics).join(', ')}.` }], isError: true };
                    return { content: [{ type: 'text', text: topics[topic](view, args) }] };
                },
            },
        ],
    };
}
function section(title, items) {
    return items.length > 0 ? [`${title}:`, ...items.map((item) => `- ${item}`)] : [`${title}: none`];
}
