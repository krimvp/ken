import type { Catalog, PluginName } from './catalog.ts';
import type { JsonValue } from './plugin.ts';
import type { EngineRecord } from './session.ts';
import type { Usage } from './usage.ts';
type Of<K extends EngineRecord['kind']> = Extract<EngineRecord, {
    kind: K;
}>;
/** The latest or every record of each kind, as the log's records left it. */
export interface RecordIndex {
    readonly conversation: string | undefined;
    readonly run: Of<'run'> | undefined;
    readonly enabled: ReadonlyMap<PluginName, Of<'enabled'>>;
    readonly catalog: readonly Of<'catalog'>[];
    /** Pending texts since the last `delivered`. */
    readonly undelivered: readonly string[];
    readonly state: ReadonlyMap<PluginName, JsonValue>;
    readonly calls: readonly Of<'call'>[];
    /** By call id, in record order. */
    readonly denials: ReadonlyMap<string, readonly Of<'denied'>[]>;
    readonly usage: readonly Usage[];
    readonly skills: ReadonlySet<string>;
    readonly delegations: readonly Of<'delegation'>[];
}
export interface RecordLog {
    /** Live: reads always see every record so far. */
    readonly byKind: RecordIndex;
    /** Indexes `record` and hands it to the log's `onAppend`. */
    append(record: EngineRecord): void;
    /** Indexes a transcript's records without handing them on. They count as taken. */
    restore(records: readonly EngineRecord[]): void;
    /** Records appended since the last call, each plugin's state record but its last left out. */
    take(): readonly EngineRecord[];
}
export declare function createRecordLog(onAppend: (record: EngineRecord) => void): RecordLog;
/** Transcript boundary: a malformed or unknown record throws, because guessing would rebuild a different engine. */
export declare function parseRecord(value: unknown, catalog: Catalog, redact: (text: string) => string): EngineRecord;
/** A plugin's next state as it is stored: plain JSON with every string redacted, keys too, capped and deep-frozen. */
export declare function storableState(plugin: PluginName, value: unknown, redact: (text: string) => string): JsonValue;
export {};
