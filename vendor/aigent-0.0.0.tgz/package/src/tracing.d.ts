import { type Context, type Meter, type Span } from '@opentelemetry/api';
import type { EventTrace, LogRecord, Severity } from './session.ts';
import { type Usage } from './usage.ts';
export declare const tracer: import("@opentelemetry/api").Tracer;
declare function createInstruments(meter: Meter): {
    duration: import("@opentelemetry/api").Histogram<import("@opentelemetry/api").Attributes>;
    tokens: import("@opentelemetry/api").Histogram<import("@opentelemetry/api").Attributes>;
    toolCalls: import("@opentelemetry/api").Counter<import("@opentelemetry/api").Attributes>;
    denials: import("@opentelemetry/api").Counter<import("@opentelemetry/api").Attributes>;
    hookFailures: import("@opentelemetry/api").Counter<import("@opentelemetry/api").Attributes>;
};
/** The metrics API has no proxy provider, so instruments come from whichever provider is registered when one is first needed. */
export declare function instruments(): ReturnType<typeof createInstruments>;
declare const thrownBrand: unique symbol;
/** The class name of a thrown value. Only `thrownType` makes one, so a stray string never reaches `error.type`. */
type Thrown = string & {
    readonly [thrownBrand]: true;
};
/** Every `error.type` a span can carry. */
export type ErrorType = 'unknown_tool' | 'invalid_arguments' | 'malformed_result' | 'tool_error' | 'timeout' | 'model_error' | Thrown;
export declare function thrownType(error: unknown): Thrown;
/** Token counts as both the `chat` and the `delegate__run` spans report them. Input tokens include the cached ones. */
export declare function usageAttributes(usage: Usage): {
    'gen_ai.usage.input_tokens': number;
    'gen_ai.usage.output_tokens': number;
    'gen_ai.usage.cache_read.input_tokens': number;
    'gen_ai.usage.cache_creation.input_tokens': number;
};
/** A content attribute's value: JSON with every string and key redacted, then each string cut at CONTENT_CAP with the cut marked. */
export declare function captured(value: unknown, redact: (text: string) => string): string;
/**
 * The newest `messages` whose captured JSON fits HISTORY_CAP together, as one JSON array, and how many older ones it
 * left out. The newest is kept even alone, and CONTENT_CAP already bounds each of its strings.
 */
export declare function capturedHistory(messages: readonly unknown[], redact: (text: string) => string): {
    readonly json: string;
    readonly omitted: number;
};
/** The bytes a base64 string decodes to. Captured content names an image by its type and size, never its data. */
export declare function decodedBytes(base64: string): number;
/** On every span a session opens, so a backend finds a conversation's runs across traces, its helpers' included. */
export declare function conversationAttributes(id: string): {
    'gen_ai.conversation.id': string;
};
/** A span's ids for an event to spread in. Empty when no SDK records the span, so the event has no `trace`. */
export declare function traceOf(span?: Span | undefined): {
    readonly trace?: EventTrace;
};
/** A record correlated with `span`, the active one by default. The caller has redacted `body` and `attributes`. */
export declare function logRecord(severity: Severity, body: string, attributes?: LogRecord['attributes'], { eventName, span }?: {
    readonly eventName?: string;
    readonly span?: Span;
}): LogRecord;
/** The host's default `log`: one stderr line per record at INFO and above, greppable by trace. */
export declare function writeStderr(record: LogRecord): void;
/**
 * The active context joined with the OTel environment carriers `TRACEPARENT`, `TRACESTATE` and `BAGGAGE`, as the
 * global propagator reads them. Without a registered SDK the propagator reads nothing.
 */
export declare function envContext(): Context;
export declare function fail(span: Span, type: ErrorType, message?: string): void;
export {};
