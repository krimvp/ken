// The engine's record log: the append-only list of EngineRecords, the by-kind index derived from it, the transcript
// parser that rebuilds it on resume, and the checks a plugin's state passes before it is stored.
import { isValidSpanId, isValidTraceId } from '@opentelemetry/api';
import { redactJson } from "./redact.js";
export function createRecordLog(onAppend) {
    /** Appended and not yet taken. The transcript holds the rest, so only the indexes keep them here. */
    let untaken = [];
    const byKind = {
        conversation: undefined,
        run: undefined,
        enabled: new Map(),
        catalog: [],
        undelivered: [],
        state: new Map(),
        calls: [],
        denials: new Map(),
        usage: [],
        skills: new Set(),
        delegations: [],
    };
    const index = (record) => {
        switch (record.kind) {
            case 'conversation':
                byKind.conversation = record.id;
                return;
            case 'run':
                byKind.run = record;
                return;
            case 'enabled':
                byKind.enabled.set(record.plugin, record);
                return;
            case 'catalog':
                byKind.catalog.push(record);
                return;
            case 'pending':
                byKind.undelivered.push(record.text);
                return;
            case 'delivered':
                byKind.undelivered = [];
                return;
            case 'state':
                byKind.state.set(record.plugin, record.value);
                return;
            case 'denied':
                byKind.denials.set(record.callId, [...(byKind.denials.get(record.callId) ?? []), record]);
                return;
            case 'call':
                byKind.calls.push(record);
                return;
            case 'usage':
                byKind.usage.push(record);
                return;
            case 'skill':
                byKind.skills.add(record.name);
                return;
            case 'delegation':
                byKind.delegations.push(record);
                return;
            default:
                return record;
        }
    };
    return {
        byKind,
        append(record) {
            index(record);
            untaken.push(record);
            onAppend(record);
        },
        restore(resumed) {
            for (const record of resumed)
                index(record);
        },
        take() {
            const fresh = untaken;
            untaken = [];
            const last = new Map(fresh.flatMap((r, i) => (r.kind === 'state' ? [[r.plugin, i]] : [])));
            return fresh.filter((r, i) => r.kind !== 'state' || last.get(r.plugin) === i);
        },
    };
}
/** Transcript boundary: a malformed or unknown record throws, because guessing would rebuild a different engine. */
export function parseRecord(value, catalog, redact) {
    const fail = (why) => {
        throw new Error(`transcript record ${JSON.stringify(value)}: ${why}`);
    };
    if (typeof value !== 'object' || value === null)
        return fail('not an object');
    const r = value;
    if (typeof r.kind !== 'string' || !Object.hasOwn(recordParsers, r.kind))
        return fail('unknown kind');
    const plugin = (field) => (typeof field === 'string' && catalog.pluginName(field)) || fail(`plugin ${JSON.stringify(field)} is not in the plugin set`);
    const count = (key) => {
        const n = r[key];
        return typeof n === 'number' && Number.isFinite(n) && n >= 0 ? n : fail(`${key} must be a count`);
    };
    return recordParsers[r.kind](r, { fail, plugin, count, redact });
}
/** One parser per record kind. A kind without one fails the build. */
const recordParsers = {
    conversation: (r, { fail }) => (typeof r.id === 'string' && r.id !== '' ? { kind: 'conversation', id: r.id } : fail('missing id')),
    run: (r, { fail }) => {
        const { traceId, spanId, traceFlags } = r;
        if (typeof traceId !== 'string' || !isValidTraceId(traceId) || typeof spanId !== 'string' || !isValidSpanId(spanId))
            return fail('not a valid trace and span id');
        return Number.isInteger(traceFlags) && traceFlags >= 0 && traceFlags <= 255 ? { kind: 'run', traceId, spanId, traceFlags: traceFlags } : fail('traceFlags must be a byte');
    },
    enabled: (r, { fail, plugin }) => {
        const cause = r.cause;
        if (cause === 'initial' || cause === 'host' || cause === 'model')
            return { kind: 'enabled', plugin: plugin(r.plugin), cause };
        if (typeof cause === 'object' && cause !== null && 'dependencyOf' in cause) {
            return { kind: 'enabled', plugin: plugin(r.plugin), cause: { dependencyOf: plugin(cause.dependencyOf) } };
        }
        return fail('unknown cause');
    },
    denied: (r, { fail, plugin }) => {
        const { callId, tool, reason } = r;
        if (typeof callId !== 'string' || typeof tool !== 'string' || typeof reason !== 'string')
            return fail('missing callId, tool or reason');
        if (r.outer === undefined)
            return { kind: 'denied', callId, tool, plugin: plugin(r.plugin), reason };
        if (!Number.isInteger(r.outer) || r.outer < 1 || typeof r.plugin !== 'string')
            return fail('outer must be a level of 1 or more, with a plugin name');
        return { kind: 'denied', callId, tool, plugin: r.plugin, reason, outer: r.outer };
    },
    catalog: (r, { fail }) => (typeof r.fingerprint === 'string' ? { kind: 'catalog', fingerprint: r.fingerprint } : fail('missing fingerprint')),
    pending: (r, { fail }) => (typeof r.text === 'string' ? { kind: 'pending', text: r.text } : fail('missing text')),
    delivered: () => ({ kind: 'delivered' }),
    state: (r, { plugin, redact }) => {
        const name = plugin(r.plugin);
        try {
            return { kind: 'state', plugin: name, value: storableState(name, r.value, redact) };
        }
        catch (error) {
            // Not fail: the record it would quote holds the value just refused, which may be huge or carry a secret.
            throw new Error(`transcript state record: ${messageOf(error)}`);
        }
    },
    call: (r, { fail }) => {
        if (typeof r.callId !== 'string')
            return fail('missing callId');
        if (r.outcome === 'unresolved')
            return typeof r.requested === 'string' ? { kind: 'call', callId: r.callId, requested: r.requested, outcome: r.outcome } : fail('missing requested');
        if (r.outcome !== 'ran' && r.outcome !== 'error' && r.outcome !== 'denied')
            return fail('unknown outcome');
        return typeof r.tool === 'string' ? { kind: 'call', callId: r.callId, tool: r.tool, outcome: r.outcome } : fail('missing tool');
    },
    usage: (_, { count }) => ({ kind: 'usage', input: count('input'), output: count('output'), cacheRead: count('cacheRead'), cacheWrite: count('cacheWrite') }),
    skill: (r, { fail }) => (typeof r.name === 'string' ? { kind: 'skill', name: r.name } : fail('missing name')),
    delegation: (r, { fail, count }) => {
        if (typeof r.callId !== 'string' || typeof r.profile !== 'string')
            return fail('missing callId or profile');
        const outcome = r.outcome;
        if (outcome !== 'done' && outcome !== 'max_turns' && outcome !== 'aborted' && outcome !== 'error')
            return fail('unknown outcome');
        return {
            kind: 'delegation',
            callId: r.callId,
            profile: r.profile,
            outcome,
            turns: count('turns'),
            requests: count('requests'),
            input: count('input'),
            output: count('output'),
            cacheRead: count('cacheRead'),
            cacheWrite: count('cacheWrite'),
        };
    },
};
const STATE_CAP = 16 * 1024;
/** A plugin's next state as it is stored: plain JSON with every string redacted, keys too, capped and deep-frozen. */
export function storableState(plugin, value, redact) {
    if (typeof value?.then === 'function')
        throw new Error(`plugin "${plugin}" state.update must return a value, not a promise`);
    let state;
    try {
        state = frozenJson(redactJson(value, redact));
    }
    catch (error) {
        throw new Error(`plugin "${plugin}" state must be JSON: ${messageOf(error)}`);
    }
    const bytes = Buffer.byteLength(JSON.stringify(state));
    if (bytes > STATE_CAP)
        throw new Error(`plugin "${plugin}" state is ${bytes} bytes, over the ${STATE_CAP}-byte cap`);
    return state;
}
/** A deep-frozen copy of a JSON value. Anything else throws. */
function frozenJson(value, at = 'value') {
    if (value === null || typeof value === 'boolean' || typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value)))
        return value;
    if (Array.isArray(value))
        return Object.freeze(value.map((v, i) => frozenJson(v, `${at}[${i}]`)));
    const proto = typeof value === 'object' ? Object.getPrototypeOf(value) : undefined;
    if (proto === Object.prototype || proto === null) {
        return Object.freeze(Object.fromEntries(Object.entries(value).map(([k, v]) => [k, frozenJson(v, `${at}.${k}`)])));
    }
    const name = proto?.constructor?.name;
    const found = typeof value === 'number' ? String(value) : typeof value !== 'object' ? typeof value : name ? `a ${name} instance` : 'a non-plain object';
    throw new Error(`found ${found} at ${at}`);
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error);
}
