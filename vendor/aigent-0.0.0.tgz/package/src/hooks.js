// The hook runner: each plugin's hook under a timeout, concurrently across plugins and in its own span, with every
// failure logged and counted. Never rejects.
import { fail, instruments, thrownType, tracer } from "./tracing.js";
/** A failed gate denies the call, so it is an error. Any other failed hook is ignored, so it is a warning. */
const hookFailure = {
    onEnable: 'WARN',
    onUserPrompt: 'WARN',
    beforeToolCall: 'ERROR',
    onToolResult: 'WARN',
    onTurnEnd: 'WARN',
    onSessionEnd: 'WARN',
};
/**
 * Calls one hook under the timeout, never rejecting. The hook's signal is its lifetime: it fires on timeout, on any
 * of `extra`, or once the hook has settled, whichever comes first.
 */
export async function settle(call, timeoutMs, extra) {
    // A ref'd timer, unlike AbortSignal.timeout, so a hook that never settles still gets its verdict.
    const timeout = new AbortController();
    const timer = setTimeout(() => timeout.abort(new Error('timeout')), timeoutMs);
    const settled = new AbortController();
    const signal = AbortSignal.any([timeout.signal, settled.signal, ...extra]);
    let onAbort = () => { };
    try {
        const value = await new Promise((resolve, reject) => {
            onAbort = () => reject(signal.reason);
            if (signal.aborted)
                onAbort();
            signal.addEventListener('abort', onAbort, { once: true });
            Promise.resolve()
                .then(() => call(signal))
                .then(resolve, reject);
        });
        return { kind: 'ok', value };
    }
    catch (error) {
        if (timeout.signal.aborted)
            return { kind: 'failed', reason: `timed out after ${timeoutMs}ms`, type: 'timeout' };
        return extra.some((s) => s.aborted) ? { kind: 'aborted' } : { kind: 'failed', reason: messageOf(error), type: thrownType(error) };
    }
    finally {
        clearTimeout(timer);
        signal.removeEventListener('abort', onAbort);
        settled.abort(new Error('hook settled'));
    }
}
export function createHookRunner({ timeoutMs, contextFor, log, redact, spanAttributes, closing }) {
    return (plugins, hook, invoke, extra = [closing], level) => {
        const hooked = plugins.filter((p) => p.hooks?.[hook]);
        const attributes = { 'aigent.hook': hook, ...(level !== undefined && { 'aigent.hook.outer': level }) };
        return Promise.all(hooked.map((p) => tracer.startActiveSpan(`aigent.hook ${hook}`, { attributes: { 'aigent.plugin': p.name, ...attributes, ...spanAttributes } }, async (span) => {
            const attribution = { 'aigent.plugin': p.name, 'aigent.hook': hook };
            const settled = await settle((signal) => invoke(p.hooks, contextFor(p.name, signal, attribution)), timeoutMs, extra);
            if (settled.kind === 'failed') {
                fail(span, settled.type, redact(settled.reason));
                log(hookFailure[hook], `hook failed: ${settled.reason}`, attribution);
                instruments().hookFailures.add(1, { 'aigent.hook': hook, 'aigent.plugin': p.name, 'error.type': settled.type });
            }
            span.end();
            return { plugin: p.name, settled };
        })));
    };
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error);
}
