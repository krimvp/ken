// The only place plugin objects are validated. Everything downstream trusts a Catalog and its brands.
var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { createHash } from 'node:crypto';
import { readdir, realpath, stat } from 'node:fs/promises';
import { registerHooks } from 'node:module';
import { dirname, join, relative, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
export const CORE = 'core';
/** The engine-built plugin only the host can enable. */
export const SESSION = 'session';
/** The engine-built plugin only the host can enable, and only when it configured `delegate`. Reserved either way. */
export const DELEGATE = 'delegate';
const RESERVED = [CORE, SESSION, DELEGATE];
/** Unambiguous because plugin names cannot contain `_`. */
export function qualify(plugin, local) {
    return `${plugin}__${local}`;
}
export class CatalogError extends Error {
    problems;
    constructor(problems) {
        super(`invalid plugins:\n- ${problems.join('\n- ')}`);
        this.problems = problems;
    }
}
const PLUGIN_NAME = /^[a-z0-9-]+$/;
const TOOL_NAME = /^[A-Za-z0-9_-]+$/;
const SKILL_NAME = /^[a-z0-9_-]+$/;
// OpenAI-compatible endpoints reject longer function names.
const MAX_TOOL_NAME = 64;
const HOOKS = new Set(['onEnable', 'onUserPrompt', 'beforeToolCall', 'onToolResult', 'onTurnEnd', 'onSessionEnd']);
/**
 * `builtins` are plugins the engine builds under reserved names. They are trusted, so not parsed. Only the host can
 * enable them, so they are left out of `listed` and the fingerprint, and no host plugin may depend on one.
 */
export function parseCatalog(plugins, builtins = []) {
    const problems = [];
    const byName = new Map();
    for (const [index, value] of plugins.entries()) {
        const parsed = parsePlugin(value, `plugins[${index}]`);
        if (!parsed.ok) {
            problems.push(...parsed.problems);
            continue;
        }
        const name = parsed.plugin.name;
        if (byName.has(name))
            problems.push(`plugin "${name}" is defined twice`);
        else
            byName.set(name, parsed.plugin);
    }
    for (const [name, plugin] of byName) {
        for (const dep of plugin.dependsOn ?? []) {
            if (dep === name)
                problems.push(`plugin "${name}" depends on itself`);
            else if (!byName.has(dep))
                problems.push(`plugin "${name}" depends on unknown plugin "${dep}"`);
        }
    }
    if (problems.length > 0)
        throw new CatalogError(problems);
    const listed = [...byName.keys()].sort();
    for (const plugin of builtins)
        byName.set(plugin.name, plugin);
    const closures = new Map();
    const visiting = [];
    const visit = (name) => {
        const done = closures.get(name);
        if (done)
            return done;
        const cycleStart = visiting.indexOf(name);
        if (cycleStart !== -1)
            throw new CatalogError([`dependency cycle: ${[...visiting.slice(cycleStart), name].join(' -> ')}`]);
        visiting.push(name);
        const closure = [...new Set([...(byName.get(name).dependsOn ?? []).flatMap((dep) => visit(dep)), name])];
        visiting.pop();
        closures.set(name, closure);
        return closure;
    };
    const sorted = [...byName.keys()].sort();
    for (const name of sorted)
        visit(name);
    const tools = new Map();
    const skills = new Map();
    for (const name of sorted) {
        const plugin = byName.get(name);
        for (const tool of plugin.tools ?? [])
            tools.set(qualify(name, tool.name), { name: qualify(name, tool.name), plugin: name, tool });
        for (const skill of plugin.skills ?? [])
            skills.set(`${name}__${skill.name}`, { plugin: name, skill });
    }
    const fingerprint = createHash('sha256')
        .update(JSON.stringify(listed.map((name) => [name, byName.get(name).description])))
        .digest('hex')
        .slice(0, 16);
    return {
        plugins: new Map(sorted.map((name) => [name, byName.get(name)])),
        listed: new Map(listed.map((name) => [name, byName.get(name)])),
        closures,
        tools,
        skills,
        fingerprint,
        pluginName: (name) => (byName.has(name) ? name : undefined),
    };
}
/**
 * Imports every plugin unit in a trusted local directory. Each unit must default-export a plugin. From then on, for the
 * life of the process, an import made from inside a unit may reach only aigent/plugin, packages and its own files.
 */
export async function loadPlugins(dir) {
    const units = await pluginUnits(typeof dir === 'string' ? dir : fileURLToPath(dir));
    guard(units);
    const plugins = [];
    for (const { entry } of units) {
        const mod = await import(__rewriteRelativeImportExtension(pathToFileURL(entry).href)).catch((error) => {
            throw error instanceof DeniedImport ? new CatalogError([error.message]) : error;
        });
        const parsed = parsePlugin(mod.default, entry);
        if (!parsed.ok)
            throw new CatalogError(parsed.problems);
        plugins.push(parsed.plugin);
    }
    return plugins;
}
/**
 * What `loadPlugins` treats as one plugin each: `*.ts`, `*.js` or `*.mjs` files, and subdirectories with an `index.ts`
 * or `index.js`. Sorted by name so the catalog is stable. A symlink counts as what it points to, and the unit is its
 * target. Throws when a directory's index resolves outside it or when two units overlap.
 */
export async function pluginUnits(dir) {
    const found = [];
    for (const name of (await readdir(dir)).sort()) {
        const path = join(dir, name);
        // Node runs a module from its real path, so the guard knows a unit by its real path, wherever a symlink points.
        const root = await realpath(path).catch((error) => {
            if (error.code === 'ENOENT' && !isModuleFile(name))
                return undefined;
            throw error;
        });
        if (!root)
            continue;
        const entry = (await stat(root)).isDirectory() ? await indexOf(root) : isModuleFile(name) ? root : undefined;
        if (entry)
            found.push({ path, root, entry });
    }
    // The guard attributes a file to the first unit whose root holds it, so a unit inside another would pass for it.
    const problems = found.flatMap((unit, i) => [
        ...(within(unit.root, unit.entry) ? [] : [`${unit.path}: its index resolves to ${unit.entry}, outside the unit`]),
        ...found.slice(i + 1).filter((other) => within(unit.root, other.root) || within(other.root, unit.root)).map((other) => `${unit.path} and ${other.path} resolve to overlapping units`),
    ]);
    if (problems.length > 0)
        throw new CatalogError(problems);
    return found;
}
function isModuleFile(name) {
    return !name.startsWith('.') && !name.endsWith('.d.ts') && !name.endsWith('.test.ts') && /\.(ts|js|mjs)$/.test(name);
}
async function indexOf(dir) {
    const names = new Set(await readdir(dir));
    const index = ['index.ts', 'index.js'].find((name) => names.has(name));
    return index && realpath(join(dir, index));
}
const SRC = import.meta.dirname;
// What a plugin's import of aigent/plugin reaches, plugin.ts in the checkout and the built plugin.js once installed.
const CONTRACT = fileURLToPath(import.meta.resolve('aigent/plugin'));
/** Every unit root loadPlugins has seen. It never shrinks, because a tool's lazy import runs long after loading. */
const guarded = new Set();
let hooked = false;
class DeniedImport extends Error {
}
function guard(units) {
    for (const unit of units)
        guarded.add(unit.root);
    if (hooked)
        return;
    hooked = true;
    registerHooks({
        resolve(specifier, context, next) {
            const resolved = next(specifier, context);
            const from = context.parentURL?.startsWith('file:') ? fileURLToPath(context.parentURL) : undefined;
            const unit = from && unitOf(from);
            if (!from || !unit || !resolved.url.startsWith('file:'))
                return resolved;
            const reason = denial(specifier, unit, fileURLToPath(resolved.url));
            if (!reason)
                return resolved;
            throw new DeniedImport(`${unit}: ${relative(dirname(unit), from)} imports "${specifier}", which ${reason}. A plugin may import only aigent/plugin, node: builtins, packages and files inside its own unit.`);
        },
    });
}
function denial(specifier, unit, target) {
    if (target === CONTRACT)
        return undefined;
    if (within(SRC, target))
        return 'is inside aigent';
    const other = unitOf(target);
    if (other && other !== unit)
        return 'is another plugin unit';
    // Bare specifiers may resolve anywhere, so npm workspace packages work.
    if (/^(\.|\/|file:)/.test(specifier) && !within(unit, target))
        return 'is outside its unit';
    return undefined;
}
function unitOf(path) {
    for (const root of guarded)
        if (within(root, path))
            return root;
    return undefined;
}
function within(root, path) {
    return path === root || path.startsWith(root + sep);
}
/** Shape and per-plugin rules. Cross-plugin rules (duplicates, dependencies) live in parseCatalog. */
function parsePlugin(value, source) {
    if (!isRecord(value))
        return { ok: false, problems: [`${source}: default export is not a plugin object`] };
    const problems = [];
    const { name, description, dependsOn, secrets, instructions, tools, skills, hooks } = value;
    const label = typeof name === 'string' ? `plugin "${name}"` : source;
    const fail = (problem) => problems.push(`${label}: ${problem}`);
    if (typeof name !== 'string' || !PLUGIN_NAME.test(name))
        fail('name must match [a-z0-9-]+');
    else if (RESERVED.includes(name))
        fail(`"${name}" is reserved`);
    if (typeof description !== 'string' || description.trim() === '' || description.includes('\n'))
        fail('description must be one non-empty line');
    if (dependsOn !== undefined && !(Array.isArray(dependsOn) && dependsOn.every((d) => typeof d === 'string')))
        fail('dependsOn must be a list of plugin names');
    if (secrets !== undefined && !(Array.isArray(secrets) && secrets.every((s) => typeof s === 'string' && s !== '') && new Set(secrets).size === secrets.length))
        fail('secrets must be a list of distinct secret names');
    if (instructions !== undefined && typeof instructions !== 'string')
        fail('instructions must be a string');
    if (tools !== undefined && !Array.isArray(tools))
        fail('tools must be a list');
    const toolNames = new Set();
    for (const tool of Array.isArray(tools) ? tools : []) {
        if (!isRecord(tool) || typeof tool.name !== 'string' || !TOOL_NAME.test(tool.name)) {
            fail('every tool needs a name matching [A-Za-z0-9_-]+');
            continue;
        }
        const at = `tool "${tool.name}"`;
        if (toolNames.has(tool.name))
            fail(`${at} is defined twice`);
        toolNames.add(tool.name);
        if (typeof name === 'string' && `${name}__${tool.name}`.length > MAX_TOOL_NAME)
            fail(`${at}: "${name}__${tool.name}" is longer than ${MAX_TOOL_NAME} characters`);
        if (typeof tool.description !== 'string')
            fail(`${at}: description must be a string`);
        if (!isRecord(tool.parameters) || tool.parameters.type !== 'object')
            fail(`${at}: parameters must be a JSON Schema with type "object"`);
        if (typeof tool.execute !== 'function')
            fail(`${at}: execute must be a function`);
    }
    if (skills !== undefined && !Array.isArray(skills))
        fail('skills must be a list');
    const skillNames = new Set();
    for (const skill of Array.isArray(skills) ? skills : []) {
        if (!isRecord(skill) || typeof skill.name !== 'string' || !SKILL_NAME.test(skill.name)) {
            fail('every skill needs a name matching [a-z0-9_-]+');
            continue;
        }
        const at = `skill "${skill.name}"`;
        if (skillNames.has(skill.name))
            fail(`${at} is defined twice`);
        skillNames.add(skill.name);
        if (typeof skill.description !== 'string')
            fail(`${at}: description must be a string`);
        if (typeof skill.load !== 'function')
            fail(`${at}: load must be a function`);
    }
    if (hooks !== undefined && !isRecord(hooks))
        fail('hooks must be an object');
    for (const [hook, fn] of Object.entries(isRecord(hooks) ? hooks : {})) {
        if (!HOOKS.has(hook))
            fail(`unknown hook "${hook}"`);
        else if (typeof fn !== 'function')
            fail(`hook "${hook}" must be a function`);
    }
    if (problems.length > 0)
        return { ok: false, problems };
    // Every field the Plugin type declares was checked above. The engine reads them for the life of a session, so it gets
    // a frozen copy the plugin object cannot change. Functions stay bound to the object they were defined on.
    const v = value;
    return {
        ok: true,
        plugin: Object.freeze({
            name: v.name,
            description: v.description,
            ...(v.dependsOn && { dependsOn: Object.freeze([...v.dependsOn]) }),
            ...(v.secrets && { secrets: Object.freeze([...v.secrets]) }),
            ...(v.instructions !== undefined && { instructions: v.instructions }),
            ...(v.tools && { tools: Object.freeze(v.tools.map(copyTool)) }),
            ...(v.skills && { skills: Object.freeze(v.skills.map(copySkill)) }),
            ...(v.hooks && { hooks: copyHooks(v.hooks) }),
        }),
    };
}
function copyTool(tool) {
    const { name, description, parameters, execute } = tool;
    return Object.freeze({ name, description, parameters, execute: execute.bind(tool) });
}
function copySkill(skill) {
    const { name, description, load } = skill;
    return Object.freeze({ name, description, load: load.bind(skill) });
}
function copyHooks(hooks) {
    const copy = {};
    for (const hook of HOOKS) {
        const fn = hooks[hook];
        if (typeof fn === 'function')
            copy[hook] = fn.bind(hooks);
    }
    return Object.freeze(copy);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
