// Host vocabulary. Types, and the one constant a host option is checked against. No loop-library type crosses this
// surface; `createSession` lives in the adapter.
/** The shortest secret value a session and an eval run accept. */
export const MIN_SECRET_LENGTH = 8;
