import { type ToolName } from './catalog.ts';
import type { JsonSchema, Tool, ToolContext, ToolResult } from './plugin.ts';
import type { ToolMode } from './session.ts';
export interface ToolSpec {
    readonly name: ToolName;
    readonly description: string;
    readonly parameters: JsonSchema;
}
export declare const CALL_TOOL: ToolSpec;
export declare const RUN_CODE: ToolSpec;
export declare const RUN_BASH: ToolSpec;
/**
 * What each tool mode declares. `declared`: every enabled plugin's tools. `reached`: plugins enabled after the first
 * request are reached through the `via` core tool, and their schemas follow `heading` in the enable text.
 */
export type ModeRules = {
    readonly late: 'declared';
} | {
    readonly late: 'reached';
    readonly via: ToolSpec;
    readonly heading: string;
};
export declare const MODES: {
    readonly [M in ToolMode]: ModeRules;
};
/** The session a code tool's calls go back through. */
export interface CodeHost {
    /** Per code tool call, its tool calls included. */
    readonly timeoutMs: number;
    /** Tool calls per code tool call. Each call past it fails without running. */
    readonly maxCalls: number;
    /** The id of the call `ctx` was made for. Undefined when the session did not make it. */
    callIdOf(ctx: ToolContext): string | undefined;
    /** Runs one tool call the code made, as call `id`. `route` says how it came, as in "from core__run_code". Never rejects. */
    call(id: string, name: string, args: unknown, route: string, signal: AbortSignal): Promise<ToolResult>;
    /** The tool names `core__run_bash` runs as commands. */
    commands(): string[];
    /** The session's redactor. A result is redacted before it is capped, so the cap never cuts a secret short of a match. */
    redact(text: string): string;
}
/** `core__run_code` and `core__run_bash`. Each call the code makes is `<call id>/<n>`. */
export declare function createCodeTools(host: CodeHost): readonly Tool[];
