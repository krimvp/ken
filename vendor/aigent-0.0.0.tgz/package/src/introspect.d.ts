import type { Denial, EnableCause, Plugin } from './plugin.ts';
export interface SessionView {
    config(): ConfigView;
    /** Finished calls, oldest first. A call still running is not one. */
    calls(): readonly CallView[];
    plugins(): PluginsView;
    /** Read from inside a tool call. */
    budget(): BudgetView;
}
export interface ConfigView {
    readonly modelId: string;
    readonly provider: string;
    readonly toolMode: 'native' | 'dispatch' | 'programmatic' | 'bash';
    readonly maxTurns: number;
    readonly hookTimeoutMs: number;
    readonly contextWindow: number;
    readonly maxOutputTokens: number;
}
export type CallView = 
/** `name` is the resolved tool, or for `unresolved` the name the model asked for. */
{
    readonly name: string;
    readonly outcome: 'ran' | 'error' | 'unresolved';
} | {
    readonly name: string;
    readonly outcome: 'denied';
    readonly denials: readonly Denial[];
};
export interface PluginsView {
    /** Enable order. */
    readonly enabled: readonly {
        readonly name: string;
        readonly cause: EnableCause;
    }[];
    readonly catalogOnly: readonly {
        readonly name: string;
        readonly description: string;
    }[];
    /** The skills enabled plugins offer, as `<plugin>__<skill>`. */
    readonly skills: readonly {
        readonly name: string;
        readonly loaded: boolean;
    }[];
}
export interface BudgetView {
    /** Model requests in this session, the one that made this call included. */
    readonly requests: number;
    /** `prompt` is input plus cache read and cache write. */
    readonly tokens: {
        readonly prompt: number;
        readonly input: number;
        readonly cacheRead: number;
        readonly cacheWrite: number;
        readonly output: number;
    };
    readonly cachedRatio: {
        readonly session: number | undefined;
        readonly last: number | undefined;
    };
    /** The last request's prompt tokens plus its output. Undefined before the first request. */
    readonly context: {
        readonly used: number;
        readonly window: number;
    } | undefined;
    /** In the current prompt. The turn that made this call is used. */
    readonly turns: {
        readonly used: number;
        readonly max: number;
    };
    /**
     * Finished delegations and their helpers' requests and tokens, which the lines above leave out. Only while
     * `delegate` is enabled, so every other session's budget is unchanged. A delegation still running is not counted.
     */
    readonly delegated: {
        readonly calls: number;
        readonly requests: number;
        readonly tokens: {
            readonly prompt: number;
            readonly output: number;
        };
    } | undefined;
}
/** The tool's local name. The model sees `session__inspect`. */
export declare const INSPECT = "inspect";
export declare function createSessionPlugin(view: SessionView): Plugin;
