import type { Plugin, Skill, Tool } from './plugin.ts';
declare const pluginNameBrand: unique symbol;
/** A plugin name that exists in the catalog, or `core`. */
export type PluginName = string & {
    readonly [pluginNameBrand]: true;
};
declare const toolNameBrand: unique symbol;
/** A model-facing `<plugin>__<tool>` name of a tool that exists. */
export type ToolName = string & {
    readonly [toolNameBrand]: true;
};
export declare const CORE: PluginName;
/** The engine-built plugin only the host can enable. */
export declare const SESSION: PluginName;
/** The engine-built plugin only the host can enable, and only when it configured `delegate`. Reserved either way. */
export declare const DELEGATE: PluginName;
/** Unambiguous because plugin names cannot contain `_`. */
export declare function qualify(plugin: PluginName, local: string): ToolName;
export interface CatalogTool {
    readonly name: ToolName;
    readonly plugin: PluginName;
    readonly tool: Tool;
}
export interface CatalogSkill {
    readonly plugin: PluginName;
    readonly skill: Skill;
}
export interface Catalog {
    /** Name order, so text derived from it is stable. Builtins included. */
    readonly plugins: ReadonlyMap<PluginName, Plugin>;
    /** The host's plugins, in name order: the ones the model sees in the catalog and may enable. */
    readonly listed: ReadonlyMap<PluginName, Plugin>;
    /** Dependencies first, the plugin itself last. */
    readonly closures: ReadonlyMap<PluginName, readonly PluginName[]>;
    readonly tools: ReadonlyMap<ToolName, CatalogTool>;
    /** Keyed by `<plugin>__<skill>`. */
    readonly skills: ReadonlyMap<string, CatalogSkill>;
    /** Changes when a plugin is added, removed, renamed or redescribed. */
    readonly fingerprint: string;
    pluginName(name: string): PluginName | undefined;
}
export declare class CatalogError extends Error {
    readonly problems: readonly string[];
    constructor(problems: readonly string[]);
}
/**
 * `builtins` are plugins the engine builds under reserved names. They are trusted, so not parsed. Only the host can
 * enable them, so they are left out of `listed` and the fingerprint, and no host plugin may depend on one.
 */
export declare function parseCatalog(plugins: readonly Plugin[], builtins?: readonly Plugin[]): Catalog;
/**
 * Imports every plugin unit in a trusted local directory. Each unit must default-export a plugin. From then on, for the
 * life of the process, an import made from inside a unit may reach only aigent/plugin, packages and its own files.
 */
export declare function loadPlugins(dir: string | URL): Promise<Plugin[]>;
/** One plugin: a module file that is its own root, or a subdirectory whose whole subtree is the unit and whose index is the entry. */
export interface PluginUnit {
    readonly root: string;
    readonly entry: string;
}
/**
 * What `loadPlugins` treats as one plugin each: `*.ts`, `*.js` or `*.mjs` files, and subdirectories with an `index.ts`
 * or `index.js`. Sorted by name so the catalog is stable. A symlink counts as what it points to, and the unit is its
 * target. Throws when a directory's index resolves outside it or when two units overlap.
 */
export declare function pluginUnits(dir: string): Promise<PluginUnit[]>;
export {};
