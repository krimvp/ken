import type { Plugin, ToolContext } from './plugin.ts';
/** How a helper's run ended, as the engine reports it. */
export type HelperResult = {
    readonly stop: 'done' | 'max_turns';
    readonly text: string;
    readonly turns: number;
} | {
    readonly stop: 'aborted';
    readonly turns: number;
} | {
    readonly stop: 'error';
    readonly message: string;
    readonly turns: number;
};
export interface DelegatePort {
    /** Fixed at creation, so the tool description, and the prompt cache, never change. */
    readonly profiles: readonly {
        readonly name: string;
        readonly description: string;
    }[];
    /** Runs one helper to its end. `ctx` is the one this call's execute got. Never rejects. */
    run(profile: string, task: string, ctx: ToolContext): Promise<HelperResult>;
}
/** The tool's local name. The model sees `delegate__run`. */
export declare const RUN = "run";
/** A helper's answer can be any length, so the tool result keeps only its start. */
export declare const ANSWER_CAP = 8000;
export declare function createDelegatePlugin(port: DelegatePort): Plugin;
