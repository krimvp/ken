// The delegate plugin: one tool that hands a task to a helper session and returns its answer. Like any plugin it
// imports only the plugin contract. The engine builds it with a DelegatePort and owns everything the helper's run
// leaves behind: its record, its events and its gate chain.
/** The tool's local name. The model sees `delegate__run`. */
export const RUN = 'run';
/** A helper's answer can be any length, so the tool result keeps only its start. */
export const ANSWER_CAP = 8_000;
export function createDelegatePlugin(port) {
    const profiles = [...port.profiles].sort((a, b) => (a.name < b.name ? -1 : 1));
    const names = profiles.map((p) => p.name);
    return {
        name: 'delegate',
        description: 'Hands one task to a helper agent with fewer tools.',
        instructions: 'delegate__run hands one self-contained task to a helper with fewer tools. The helper sees none of this conversation, so put everything it needs in task. Its tool calls pass the same checks as yours.',
        tools: [
            {
                name: RUN,
                description: ['Run a helper on one task and get its answer. Profiles:', ...profiles.map((p) => `- ${p.name}: ${p.description}`)].join('\n'),
                parameters: {
                    type: 'object',
                    properties: {
                        profile: { type: 'string', enum: names, description: 'Which helper runs the task.' },
                        task: { type: 'string', description: 'The whole task, with every fact the helper needs.' },
                    },
                    required: ['profile', 'task'],
                    additionalProperties: false,
                },
                async execute(args, ctx) {
                    const profile = String(args.profile);
                    if (!names.includes(profile))
                        return error(`No profile "${profile}". Profiles: ${names.join(', ')}.`);
                    const result = await port.run(profile, String(args.task), ctx);
                    switch (result.stop) {
                        case 'done':
                            return text(capped(result.text));
                        case 'max_turns':
                            return text(`The helper stopped at its turn limit. Its last text:\n${capped(result.text)}`);
                        case 'aborted':
                            return error('The helper was aborted.');
                        case 'error':
                            return error(`The helper failed: ${result.message}`);
                        default:
                            return result;
                    }
                },
            },
        ],
    };
}
function capped(answer) {
    return answer.length > ANSWER_CAP ? `${answer.slice(0, ANSWER_CAP)}\n[answer cut at ${ANSWER_CAP} characters]` : answer;
}
function text(value) {
    return { content: [{ type: 'text', text: value }] };
}
function error(value) {
    return { content: [{ type: 'text', text: value }], isError: true };
}
