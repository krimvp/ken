import { type ModelSpec, type RunResult, type Session, type SessionEvent, type SessionOptions, type ToolMode, type Transcript } from '../session.ts';
import { type RecordedScenario, type Scenario } from './scenario.ts';
export declare const isToolMode: (value: unknown) => value is ToolMode;
export interface RunOptions {
    /** The directory the scenario's plugin paths are relative to, normally the scenario file's directory. */
    readonly root: string;
    /** `createSession` for a real model. Tests pass a faux model's opener, which continues one script across sessions. */
    readonly open: (options: SessionOptions) => Promise<Session>;
    readonly model: ModelSpec;
    readonly toolMode: ToolMode;
    /** Per prompt step. A prompt past it ends `aborted`, which ends the run. */
    readonly promptTimeoutMs: number;
    /** Aborts the running prompt, which ends the run. The steps already taken are still returned. */
    readonly signal?: AbortSignal;
    /** After each step that completed, with its 1-based number. Scrubbed like the log. */
    readonly onStep?: (step: number, log: StepLog) => void;
    /** The scenario's name on the attempt span, normally its file name without `.json`. */
    readonly name?: string;
}
/**
 * What one scenario run did. JSON-shaped, so a result directory round-trips it exactly.
 *
 * Every string has passed the scrub: a raw secret value appears only as the mark `secret-free` fails on,
 * `[LEAKED:<leakNonce>:<NAME>]`. Adjacent text deltas are joined into one text event first, so the scrub sees whole strings.
 */
export interface RunLog {
    readonly format: 'aigent-run/1';
    readonly scenario: RecordedScenario;
    readonly model: ModelSpec;
    /**
     * The sampling the run asked for, read from `model`. `null` is unset: no request carried it, so the server's default
     * applied. Absent from a run recorded before the field existed, which says nothing either way.
     */
    readonly sampling?: {
        readonly temperature: number | null;
        readonly seed: number | null;
    };
    readonly toolMode: ToolMode;
    /**
     * Transcript length once the first session exists: the system prompt and the records written at creation.
     * Those records reach no listener, because nobody can subscribe before the session is returned.
     */
    readonly start: number;
    /**
     * `steps[i]` is what happened at `scenario.steps[i]`. Shorter than the scenario when a prompt ended `error` or
     * `aborted`, which is its last step, or when a step threw.
     */
    readonly steps: readonly StepLog[];
    /** The step that threw and ended the run there, such as a resume whose plugin set rejects the saved records. */
    readonly failure?: {
        readonly step: number;
        readonly message: string;
    };
    /**
     * Random per run and never shown to the model, so text that quotes a mark, in a reply or a fetched page, cannot
     * pass for one. Absent from a run recorded before it, whose mark is `[LEAKED:<NAME>]`.
     */
    readonly leakNonce?: string;
    /** The trace of the run's `aigent.eval.attempt` span. Absent when no OpenTelemetry SDK recorded the span. */
    readonly traceId?: string;
    /** The last session's transcript after it closed. Begins with every saved transcript's messages. */
    readonly transcript: Transcript;
}
/** `end` is the transcript length after the step, so a step's messages are `transcript.messages.slice(previous end, end)`. */
export type StepLog = {
    readonly kind: 'prompt';
    readonly result: RunResult;
    readonly events: readonly SessionEvent[];
    readonly end: number;
} | {
    readonly kind: 'enable';
    readonly events: readonly SessionEvent[];
    readonly end: number;
}
/** `saved` is the JSON the new session resumed from. `end` counts the records the new session wrote at creation. */
 | {
    readonly kind: 'resume';
    readonly saved: Transcript;
    readonly end: number;
};
/**
 * Runs every step on sessions from `options.open`. Throws ScenarioError before the first session opens when a
 * secret or the model key is unset or shorter than MIN_SECRET_LENGTH, a plugin set does not load, or the scenario
 * names a plugin, tool or skill its set lacks. A provider error, an abort or a throwing step is not a throw: it ends
 * the run, and the log says where.
 *
 * The run is one `aigent.eval.attempt` span, which every prompt's `invoke_agent` nests under. It parents on the
 * environment's `TRACEPARENT` when there is one.
 */
export declare function runScenario(scenario: Scenario, options: RunOptions): Promise<RunLog>;
/**
 * The secret names whose raw values a string held before the scrub marked them, by the marks of the run whose nonce
 * this is. Read by `secret-free`. A run without a nonce was recorded with the old mark, which any text could forge.
 */
export declare function leaksIn(text: string, nonce: string | undefined): readonly string[];
/**
 * Writes the run log as a result directory, all or nothing: the files go to a sibling temp directory that is
 * renamed into place, so `dir` holds a whole run or does not exist. Rejects when `dir` exists. A crash leaves only
 * a `<dir>.partial-*` sibling, which no reader mistakes for a run.
 *
 *   <dir>/run.json         RunFile
 *   <dir>/transcript.json  the final Transcript
 *   <dir>/events.jsonl     {"step": n, "event": SessionEvent} per line, in emission order; prompt and enable steps only
 *   <dir>/resume-<n>.json  the Transcript step n saved and resumed from, one per resume step
 */
export declare function writeRun(dir: string, run: RunLog): Promise<void>;
export declare class RunFileError extends Error {
    readonly problems: readonly string[];
    constructor(dir: string, problems: readonly string[]);
}
/**
 * The result-directory boundary, for `aigent check` and the future multeval grader. Parses what writeRun wrote
 * back into the identical RunLog, and throws RunFileError naming every problem rather than guessing. Past the
 * type tag of each event, events and transcript messages are trusted as written.
 */
export declare function readRun(dir: string): Promise<RunLog>;
