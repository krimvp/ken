import type { JsonObject } from '../plugin.ts';
declare const patternBrand: unique symbol;
/** A regex source that compiled. Always matched case-insensitively. */
export type Pattern = string & {
    readonly [patternBrand]: true;
};
/** Argument name to the pattern its value must match: a string as it is, any other value as JSON. */
export type ArgPatterns = Readonly<Record<string, Pattern>>;
/** A call to `tool` whose arguments match `args`. */
export interface CallPattern {
    readonly tool: string;
    readonly args?: ArgPatterns;
}
/**
 * A path that `state`'s fixture plugin counts as changed, any path when `path` is absent. The plugin keeps
 * `{ "changed": { <path>: <calls that changed it> } }` as its state, and a count that grew during a step is a change.
 */
export interface StatePattern {
    readonly state: string;
    readonly path?: Pattern;
}
/** What `respects` forbids: a call that ran, or a change a fixture recorded. */
export type Effect = CallPattern | StatePattern;
/**
 * One behavior judged on one prompt step. The `check` names are the behavior names, so a scenario reads in the same
 * words a report prints. Tool names are model-facing `<plugin>__<tool>`; the plugin is the part before `__`.
 * `setup` marks an expectation that only sets the scene, such as the enable that makes a gate reachable: it is judged
 * and reported as usual, and the multeval grade leaves it out of its kind's score.
 */
export type Expectation = Behavior & {
    readonly setup?: true;
};
/**
 * An expectation in a recorded run whose check this build does not have, such as `refuses`, which 65a17d4 removed.
 * Kept exactly as recorded, so readRun still returns what writeRun wrote, and reported as a skip.
 */
export type Unjudgeable = JsonObject & {
    readonly check: string;
};
/** The scenario a result directory holds: what it was run with, judged by this build where it can be. */
export type RecordedScenario = Scenario<Expectation | Unjudgeable>;
export declare const isJudgeable: (expectation: {
    readonly check: string;
}) => expectation is Expectation;
type Behavior = 
/** The model enables `plugin` during this prompt. */
{
    readonly check: 'discover';
    readonly plugin: string;
}
/** The model enables nothing during this prompt. */
 | {
    readonly check: 'restraint';
}
/**
 * After the model enabled `tool`'s plugin, its first turn that does more than load skills (`core__load_skill`) calls
 * `tool` with matching args, and the call runs.
 */
 | {
    readonly check: 'use';
    readonly tool: string;
    readonly args?: ArgPatterns;
}
/** Dispatch mode. After a `core__call_tool` for `tool` is rejected before it runs, the next turn's call to `tool` runs. */
 | {
    readonly check: 'dispatch-recover';
    readonly tool: string;
}
/** The final answer matches `matches`, as for an instruction delivered in an enable result or a correct answer. */
 | {
    readonly check: 'follow';
    readonly matches: Pattern;
}
/**
 * No call that ran during this prompt, a helper's included, matches a call effect, and no fixture state, a helper's
 * included, records a change that matches a state effect. A denied call does not run, so it changes nothing.
 */
 | {
    readonly check: 'respects';
    readonly effects: readonly Effect[];
}
/** The model loads `skill` (`<plugin>__<skill>`) during this prompt, or does not, as `loaded` says. */
 | {
    readonly check: 'skill';
    readonly skill: string;
    readonly loaded: boolean;
}
/**
 * After a gate denies a call to `tool` with matching args, neither the model nor a helper calls `tool` with matching
 * args again or any tool in `around`, and the model's answer matches `reports`. A helper's denied call counts.
 */
 | {
    readonly check: 'denial';
    readonly tool: string;
    readonly args?: ArgPatterns;
    readonly reports: Pattern;
    readonly around?: readonly string[];
}
/** Needs an enable step of `tool`'s plugin since the previous prompt. The model calls `tool` and the call runs. */
 | {
    readonly check: 'host-enable';
    readonly tool: string;
    readonly args?: ArgPatterns;
}
/** Needs a resume step since the previous prompt. The model calls `tool` and the call runs. */
 | {
    readonly check: 'resume';
    readonly tool: string;
    readonly args?: ArgPatterns;
};
export type ScenarioStep<E = Expectation> = 
/** `expect` holds the behaviors judged on this prompt, one per check. Invariants need no declaration. */
{
    readonly kind: 'prompt';
    readonly text: string;
    readonly expect?: readonly E[];
}
/** A host enable between prompts. */
 | {
    readonly kind: 'enable';
    readonly plugin: string;
}
/** Saves the transcript through a JSON round trip, closes the session and resumes from it. `plugins` replaces the plugin set. */
 | {
    readonly kind: 'resume';
    readonly plugins?: readonly string[];
};
/** A helper profile. Its plugins come from directories like the scenario's own, loaded once and shared by every helper. */
export interface ScenarioProfile {
    readonly description: string;
    readonly plugins: readonly string[];
    readonly maxTurns?: number;
    readonly systemPrompt?: string;
}
/** `/2` adds state effects to `respects`. `/1` is the same vocabulary without them, so older result directories still read. */
export type ScenarioFormat = 'aigent-scenario/1' | 'aigent-scenario/2';
export interface Scenario<E = Expectation> {
    readonly format: ScenarioFormat;
    /** Plugin directories relative to the scenario file. Each is loaded with loadPlugins and the sets are concatenated. */
    readonly plugins: readonly string[];
    /** The session's `delegate` options. A scenario that enables `delegate` needs it. */
    readonly delegate?: {
        readonly maxDepth?: number;
        readonly profiles: Readonly<Record<string, ScenarioProfile>>;
    };
    /** Enabled at start. Passed again on every resume, where names already enabled are skipped. */
    readonly enabled?: readonly string[];
    /**
     * Env var names holding host secrets. Each must be set when the scenario runs: its value goes to the session's
     * `secrets` and to the runner's scrub. A fixture plugin reads the same variable, so the value it echoes is the one scrubbed.
     */
    readonly secrets?: readonly string[];
    readonly systemPrompt: string;
    /** Model turns per prompt. The session default applies when absent. */
    readonly maxTurns?: number;
    /**
     * Yes/no criteria for an LLM judge, for what no pattern can judge, such as whether the model told the user the truth.
     * The multeval loader turns them into a judge check of the case. `check` never reads them.
     */
    readonly judge?: readonly string[];
    /** Labels that select the scenario. The multeval loader copies them into its case, so a run spec's `tags` pick a suite. */
    readonly tags?: readonly string[];
    /** Non-empty. A step's number, in check ids and result files, is its 1-based position here. */
    readonly steps: readonly ScenarioStep<E>[];
}
export declare class ScenarioError extends Error {
    readonly problems: readonly string[];
    constructor(problems: readonly string[]);
}
export declare function readScenario(file: string): Promise<Scenario>;
/**
 * The scenario boundary. Collects every problem, each at its JSON path, before throwing ScenarioError. Unknown fields
 * are problems too, so a misspelled `expect` is not silently a scenario without behaviors, and so is an unknown check.
 * So is what would make a score vacuous: an empty pattern, an empty `args`, a duplicate name, a `discover` or `use`
 * of a plugin enabled before its prompt, which always skips, and a scenario with no prompt.
 */
export declare function parseScenario(value: unknown): Scenario;
/**
 * The same boundary for the copy a result directory keeps, read by readRun. The run already happened, so an
 * expectation whose check this build lacks is kept as Unjudgeable instead of failing the whole directory, and what
 * only an author can fix, such as an empty pattern, is judged as it was recorded.
 */
export declare function parseRecordedScenario(value: unknown): RecordedScenario;
export interface Names {
    readonly plugins: readonly string[];
    readonly tools: readonly string[];
    readonly skills: readonly string[];
    /** Plugins whose state a state effect reads, which a helper's plugin set may hold too. */
    readonly states?: readonly string[];
}
/** Names an expectation relies on, so the runner can refuse a scenario that misspells one before a paid run. */
export declare function referencedNames(expectation: Expectation): Names;
type Check = Behavior['check'];
/** Every check name, in parse-table order. */
export declare const CHECKS: readonly Check[];
export {};
