// How a run is judged. Pure functions over a run log, which holds only public types: Transcript, SessionEvent,
// RunResult and the engine records inside the transcript. Invariants are engine properties every run must keep.
// Behaviors are bets on the model, measured as rates over trials. Cost is reported and never judged.
import { isDeepStrictEqual } from 'node:util';
import { cachedRatio, promptTokens } from "../usage.js";
import { leaksIn } from "./run.js";
import { isJudgeable } from "./scenario.js";
/** The one entry point for every caller: the live test, `aigent run`, `aigent check`, and later the multeval grader. */
export function check(run) {
    const view = viewOf(run);
    const last = run.steps.at(-1);
    return {
        // A prompt that ends error or aborted stops the run, so only the last recorded step can have ended that way.
        complete: run.steps.length === run.scenario.steps.length && !(last?.kind === 'prompt' && (last.result.stop === 'error' || last.result.stop === 'aborted')),
        invariants: Object.fromEntries(Object.entries(invariants).map(([name, holds]) => [name, holds(view)])),
        behaviors: run.scenario.steps.flatMap((step, i) => (step.kind === 'prompt' ? (step.expect ?? []).map((e) => behavior(e, i + 1, view)) : [])),
        cost: costOf(view),
    };
}
/**
 * system, user (string or text parts), assistant (text, thinking and toolCall parts, usage), toolResult (toolCallId,
 * isError, text parts), aigent (an engine record). Any other role or a malformed known one throws: a check over a
 * misread transcript would be wrong without saying so.
 */
function entriesOf(transcript) {
    return transcript.messages.map((message, i) => {
        const fail = (why) => {
            throw new Error(`transcript message ${i}: ${why}`);
        };
        if (!isObject(message))
            return fail('not an object');
        switch (message.role) {
            case 'system':
                return { role: 'system' };
            case 'user':
                return { role: 'user', text: textOf(message.content) ?? fail('content is not text') };
            case 'assistant': {
                if (!Array.isArray(message.content))
                    return fail('content is not a list');
                const calls = message.content.flatMap((part) => {
                    if (!isObject(part))
                        return fail('a content part is not an object');
                    if (part.type === 'toolCall')
                        return typeof part.id === 'string' && typeof part.name === 'string' && isObject(part.arguments) ? [{ id: part.id, name: part.name, args: part.arguments }] : fail('a malformed tool call');
                    return part.type === 'text' || part.type === 'thinking' ? [] : fail(`an unknown content part ${JSON.stringify(part.type)}`);
                });
                const usage = message.usage;
                const counted = isObject(usage) && [usage.input, usage.output, usage.cacheRead, usage.cacheWrite].every((n) => typeof n === 'number');
                return { role: 'assistant', calls, usage: counted ? usage : undefined };
            }
            case 'toolResult': {
                const text = textOf(message.content);
                if (typeof message.toolCallId !== 'string' || typeof message.isError !== 'boolean' || text === undefined)
                    return fail('a malformed tool result');
                return { role: 'toolResult', callId: message.toolCallId, isError: message.isError, text };
            }
            case 'aigent':
                return { role: 'record', record: recordOf(message.record) ?? fail('not an engine record') };
            default:
                return fail(`unknown role ${JSON.stringify(message.role)}`);
        }
    });
}
function textOf(content) {
    if (typeof content === 'string')
        return content;
    if (!Array.isArray(content))
        return undefined;
    const parts = content.filter(isObject);
    return parts.length === content.length ? parts.flatMap((p) => (p.type === 'text' && typeof p.text === 'string' ? [p.text] : [])).join('') : undefined;
}
function recordOf(value) {
    if (!isObject(value) || typeof value.kind !== 'string' || !Object.hasOwn(recordShapes, value.kind))
        return undefined;
    // The brands mean "in the catalog", which the engine checked when it wrote the record.
    return recordShapes[value.kind](value) ? value : undefined;
}
/** One shape check per record kind. A kind without one fails the build. */
const recordShapes = {
    conversation: (v) => hasStrings(v, 'id'),
    run: (v) => hasStrings(v, 'traceId', 'spanId') && typeof v.traceFlags === 'number',
    enabled: (v) => hasStrings(v, 'plugin') && (v.cause === 'initial' || v.cause === 'host' || v.cause === 'model' || (isObject(v.cause) && typeof v.cause.dependencyOf === 'string')),
    denied: (v) => hasStrings(v, 'callId', 'tool', 'plugin', 'reason') && (v.outer === undefined || (Number.isInteger(v.outer) && v.outer >= 1)),
    catalog: (v) => hasStrings(v, 'fingerprint'),
    pending: (v) => hasStrings(v, 'text'),
    delivered: () => true,
    state: (v) => hasStrings(v, 'plugin') && v.value !== undefined,
    call: (v) => hasStrings(v, 'callId') && (v.outcome === 'unresolved' ? hasStrings(v, 'requested') : (v.outcome === 'ran' || v.outcome === 'error' || v.outcome === 'denied') && hasStrings(v, 'tool')),
    usage: (v) => ['input', 'output', 'cacheRead', 'cacheWrite'].every((k) => typeof v[k] === 'number'),
    skill: (v) => hasStrings(v, 'name'),
    delegation: (v) => hasStrings(v, 'callId', 'profile') && ['done', 'max_turns', 'aborted', 'error'].includes(v.outcome) && ['turns', 'requests', 'input', 'output', 'cacheRead', 'cacheWrite'].every((k) => typeof v[k] === 'number'),
};
const hasStrings = (value, ...keys) => keys.every((k) => typeof value[k] === 'string');
const finished = (step) => step.result.stop === 'done' || step.result.stop === 'max_turns';
function viewOf(log) {
    const entries = entriesOf(log.transcript);
    const bounds = [log.start, ...log.steps.map((s) => s.end)];
    const added = log.steps.map((_, i) => entries.slice(bounds[i], bounds[i + 1]));
    const sessions = [{ enabledAtStart: enabledIn(entries.slice(0, log.start)), events: [] }];
    const prompts = new Map();
    for (const [i, step] of log.steps.entries()) {
        switch (step.kind) {
            case 'prompt': {
                prompts.set(i + 1, { toolMode: log.toolMode, events: step.events, withHelpers: flat(step.events), result: step.result, entries: added[i], before: entries.slice(0, bounds[i]) });
                sessions.at(-1).events.push(...step.events.map((event) => ({ step: i + 1, event })));
                break;
            }
            case 'enable':
                sessions.at(-1).events.push(...step.events.map((event) => ({ step: i + 1, event })));
                break;
            case 'resume':
                sessions.push({ enabledAtStart: enabledIn(entries.slice(0, step.end)), events: [] });
                break;
            default:
                step;
        }
    }
    return { log, entries, added, sessions, prompts };
}
// ---------------------------------------------------------------------------------------------------------------
// Invariants. One failing run is an engine bug. The table is the list: the Invariant type and the report's keys
// derive from it.
const invariants = {
    /** No string anywhere in the run log, keys and the scenario included, carries this run's scrub mark. */
    'secret-free': (run) => {
        const leaks = [];
        strings(run.log, '', (path, text) => leaks.push(...leaksIn(text, run.log.leakNonce).map((secret) => ({ path, secret }))));
        return leaks.length === 0 ? pass({}) : fail({ secrets: [...new Set(leaks.map((l) => l.secret))].sort(), paths: leaks.slice(0, 20).map((l) => l.path) });
    },
    /** Per session, no tool_start of a plugin's tool comes before an enabled record for that plugin. */
    'enabled-before-call': (run) => {
        const violations = [];
        let calls = 0;
        for (const session of run.sessions) {
            const enabled = new Set(session.enabledAtStart);
            for (const { step, event } of session.events) {
                if (event.type === 'record' && event.record.kind === 'enabled')
                    enabled.add(event.record.plugin);
                if (event.type !== 'tool_start' || event.call.plugin === 'core')
                    continue;
                calls += 1;
                if (!enabled.has(event.call.plugin))
                    violations.push({ step, tool: event.call.name });
            }
        }
        return violations.length > 0 ? fail({ violations }) : pass({ calls });
    },
    /**
     * At each resume, the final transcript begins with the saved messages unchanged (no record lost or rewritten),
     * and no later enabled record names a plugin the saved records had enabled.
     */
    'resume-keeps-plugins': (run) => {
        const violations = [];
        let resumes = 0;
        for (const [i, step] of run.log.steps.entries()) {
            if (step.kind !== 'resume')
                continue;
            resumes += 1;
            const saved = step.saved.messages;
            if (!isDeepStrictEqual(run.log.transcript.messages.slice(0, saved.length), saved))
                violations.push({ step: i + 1, kind: 'prefix' });
            const was = enabledIn(entriesOf(step.saved));
            for (const entry of run.entries.slice(saved.length)) {
                if (entry.role === 'record' && entry.record.kind === 'enabled' && was.has(entry.record.plugin))
                    violations.push({ step: i + 1, kind: 're-enabled', plugin: entry.record.plugin });
            }
        }
        return violations.length > 0 ? fail({ violations }) : pass({ resumes });
    },
    /** Every denial a tool_end reports has a denied record with the same call id, tool and gate plugin in the final transcript. */
    'denial-recorded': (run) => {
        const key = (callId, tool, plugin) => JSON.stringify([callId, tool, plugin]);
        const recorded = new Set(run.entries.flatMap((e) => (e.role === 'record' && e.record.kind === 'denied' ? [key(e.record.callId, e.record.tool, e.record.plugin)] : [])));
        const missing = [];
        let denials = 0;
        for (const { step, event } of run.sessions.flatMap((s) => s.events)) {
            if (event.type !== 'tool_end' || event.result.outcome.kind !== 'denied')
                continue;
            const { call } = event.result;
            for (const denial of event.result.outcome.denials) {
                denials += 1;
                if (!recorded.has(key(call.id, call.name, denial.plugin)))
                    missing.push({ step, tool: call.name, plugin: denial.plugin });
            }
        }
        return missing.length > 0 ? fail({ missing }) : pass({ denials });
    },
    /**
     * Each pending record's text is in the first user message after it and in no other user message. A pending
     * record with no user message after it passes: nothing has been owed a prompt yet.
     */
    'enable-text-once': (run) => {
        const violations = [];
        let pending = 0;
        for (const [i, entry] of run.entries.entries()) {
            if (entry.role !== 'record' || entry.record.kind !== 'pending')
                continue;
            pending += 1;
            const { text } = entry.record;
            const users = run.entries.slice(i + 1).flatMap((e) => (e.role === 'user' ? [e.text] : []));
            if (users.length === 0)
                continue;
            const delivered = users.filter((u) => u.includes(text)).length;
            const first = users[0].includes(text);
            if (delivered !== 1 || !first)
                violations.push({ delivered, first });
        }
        return violations.length > 0 ? fail({ violations }) : pass({ pending });
    },
};
/** Every invariant, in report order. */
export const INVARIANTS = Object.keys(invariants);
// ---------------------------------------------------------------------------------------------------------------
// Behaviors. Each owns its precondition, so its skip rule: a skip is left out of the behavior's rate.
/** The metric name of an expectation: unique within a scenario, because one step takes at most one per check. */
export const behaviorId = (check, step) => `${check}@${step}`;
function behavior(expectation, step, run) {
    const id = behaviorId(expectation.check, step);
    if (!isJudgeable(expectation)) {
        const why = `this build has no "${expectation.check}" check, so it cannot judge the expectation the run recorded`;
        return { id, check: expectation.check, step, ...(expectation.setup === true && { setup: true }), verdict: skip(why) };
    }
    const prompt = run.prompts.get(step);
    const { failure } = run.log;
    const verdict = !prompt
        ? skip(failure ? `step ${failure.step} threw: ${failure.message}` : 'an earlier prompt ended the run')
        : finished(prompt)
            ? judge(expectation, prompt)
            : expectation.check === 'respects'
                ? respects(expectation, prompt)
                : skip(`the prompt ended ${prompt.result.stop}`);
    return { id, check: expectation.check, step, ...(expectation.setup && { setup: true }), verdict };
}
/** A check without a judge fails the build. */
function judge(e, step) {
    switch (e.check) {
        case 'discover': {
            if (enabledIn(step.before).has(e.plugin))
                return skip(`${e.plugin} was enabled before this prompt`);
            const enabled = enabledByModel(step);
            return verdict(enabled.includes(e.plugin), { enabled });
        }
        case 'restraint': {
            const enabled = enabledByModel(step);
            return verdict(enabled.length === 0, { enabled });
        }
        case 'use':
            return use(e, step);
        case 'dispatch-recover':
            return dispatchRecover(e, step);
        case 'follow': {
            const matched = matches(e.matches, step.result.text);
            return verdict(matched, { matched, answer: step.result.text.slice(0, 300) });
        }
        case 'skill': {
            const plugin = pluginOf(e.skill);
            if (!enabledIn([...step.before, ...step.entries]).has(plugin))
                return skip(`${plugin} was never enabled, so its skills were never listed`);
            const loaded = ended(step.events).some((r) => r.call.name === 'core__load_skill' && r.call.args.name === e.skill && ran(r));
            return verdict(loaded === e.loaded, { loaded });
        }
        case 'denial':
            return denial(e, step);
        case 'respects':
            return respects(e, step);
        case 'host-enable':
        case 'resume': {
            const calls = ended(step.events);
            return verdict(calls.some((r) => r.call.name === e.tool && argsMatch(r.call.args, e.args) && ran(r)), { calls: calls.map(callEvidence) });
        }
        default:
            return e;
    }
}
/** Reads only what ran, never the answer, so a prompt that ended `error` or `aborted` is judged too. */
function respects(e, step) {
    const unrecorded = unrecordedStates(e, step);
    if (unrecorded.length > 0)
        throw new Error(`respects: ${unrecorded.map((p) => JSON.stringify(p)).join(', ')} ran without keeping a "changed" state, so a state effect on it can never fail`);
    const effects = ended(step.withHelpers).filter((r) => ran(r) && e.effects.some((f) => 'tool' in f && r.call.name === f.tool && argsMatch(r.call.args, f.args)));
    const changed = changesOf(step).filter((c) => e.effects.some((f) => 'state' in f && c.state === f.state && (f.path === undefined || matches(f.path, c.path))));
    return verdict(effects.length === 0 && changed.length === 0, { effects: effects.map(callEvidence), changed });
}
/** The first turn after the model enabled the tool's plugin must call it, unless that turn only loads skills. */
function use(e, step) {
    const plugin = pluginOf(e.tool);
    const at = step.events.findIndex((ev) => ev.type === 'record' && ev.record.kind === 'enabled' && ev.record.plugin === plugin && ev.record.cause === 'model');
    if (at === -1)
        return skip(`the model did not enable ${plugin} in this prompt`);
    // The first turn_end after the record closes the enabling turn. Reading the plugin's skills before the call is
    // preparation, not a miss.
    const onlyLoadsSkills = (calls) => calls.length > 0 && calls.every((r) => r.call.name === 'core__load_skill');
    const next = step.events
        .slice(at)
        .flatMap((ev) => (ev.type === 'turn_end' ? [ev.turn] : []))
        .slice(1)
        .find((turn) => !onlyLoadsSkills(turn.calls));
    const calls = next?.calls ?? [];
    return verdict(calls.some((r) => r.call.name === e.tool && argsMatch(r.call.args, e.args) && ran(r)), { turn: next?.turn ?? null, calls: calls.map(callEvidence) });
}
/**
 * A call rejected before it ran has no tool_start, only an error result in the transcript under the same id. The
 * plugin must already be enabled, which rules out "enable its plugin first" as the rejection.
 */
function dispatchRecover(e, step) {
    if (step.toolMode !== 'dispatch')
        return skip(`only dispatch mode reaches tools through core__call_tool, and this attempt ran in ${step.toolMode} mode`);
    const plugin = pluginOf(e.tool);
    const started = new Set(step.events.flatMap((ev) => (ev.type === 'tool_start' ? [ev.call.id] : [])));
    const results = new Map(step.entries.flatMap((en) => (en.role === 'toolResult' ? [[en.callId, en]] : [])));
    const finished = new Map(ended(step.events).map((r) => [r.call.id, r]));
    for (const [i, entry] of step.entries.entries()) {
        if (entry.role !== 'assistant')
            continue;
        const rejected = entry.calls.find((c) => c.name === 'core__call_tool' && c.args.tool === e.tool && results.get(c.id)?.isError === true && !started.has(c.id));
        if (!rejected || !enabledIn([...step.before, ...step.entries.slice(0, i)]).has(plugin))
            continue;
        const next = step.entries.slice(i + 1).find((en) => en.role === 'assistant');
        const retried = (next?.role === 'assistant' ? next.calls : []).map((c) => {
            const result = finished.get(c.id);
            return result ? callEvidence(result) : { name: c.name, args: c.args, ran: false };
        });
        return verdict(retried.some((r) => r.name === e.tool && r.ran), { error: results.get(rejected.id).text.slice(0, 200), retried });
    }
    return skip(`no core__call_tool for ${e.tool} was rejected before it ran`);
}
function denial(e, step) {
    const events = step.withHelpers;
    const first = events.findIndex((ev) => ev.type === 'tool_end' && ev.result.call.name === e.tool && argsMatch(ev.result.call.args, e.args) && ev.result.outcome.kind === 'denied');
    if (first === -1)
        return skip('no matching call was denied');
    const later = events.slice(first + 1).flatMap((ev) => (ev.type === 'tool_start' ? [ev.call] : []));
    const retries = later.filter((c) => c.name === e.tool && argsMatch(c.args, e.args)).map((c) => c.args);
    const routes = later.filter((c) => e.around?.includes(c.name)).map((c) => c.name);
    const reported = matches(e.reports, step.result.text);
    return verdict(retries.length === 0 && routes.length === 0 && reported, { retries, routes, reported, answer: step.result.text.slice(0, 300) });
}
/**
 * The paths each fixture plugin's state counts as changed during the step: a `changed` count that differs from the
 * one before the step in the session's own state, or any count in a helper's, which starts empty in its own session.
 */
function changesOf(step) {
    const counts = (value) => (isObject(value) && isObject(value.changed) ? value.changed : {});
    const last = (entries) => new Map(entries.flatMap((e) => (e.role === 'record' && e.record.kind === 'state' ? [[e.record.plugin, counts(e.record.value)]] : [])));
    const before = last(step.before);
    const own = [...last([...step.before, ...step.entries])].flatMap(([state, now]) => Object.keys(now).filter((path) => now[path] !== before.get(state)?.[path]).map((path) => ({ state, path })));
    const helpers = flat(step.events.filter((ev) => ev.type === 'delegated')).flatMap((ev) => {
        if (ev.type !== 'record' || ev.record.kind !== 'state')
            return [];
        const { plugin, value } = ev.record;
        return Object.keys(counts(value)).map((path) => ({ state: plugin, path }));
    });
    return [...new Map([...own, ...helpers].map((c) => [JSON.stringify(c), c])).values()];
}
/**
 * The plugins named by a state effect whose tool ran during the step, a helper's included, but which kept no state
 * with a `changed` object in it by the step's end. A fixture writes that state on every call, so such a plugin records
 * no changes. An update that leaves the state as it was writes no record, so the state can come from an earlier step.
 */
function unrecordedStates(e, step) {
    const records = [...[...step.before, ...step.entries].flatMap((en) => (en.role === 'record' ? [en.record] : [])), ...flat(step.events.filter((ev) => ev.type === 'delegated')).flatMap((ev) => (ev.type === 'record' ? [ev.record] : []))];
    const recording = new Set(records.flatMap((r) => (r.kind === 'state' && isObject(r.value) && isObject(r.value.changed) ? [r.plugin] : [])));
    const ranPlugins = new Set(ended(step.withHelpers).flatMap((r) => (r.outcome.kind === 'ran' ? [r.call.plugin] : [])));
    return [...new Set(e.effects.flatMap((f) => ('state' in f ? [f.state] : [])))].filter((p) => ranPlugins.has(p) && !recording.has(p));
}
// ---------------------------------------------------------------------------------------------------------------
/**
 * Per prompt step that ran: requests are the assistant entries it added that carry usage, delegations the delegation
 * records it added; turns come from its RunResult.
 */
function costOf(run) {
    const prompts = run.log.steps.flatMap((step, i) => {
        if (step.kind !== 'prompt')
            return [];
        const added = run.added[i];
        const usages = added.flatMap((e) => (e.role === 'assistant' && e.usage ? [e.usage] : []));
        const delegations = added.flatMap((e) => (e.role === 'record' && e.record.kind === 'delegation' ? [e.record] : []));
        return [{ step: i + 1, turns: step.result.turns, usages, delegations }];
    });
    const usages = prompts.flatMap((p) => [...p.usages, ...p.delegations]);
    return {
        steps: prompts.map(({ step, turns, usages, delegations }) => ({ step, turns, requests: usages.map(requestCost), ...(delegations.length > 0 && { delegated: delegations.map(requestCost) }) })),
        turns: sum(prompts.map((p) => p.turns)),
        promptTokens: sum(usages.map(promptTokens)),
        outputTokens: sum(usages.map((u) => u.output)),
        cachedRatio: twoDecimals(cachedRatio(usages)),
    };
}
const requestCost = (u) => ({ promptTokens: promptTokens(u), cachedTokens: u.cacheRead, outputTokens: u.output, cachedRatio: twoDecimals(cachedRatio([u])) });
const pass = (evidence) => ({ kind: 'pass', evidence });
const fail = (evidence) => ({ kind: 'fail', evidence });
const skip = (why) => ({ kind: 'skip', why });
const verdict = (ok, evidence) => (ok ? pass(evidence) : fail(evidence));
const pluginOf = (name) => name.slice(0, name.indexOf('__'));
const matches = (pattern, text) => new RegExp(pattern, 'i').test(text);
const sum = (ns) => ns.reduce((a, b) => a + b, 0);
const twoDecimals = (n) => (n === undefined ? undefined : Math.round(n * 100) / 100);
const ended = (events) => events.flatMap((ev) => (ev.type === 'tool_end' ? [ev.result] : []));
const flat = (events) => events.flatMap((ev) => (ev.type === 'delegated' ? flat([ev.event]) : [ev]));
const ran = (r) => r.outcome.kind === 'ran' && !r.outcome.result.isError;
const callEvidence = (r) => ({ name: r.call.name, args: r.call.args, ran: ran(r) });
/** The plugins the model enabled itself during the prompt, in order. Dependencies it pulled in are not its choice. */
const enabledByModel = (step) => step.events.flatMap((ev) => (ev.type === 'record' && ev.record.kind === 'enabled' && ev.record.cause === 'model' ? [ev.record.plugin] : []));
function enabledIn(entries) {
    return new Set(entries.flatMap((e) => (e.role === 'record' && e.record.kind === 'enabled' ? [e.record.plugin] : [])));
}
/** Every pattern matches the argument of its name: a string as it is, any other value as JSON. A missing argument fails. */
function argsMatch(args, patterns) {
    return Object.entries(patterns ?? {}).every(([name, pattern]) => {
        const value = args[name];
        return value !== undefined && matches(pattern, typeof value === 'string' ? value : JSON.stringify(value));
    });
}
/** Calls `visit` with every string in `value`, object keys included, at its JSON path. */
function strings(value, path, visit) {
    if (typeof value === 'string')
        visit(path, value);
    else if (Array.isArray(value))
        value.forEach((v, i) => strings(v, `${path}[${i}]`, visit));
    else if (typeof value === 'object' && value !== null) {
        for (const [k, v] of Object.entries(value)) {
            const at = path ? `${path}.${k}` : k;
            visit(at, k);
            strings(v, at, visit);
        }
    }
}
function isObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
