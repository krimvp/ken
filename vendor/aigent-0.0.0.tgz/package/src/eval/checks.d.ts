import type { JsonObject } from '../plugin.ts';
import type { EngineRecord, RunResult, SessionEvent, ToolMode } from '../session.ts';
import { type Usage } from '../usage.ts';
import { type RunLog } from './run.ts';
export type Verdict = {
    readonly kind: 'pass';
    readonly evidence: JsonObject;
} | {
    readonly kind: 'fail';
    readonly evidence: JsonObject;
}
/** The behavior had no chance to show: its precondition never happened, or its step did not run. Left out of rates. */
 | {
    readonly kind: 'skip';
    readonly why: string;
};
/** An invariant has nothing to wait for, so it never skips. A run with nothing to check passes. */
export type InvariantVerdict = Extract<Verdict, {
    readonly kind: 'pass' | 'fail';
}>;
export interface BehaviorResult {
    /** `${check}@${step}`, unique within a scenario: the metric name a report and a future grade use. */
    readonly id: string;
    /** An Expectation's check, or the check of an Unjudgeable one a recorded run holds. */
    readonly check: string;
    /** 1-based scenario step. */
    readonly step: number;
    /** The expectation only sets the scene, so a grade leaves it out of its kind's score. */
    readonly setup?: true;
    readonly verdict: Verdict;
}
export interface RequestCost {
    readonly promptTokens: number;
    readonly cachedTokens: number;
    readonly outputTokens: number;
    /** cachedTokens / promptTokens, two decimals, undefined for an empty prompt. */
    readonly cachedRatio: number | undefined;
}
export interface Cost {
    /**
     * One entry per prompt step that ran. `delegated` has one entry per delegation the step finished, the requests of
     * that helper and every helper below it summed, and is left out when there were none.
     */
    readonly steps: readonly {
        readonly step: number;
        readonly turns: number;
        readonly requests: readonly RequestCost[];
        readonly delegated?: readonly RequestCost[];
    }[];
    readonly turns: number;
    readonly promptTokens: number;
    readonly outputTokens: number;
    /** Sum of cachedTokens over sum of promptTokens across every request of the run, helpers' included, undefined when there were none. */
    readonly cachedRatio: number | undefined;
}
export interface Report {
    /** Every scenario step ran. False when a prompt ended `error` or `aborted`, or a step threw. */
    readonly complete: boolean;
    readonly invariants: {
        readonly [K in Invariant]: InvariantVerdict;
    };
    /** One per expectation, in scenario order. */
    readonly behaviors: readonly BehaviorResult[];
    readonly cost: Cost;
}
/** The one entry point for every caller: the live test, `aigent run`, `aigent check`, and later the multeval grader. */
export declare function check(run: RunLog): Report;
/** The parts of an `aigent-transcript/1` message the checks read. One per message, so step bounds index both. */
type Entry = {
    readonly role: 'system';
} | {
    readonly role: 'user';
    readonly text: string;
} | {
    readonly role: 'assistant';
    readonly calls: readonly Call[];
    readonly usage: Usage | undefined;
} | {
    readonly role: 'toolResult';
    readonly callId: string;
    readonly isError: boolean;
    readonly text: string;
} | {
    readonly role: 'record';
    readonly record: EngineRecord;
};
interface Call {
    readonly id: string;
    readonly name: string;
    readonly args: JsonObject;
}
/** A run parsed once for every check. */
interface RunView {
    readonly log: RunLog;
    /** The final transcript. */
    readonly entries: readonly Entry[];
    /** Per step that ran, the transcript entries it added. */
    readonly added: readonly (readonly Entry[])[];
    /**
     * One per session: the plugins enabled when it was created, read from the transcript because no listener saw
     * those records, and the events of its steps in emission order, each tagged with its step number.
     */
    readonly sessions: readonly {
        readonly enabledAtStart: ReadonlySet<string>;
        readonly events: readonly Tagged[];
    }[];
    /** Keyed by 1-based step number. Every prompt step that ran, however it ended. */
    readonly prompts: ReadonlyMap<number, PromptView<RunResult>>;
}
interface Tagged {
    readonly step: number;
    readonly event: SessionEvent;
}
/** A prompt that ran. Only `respects` judges one that ended `error` or `aborted`, because its calls ran all the same. */
interface PromptView<R extends RunResult = Finished> {
    readonly toolMode: ToolMode;
    readonly events: readonly SessionEvent[];
    /** `events` with each helper's events in place of the `delegated` event that carried them, at any depth. */
    readonly withHelpers: readonly SessionEvent[];
    readonly result: R;
    /** The transcript entries this prompt added. */
    readonly entries: readonly Entry[];
    /** The entries before this prompt. */
    readonly before: readonly Entry[];
}
type Finished = Extract<RunResult, {
    readonly stop: 'done' | 'max_turns';
}>;
declare const invariants: {
    /** No string anywhere in the run log, keys and the scenario included, carries this run's scrub mark. */
    'secret-free': (run: RunView) => InvariantVerdict;
    /** Per session, no tool_start of a plugin's tool comes before an enabled record for that plugin. */
    'enabled-before-call': (run: RunView) => InvariantVerdict;
    /**
     * At each resume, the final transcript begins with the saved messages unchanged (no record lost or rewritten),
     * and no later enabled record names a plugin the saved records had enabled.
     */
    'resume-keeps-plugins': (run: RunView) => InvariantVerdict;
    /** Every denial a tool_end reports has a denied record with the same call id, tool and gate plugin in the final transcript. */
    'denial-recorded': (run: RunView) => InvariantVerdict;
    /**
     * Each pending record's text is in the first user message after it and in no other user message. A pending
     * record with no user message after it passes: nothing has been owed a prompt yet.
     */
    'enable-text-once': (run: RunView) => InvariantVerdict;
};
export type Invariant = keyof typeof invariants;
/** Every invariant, in report order. */
export declare const INVARIANTS: readonly Invariant[];
/** The metric name of an expectation: unique within a scenario, because one step takes at most one per check. */
export declare const behaviorId: (check: string, step: number) => string;
export {};
