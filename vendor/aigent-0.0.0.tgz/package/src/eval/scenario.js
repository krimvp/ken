// What a scenario author writes, and the one place a scenario file is validated. A scenario is a JSON script of
// steps over one session. The runner (run.ts) interprets the steps; the checks (checks.ts) judge the expectations.
import { readFile } from 'node:fs/promises';
import { isAbsolute, normalize } from 'node:path';
export const isJudgeable = (expectation) => Object.hasOwn(expectations, expectation.check);
const FORMATS = ['aigent-scenario/1', 'aigent-scenario/2'];
export class ScenarioError extends Error {
    problems;
    constructor(problems) {
        super(`invalid scenario:\n- ${problems.join('\n- ')}`);
        this.problems = problems;
    }
}
export async function readScenario(file) {
    let value;
    try {
        value = JSON.parse(await readFile(file, 'utf8'));
    }
    catch (error) {
        throw new ScenarioError([`${file}: ${error instanceof Error ? error.message : String(error)}`]);
    }
    return parseScenario(value);
}
/**
 * The scenario boundary. Collects every problem, each at its JSON path, before throwing ScenarioError. Unknown fields
 * are problems too, so a misspelled `expect` is not silently a scenario without behaviors, and so is an unknown check.
 * So is what would make a score vacuous: an empty pattern, an empty `args`, a duplicate name, a `discover` or `use`
 * of a plugin enabled before its prompt, which always skips, and a scenario with no prompt.
 */
export function parseScenario(value) {
    return parse(value, (_, at, p) => p.fail(`${at}.check: must be one of ${CHECKS.join(', ')}`, undefined), new Problems(true));
}
/**
 * The same boundary for the copy a result directory keeps, read by readRun. The run already happened, so an
 * expectation whose check this build lacks is kept as Unjudgeable instead of failing the whole directory, and what
 * only an author can fix, such as an empty pattern, is judged as it was recorded.
 */
export function parseRecordedScenario(value) {
    return parse(value, (raw) => raw, new Problems(false));
}
function parse(value, unknownCheck, p) {
    const raw = fields(value, '', ['format', 'plugins', 'delegate', 'enabled', 'secrets', 'systemPrompt', 'maxTurns', 'judge', 'tags', 'steps'], p);
    const format = FORMATS.find((f) => f === raw.format) ?? p.fail(`format: must be ${FORMATS.map((f) => `"${f}"`).join(' or ')}`, 'aigent-scenario/2');
    const plugins = directories(raw.plugins, 'plugins', p);
    const systemPrompt = typeof raw.systemPrompt === 'string' ? raw.systemPrompt : p.fail('systemPrompt: must be a string', '');
    const maxTurns = positive(raw.maxTurns, 'maxTurns', p);
    const rawSteps = Array.isArray(raw.steps) && raw.steps.length > 0 ? raw.steps : p.fail('steps: must be a non-empty list', []);
    const enabled = raw.enabled === undefined ? undefined : names(raw.enabled, 'enabled', PLUGIN, p);
    const steps = [];
    const on = new Set(enabled);
    for (const [i, raw] of rawSteps.entries()) {
        const step = parseStep(raw, `steps[${i}]`, steps.slice(steps.findLastIndex((s) => s.kind === 'prompt') + 1), on, unknownCheck, p);
        if (step?.kind === 'enable')
            on.add(step.plugin);
        if (step)
            steps.push(step);
    }
    if (rawSteps.length > 0 && !steps.some((s) => s.kind === 'prompt'))
        p.vacuous('steps: no prompt step, so nothing is asked or judged');
    const judgeable = steps.flatMap((s) => (s.kind === 'prompt' ? (s.expect ?? []).filter(isJudgeable) : []));
    if (format === 'aigent-scenario/1' && judgeable.some((e) => e.check === 'respects' && e.effects.some((f) => 'state' in f))) {
        p.fail('format: a state effect needs "aigent-scenario/2"', undefined);
    }
    const scenario = {
        format,
        plugins,
        ...(raw.delegate !== undefined && { delegate: delegateOf(raw.delegate, p) }),
        ...(enabled !== undefined && { enabled }),
        ...(raw.secrets !== undefined && { secrets: names(raw.secrets, 'secrets', ENV_NAME, p) }),
        systemPrompt,
        ...(maxTurns !== undefined && { maxTurns }),
        ...(raw.judge !== undefined && { judge: criteria(raw.judge, p) }),
        ...(raw.tags !== undefined && { tags: names(raw.tags, 'tags', TAG, p) }),
        steps,
    };
    if (p.list.length > 0)
        throw new ScenarioError(p.list);
    return scenario;
}
/** Names an expectation relies on, so the runner can refuse a scenario that misspells one before a paid run. */
export function referencedNames(expectation) {
    switch (expectation.check) {
        case 'discover':
            return { plugins: [expectation.plugin], tools: [], skills: [] };
        case 'restraint':
        case 'follow':
            return { plugins: [], tools: [], skills: [] };
        case 'use':
        case 'dispatch-recover':
        case 'host-enable':
        case 'resume':
            return { plugins: [], tools: [expectation.tool], skills: [] };
        case 'skill':
            return { plugins: [], tools: [], skills: [expectation.skill] };
        case 'denial':
            return { plugins: [], tools: [expectation.tool, ...(expectation.around ?? [])], skills: [] };
        case 'respects':
            return { plugins: [], tools: expectation.effects.flatMap((e) => ('tool' in e ? [e.tool] : [])), skills: [], states: expectation.effects.flatMap((e) => ('state' in e ? [e.state] : [])) };
        default:
            return expectation;
    }
}
const PLUGIN = /^[a-z0-9-]+$/;
const TOOL = /^[a-z0-9-]+__[A-Za-z0-9_-]+$/;
const SKILL = /^[a-z0-9-]+__[a-z0-9_-]+$/;
const ENV_NAME = /^[A-Z_][A-Z0-9_]*$/;
const TAG = /^\S+$/;
/**
 * `since` holds the steps between the previous prompt and this one, and `on` the plugins the host enabled before it.
 * An unknown kind has no value to stand in for it.
 */
function parseStep(value, at, since, on, unknownCheck, p) {
    const kind = isRecord(value) ? value.kind : undefined;
    switch (kind) {
        case 'prompt': {
            const raw = fields(value, at, ['kind', 'text', 'expect'], p);
            const text = typeof raw.text === 'string' && raw.text !== '' ? raw.text : p.fail(`${at}.text: must be a non-empty string`, '');
            if (raw.expect === undefined)
                return { kind, text };
            if (!Array.isArray(raw.expect))
                return p.fail(`${at}.expect: must be a list`, { kind, text });
            const expect = [];
            for (const [j, e] of raw.expect.entries()) {
                const parsed = parseExpectation(e, `${at}.expect[${j}]`, since, unknownCheck, p);
                if (!parsed)
                    continue;
                if (expect.some((other) => other.check === parsed.check))
                    p.fail(`${at}.expect[${j}]: a second "${parsed.check}" on one step would share its id`, undefined);
                const plugin = !isJudgeable(parsed) ? undefined : parsed.check === 'discover' ? parsed.plugin : parsed.check === 'use' ? pluginOf(parsed.tool) : undefined;
                if (plugin !== undefined && on.has(plugin))
                    p.vacuous(`${at}.expect[${j}]: ${plugin} is enabled before this prompt, so "${parsed.check}" always skips`);
                expect.push(parsed);
            }
            if (expect.length > 0 && expect.every((e) => isJudgeable(e) && e.setup))
                p.fail(`${at}.expect: every expectation is setup, so nothing on this step would be scored`, undefined);
            return { kind, text, expect };
        }
        case 'enable': {
            const raw = fields(value, at, ['kind', 'plugin'], p);
            return { kind, plugin: name(raw.plugin, `${at}.plugin`, PLUGIN, p) };
        }
        case 'resume': {
            const raw = fields(value, at, ['kind', 'plugins'], p);
            return raw.plugins === undefined ? { kind } : { kind, plugins: directories(raw.plugins, `${at}.plugins`, p) };
        }
        default:
            return p.fail(`${at}.kind: must be "prompt", "enable" or "resume"`, undefined);
    }
}
/** One parser per check. A check without one fails the build. */
const expectations = {
    discover: (raw, at, _, p) => ({ check: 'discover', plugin: name(raw.plugin, `${at}.plugin`, PLUGIN, p) }),
    restraint: () => ({ check: 'restraint' }),
    use: (raw, at, _, p) => ({ check: 'use', ...called(raw, at, p) }),
    'dispatch-recover': (raw, at, _, p) => ({ check: 'dispatch-recover', tool: name(raw.tool, `${at}.tool`, TOOL, p) }),
    follow: (raw, at, _, p) => ({ check: 'follow', matches: pattern(raw.matches, `${at}.matches`, p) }),
    skill: (raw, at, _, p) => ({
        check: 'skill',
        skill: name(raw.skill, `${at}.skill`, SKILL, p),
        loaded: typeof raw.loaded === 'boolean' ? raw.loaded : p.fail(`${at}.loaded: must be true or false`, false),
    }),
    denial: (raw, at, _, p) => ({
        check: 'denial',
        ...called(raw, at, p),
        reports: pattern(raw.reports, `${at}.reports`, p),
        ...(raw.around !== undefined && { around: names(raw.around, `${at}.around`, TOOL, p) }),
    }),
    'host-enable': (raw, at, since, p) => {
        const call = called(raw, at, p);
        const plugin = call.tool.split('__')[0];
        if (call.tool && !since.some((s) => s.kind === 'enable' && s.plugin === plugin))
            p.fail(`${at}: needs an enable step of "${plugin}" since the previous prompt`, undefined);
        return { check: 'host-enable', ...call };
    },
    resume: (raw, at, since, p) => {
        if (!since.some((s) => s.kind === 'resume'))
            p.fail(`${at}: needs a resume step since the previous prompt`, undefined);
        return { check: 'resume', ...called(raw, at, p) };
    },
    respects: (raw, at, _, p) => {
        if (!Array.isArray(raw.effects) || raw.effects.length === 0)
            return p.fail(`${at}.effects: must be a non-empty list of effects`, { check: 'respects', effects: [] });
        return { check: 'respects', effects: raw.effects.map((e, i) => effect(e, `${at}.effects[${i}]`, p)) };
    },
};
/** The fields each check takes besides `check` and `setup`. */
const FIELDS = {
    discover: ['plugin'],
    restraint: [],
    use: ['tool', 'args'],
    'dispatch-recover': ['tool'],
    follow: ['matches'],
    skill: ['skill', 'loaded'],
    denial: ['tool', 'args', 'reports', 'around'],
    'host-enable': ['tool', 'args'],
    resume: ['tool', 'args'],
    respects: ['effects'],
};
/** Every check name, in parse-table order. */
export const CHECKS = Object.keys(expectations);
function parseExpectation(value, at, since, unknownCheck, p) {
    const check = isRecord(value) ? value.check : undefined;
    if (typeof check !== 'string')
        return p.fail(`${at}.check: must be one of ${CHECKS.join(', ')}`, undefined);
    if (!Object.hasOwn(expectations, check))
        return unknownCheck({ ...value, check }, at, p);
    const raw = fields(value, at, ['check', 'setup', ...FIELDS[check]], p);
    const parsed = expectations[check](raw, at, since, p);
    const setup = raw.setup === undefined || typeof raw.setup === 'boolean' ? raw.setup === true : p.fail(`${at}.setup: must be true or false`, false);
    return setup ? { ...parsed, setup } : parsed;
}
function effect(value, at, p) {
    if (!isRecord(value) || !('state' in value))
        return called(fields(value, at, ['tool', 'args'], p), at, p);
    const raw = fields(value, at, ['state', 'path'], p);
    const state = name(raw.state, `${at}.state`, PLUGIN, p);
    return raw.path === undefined ? { state } : { state, path: pattern(raw.path, `${at}.path`, p) };
}
/** `tool` and optional `args`, shared by the checks about one call. */
function called(raw, at, p) {
    const tool = name(raw.tool, `${at}.tool`, TOOL, p);
    if (raw.args === undefined)
        return { tool };
    if (!isRecord(raw.args))
        return p.fail(`${at}.args: must be an object of patterns`, { tool });
    if (Object.keys(raw.args).length === 0)
        p.vacuous(`${at}.args: matches every call, so leave it out`);
    return { tool, args: Object.fromEntries(Object.entries(raw.args).map(([k, v]) => [k, pattern(v, `${at}.args.${k}`, p)])) };
}
/**
 * Every problem of one parse. `fail` records one and hands back a placeholder, so a single pass finds them all.
 * `vacuous` records one only for an authored scenario: a recorded run keeps what it was run with.
 */
class Problems {
    list = [];
    authored;
    constructor(authored) {
        this.authored = authored;
    }
    fail(problem, placeholder) {
        this.list.push(problem);
        return placeholder;
    }
    vacuous(problem) {
        if (this.authored)
            this.list.push(problem);
    }
}
function fields(value, at, known, p) {
    if (!isRecord(value))
        return p.fail(`${at || 'scenario'}: must be an object`, {});
    for (const key of Object.keys(value))
        if (!known.includes(key))
            p.fail(`${at ? `${at}.` : ''}${key}: unknown field`, undefined);
    return value;
}
function name(value, at, shape, p) {
    return typeof value === 'string' && shape.test(value) ? value : p.fail(`${at}: must match ${shape.source}`, '');
}
function names(value, at, shape, p) {
    if (!Array.isArray(value))
        return p.fail(`${at}: must be a list`, []);
    const list = value.map((v, i) => name(v, `${at}[${i}]`, shape, p));
    list.forEach((n, i) => n !== '' && list.indexOf(n) < i && p.vacuous(`${at}[${i}]: "${n}" is listed twice`));
    return list;
}
/** Non-empty, relative and inside the scenario's directory, because a multeval case carries only that directory. */
function directories(value, at, p) {
    if (!Array.isArray(value) || value.length === 0)
        return p.fail(`${at}: must be a non-empty list of directories`, []);
    return value.map((dir, i) => typeof dir === 'string' && dir !== '' && !isAbsolute(dir) && normalize(dir).split(/[\\/]/)[0] !== '..' ? dir : p.fail(`${at}[${i}]: must be a directory inside the scenario's own`, ''));
}
function delegateOf(value, p) {
    const raw = fields(value, 'delegate', ['maxDepth', 'profiles'], p);
    const maxDepth = positive(raw.maxDepth, 'delegate.maxDepth', p);
    const entries = isRecord(raw.profiles) ? Object.entries(raw.profiles) : [];
    if (entries.length === 0)
        p.fail('delegate.profiles: must name at least one profile', undefined);
    const profiles = Object.fromEntries(entries.map(([name, profile]) => {
        const at = `delegate.profiles.${name}`;
        if (!PLUGIN.test(name))
            p.fail(`${at}: name must match ${PLUGIN.source}`, undefined);
        const rawProfile = fields(profile, at, ['description', 'plugins', 'maxTurns', 'systemPrompt'], p);
        const description = typeof rawProfile.description === 'string' && /^[^\r\n]*\S[^\r\n]*$/.test(rawProfile.description) ? rawProfile.description : p.fail(`${at}.description: must be one non-empty line`, '');
        const turns = positive(rawProfile.maxTurns, `${at}.maxTurns`, p);
        const prompt = rawProfile.systemPrompt === undefined || typeof rawProfile.systemPrompt === 'string' ? rawProfile.systemPrompt : p.fail(`${at}.systemPrompt: must be a string`, undefined);
        return [name, { description, plugins: directories(rawProfile.plugins, `${at}.plugins`, p), ...(turns !== undefined && { maxTurns: turns }), ...(prompt !== undefined && { systemPrompt: prompt }) }];
    }));
    return { ...(maxDepth !== undefined && { maxDepth }), profiles };
}
function positive(value, at, p) {
    return value === undefined || (typeof value === 'number' && Number.isInteger(value) && value > 0) ? value : p.fail(`${at}: must be a positive integer`, undefined);
}
function pattern(value, at, p) {
    if (typeof value !== 'string')
        return p.fail(`${at}: must be a regex source`, '');
    if (value === '')
        p.vacuous(`${at}: an empty pattern matches every text`);
    try {
        new RegExp(value, 'i');
    }
    catch (error) {
        p.fail(`${at}: does not compile: ${error instanceof Error ? error.message : String(error)}`, undefined);
    }
    return value;
}
function criteria(value, p) {
    if (!Array.isArray(value) || value.length === 0)
        return p.fail('judge: must be a non-empty list of criteria', []);
    return value.map((c, i) => (typeof c === 'string' && c.trim() !== '' ? c : p.fail(`judge[${i}]: must be a non-empty string`, '')));
}
const pluginOf = (tool) => tool.slice(0, tool.indexOf('__'));
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
