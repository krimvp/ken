// The one tracer and meter the engine and the adapter share, the vocabulary both write, and the log records they
// correlate with it. Follows the OpenTelemetry semantic conventions v1.41.0 and the Logs Data Model.
import { context, isSpanContextValid, metrics, propagation, SpanStatusCode, trace } from '@opentelemetry/api';
import pkg from '../package.json' with { type: 'json' };
import { redactJson } from "./redact.js";
import { promptTokens } from "./usage.js";
// trace.getTracer drops the options, so the schema URL goes through the provider. It is the global proxy, which
// delegates to whatever SDK the host registers later.
const SCHEMA_URL = 'https://opentelemetry.io/schemas/1.41.0';
export const tracer = trace.getTracerProvider().getTracer('aigent', pkg.version, { schemaUrl: SCHEMA_URL });
function createInstruments(meter) {
    return {
        duration: meter.createHistogram('gen_ai.client.operation.duration', {
            unit: 's',
            description: 'GenAI operation duration.',
            advice: { explicitBucketBoundaries: [0.01, 0.02, 0.04, 0.08, 0.16, 0.32, 0.64, 1.28, 2.56, 5.12, 10.24, 20.48, 40.96, 81.92] },
        }),
        tokens: meter.createHistogram('gen_ai.client.token.usage', {
            unit: '{token}',
            description: 'Number of input and output tokens used.',
            advice: { explicitBucketBoundaries: [1, 4, 16, 64, 256, 1024, 4096, 16384, 65536, 262144, 1048576, 4194304, 16777216, 67108864] },
        }),
        toolCalls: meter.createCounter('aigent.tool.calls', { unit: '{call}', description: 'Tool calls by outcome.' }),
        denials: meter.createCounter('aigent.tool.denials', { unit: '{denial}', description: 'Gate denials by the plugin whose gate denied.' }),
        hookFailures: meter.createCounter('aigent.hook.failures', { unit: '{failure}', description: 'Hook calls that threw or timed out.' }),
    };
}
let meter;
/** The metrics API has no proxy provider, so instruments come from whichever provider is registered when one is first needed. */
export function instruments() {
    const provider = metrics.getMeterProvider();
    if (meter?.provider !== provider)
        meter = { provider, instruments: createInstruments(provider.getMeter('aigent', pkg.version, { schemaUrl: SCHEMA_URL })) };
    return meter.instruments;
}
export function thrownType(error) {
    return (error instanceof Error ? error.name : '_OTHER');
}
/** Token counts as both the `chat` and the `delegate__run` spans report them. Input tokens include the cached ones. */
export function usageAttributes(usage) {
    return {
        'gen_ai.usage.input_tokens': promptTokens(usage),
        'gen_ai.usage.output_tokens': usage.output,
        'gen_ai.usage.cache_read.input_tokens': usage.cacheRead,
        'gen_ai.usage.cache_creation.input_tokens': usage.cacheWrite,
    };
}
/** The longest string a content attribute keeps. Each string is cut on its own, so the JSON stays whole. */
const CONTENT_CAP = 16_384;
/** A content attribute's value: JSON with every string and key redacted, then each string cut at CONTENT_CAP with the cut marked. */
export function captured(value, redact) {
    return JSON.stringify(redactJson(value, redact), (_key, v) => typeof v === 'string' && v.length > CONTENT_CAP ? `${v.slice(0, CONTENT_CAP)}…[truncated ${v.length - CONTENT_CAP} characters]` : v);
}
/** The longest `gen_ai.input.messages` value, eight strings at CONTENT_CAP. The history grows with every request. */
const HISTORY_CAP = 8 * CONTENT_CAP;
/**
 * The newest `messages` whose captured JSON fits HISTORY_CAP together, as one JSON array, and how many older ones it
 * left out. The newest is kept even alone, and CONTENT_CAP already bounds each of its strings.
 */
export function capturedHistory(messages, redact) {
    const each = messages.map((m) => captured(m, redact));
    let start = Math.max(0, each.length - 1);
    let size = 2 + (each[start]?.length ?? 0);
    while (start > 0 && size + 1 + each[start - 1].length <= HISTORY_CAP)
        size += 1 + each[--start].length;
    return { json: `[${each.slice(start).join(',')}]`, omitted: start };
}
/** The bytes a base64 string decodes to. Captured content names an image by its type and size, never its data. */
export function decodedBytes(base64) {
    return Math.floor((base64.length * 3) / 4) - (base64.endsWith('==') ? 2 : base64.endsWith('=') ? 1 : 0);
}
/** On every span a session opens, so a backend finds a conversation's runs across traces, its helpers' included. */
export function conversationAttributes(id) {
    return { 'gen_ai.conversation.id': id };
}
/** Undefined when no SDK records the span. */
function recorded(span) {
    const ids = span?.spanContext();
    return ids && isSpanContextValid(ids) ? ids : undefined;
}
/** A span's ids for an event to spread in. Empty when no SDK records the span, so the event has no `trace`. */
export function traceOf(span = trace.getActiveSpan()) {
    const ids = recorded(span);
    return ids ? { trace: { traceId: ids.traceId, spanId: ids.spanId } } : {};
}
const severityNumbers = { DEBUG: 5, INFO: 9, WARN: 13, ERROR: 17 };
/** A record correlated with `span`, the active one by default. The caller has redacted `body` and `attributes`. */
export function logRecord(severity, body, attributes = {}, { eventName, span = trace.getActiveSpan() } = {}) {
    const ids = recorded(span);
    return {
        severityNumber: severityNumbers[severity],
        severityText: severity,
        body,
        attributes,
        ...(eventName !== undefined && { eventName }),
        ...(ids && { traceId: ids.traceId, spanId: ids.spanId, traceFlags: ids.traceFlags }),
    };
}
/** The host's default `log`: one stderr line per record at INFO and above, greppable by trace. */
export function writeStderr(record) {
    if (record.severityNumber < severityNumbers.INFO)
        return;
    const ids = record.traceId && record.spanId ? [['trace_id', record.traceId], ['span_id', record.spanId]] : [];
    const fields = [...Object.entries(record.attributes), ...ids].map(([key, value]) => `${key}=${oneLine(value)}`);
    console.error(['[aigent]', record.severityText, oneLine(record.body), ...fields].join(' '));
}
const oneLine = (text) => text.replaceAll('\r', '\\r').replaceAll('\n', '\\n');
/**
 * The active context joined with the OTel environment carriers `TRACEPARENT`, `TRACESTATE` and `BAGGAGE`, as the
 * global propagator reads them. Without a registered SDK the propagator reads nothing.
 */
export function envContext() {
    const { TRACEPARENT: traceparent, TRACESTATE: tracestate, BAGGAGE: baggage } = process.env;
    return propagation.extract(context.active(), { traceparent, tracestate, baggage });
}
export function fail(span, type, message) {
    span.setAttribute('error.type', type).setStatus(message === undefined ? { code: SpanStatusCode.ERROR } : { code: SpanStatusCode.ERROR, message });
}
