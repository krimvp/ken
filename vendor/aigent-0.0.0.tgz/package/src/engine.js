// The engine core: everything derived from the record log, the core plugin, enabling, the tool pipeline,
// gates, redaction, stop conditions and the run outcome. Knows nothing about pi; any loop drives it through Engine.
import { randomUUID } from 'node:crypto';
import { isSpanContextValid, SpanKind, trace } from '@opentelemetry/api';
import { CORE, DELEGATE, parseCatalog, qualify } from "./catalog.js";
import { CALL_TOOL, createCodeTools, MODES, RUN_BASH, RUN_CODE } from "./core-tools.js";
import { createDelegatePlugin } from "./delegate.js";
import { createSessionPlugin } from "./introspect.js";
import { createHookRunner } from "./hooks.js";
import { createRecordLog, parseRecord, storableState } from "./records.js";
import { redactor } from "./redact.js";
import { captured, conversationAttributes, decodedBytes, fail, instruments, logRecord, thrownType, traceOf, tracer, usageAttributes } from "./tracing.js";
import { cachedRatio, promptTokens, totalUsage } from "./usage.js";
export async function createEngine(options) {
    const { toolMode, validate, emit } = options;
    const rules = MODES[toolMode];
    const via = rules.late === 'reached' ? rules.via : undefined;
    const redact = redactor(options.secrets);
    const log = (severity, body, attributes, extra) => options.log(logRecord(severity, redact(body), Object.fromEntries(Object.entries(attributes).map(([key, value]) => [key, redact(value)])), extra));
    const records = createRecordLog((record) => emit({ type: 'record', record }));
    const { byKind, append } = records;
    // The session's lifetime: it fires when close begins, and from then on nothing new starts.
    const closing = new AbortController();
    const closed = () => closing.signal.aborted;
    let ended;
    let run = { signal: new AbortController().signal, turns: 0, last: undefined, stoppedBy: undefined, calls: [] };
    let hookPhase = Promise.resolve();
    const toolContexts = new WeakMap();
    // The built-in plugins and the code tools sit in the catalog and registry below, so their callbacks reach
    // bindings defined after them.
    const view = {
        config: () => ({
            modelId: options.model.id,
            provider: options.model.provider,
            toolMode,
            maxTurns: options.maxTurns,
            hookTimeoutMs: options.hookTimeoutMs,
            contextWindow: options.model.contextWindow,
            maxOutputTokens: options.model.maxOutputTokens,
        }),
        calls: () => byKind.calls.map((c) => {
            if (c.outcome === 'unresolved')
                return { name: c.requested, outcome: c.outcome };
            if (c.outcome !== 'denied')
                return { name: c.tool, outcome: c.outcome };
            return { name: c.tool, outcome: c.outcome, denials: (byKind.denials.get(c.callId) ?? []).map(({ plugin, reason }) => ({ plugin, reason })) };
        }),
        plugins: () => ({
            enabled: [...byKind.enabled.values()].map((r) => ({ name: r.plugin, cause: r.cause })),
            catalogOnly: [...catalog.listed].filter(([name]) => !byKind.enabled.has(name)).map(([name, p]) => ({ name, description: p.description })),
            skills: [...catalog.skills].filter(([, s]) => byKind.enabled.has(s.plugin)).map(([name]) => ({ name, loaded: byKind.skills.has(name) })),
        }),
        budget: () => {
            const total = totalUsage(byKind.usage);
            const last = byKind.usage.at(-1);
            const delegated = totalUsage(byKind.delegations);
            return {
                requests: byKind.usage.length,
                tokens: { prompt: promptTokens(total), ...total },
                cachedRatio: { session: cachedRatio(byKind.usage), last: last && cachedRatio([last]) },
                context: last && { used: promptTokens(last) + last.output, window: options.model.contextWindow },
                // endTurn has not yet counted the turn this call runs in.
                turns: { used: run.turns + 1, max: options.maxTurns },
                delegated: byKind.enabled.has(DELEGATE)
                    ? { calls: byKind.delegations.length, requests: byKind.delegations.reduce((n, d) => n + d.requests, 0), tokens: { prompt: promptTokens(delegated), output: delegated.output } }
                    : undefined,
            };
        },
    };
    const { delegation } = options;
    const port = delegation && {
        profiles: delegation.profiles,
        run: async (profile, task, ctx) => {
            const minted = toolContexts.get(ctx);
            if (!minted)
                return { stop: 'error', message: 'the call context is not one this session made', turns: 0 };
            const { callId, span } = minted;
            const { result, requests, usage, transcript } = await delegation.spawn({
                callId,
                profile,
                task,
                signal: AbortSignal.any([ctx.signal, closing.signal]),
                forward: (event) => emit({ type: 'delegated', callId, profile, event }),
                ancestors: ancestorsFor(callId),
                conversationId,
            });
            const { input, output, cacheRead, cacheWrite } = usage;
            append({ kind: 'delegation', callId, profile, outcome: result.stop, turns: result.turns, requests, input, output, cacheRead, cacheWrite });
            emit({ type: 'delegation', callId, profile, transcript });
            span.setAttributes({ 'aigent.delegate.profile': profile, 'aigent.delegate.requests': requests, 'aigent.delegate.stop': result.stop, ...usageAttributes(usage) });
            return result;
        },
    };
    const catalog = parseCatalog(options.plugins, [createSessionPlugin(view), ...(port ? [createDelegatePlugin(port)] : [])]);
    const missing = [...catalog.plugins.values()].flatMap((p) => (p.secrets ?? []).filter((s) => !Object.hasOwn(options.secrets, s)).map((s) => `plugin "${p.name}" declares secret "${s}", which the host did not pass in secrets`));
    if (missing.length > 0)
        throw new Error(missing.join('; '));
    const enabled = () => [...byKind.enabled.keys()];
    const pluginOf = (name) => catalog.plugins.get(name);
    const activePlugins = () => enabled().map(pluginOf);
    /** In the first request's tool list: enabled at creation, or a dependency pulled in by such a plugin. */
    const isInitial = (name) => {
        const cause = byKind.enabled.get(name)?.cause;
        return cause === 'initial' || (typeof cause === 'object' && byKind.enabled.get(cause.dependencyOf)?.cause === 'initial');
    };
    const declaresNatively = (name) => rules.late === 'declared' || isInitial(name);
    const catalogText = () => {
        const lines = [...catalog.listed].filter(([name]) => !byKind.enabled.has(name)).map(([name, p]) => `- ${name}: ${p.description}`);
        const body = lines.length > 0 ? `Plugins you can enable with core__enable_plugin:\n${lines.join('\n')}` : 'Every available plugin is enabled.';
        return redact(`<plugin-catalog>\n${body}\n</plugin-catalog>`);
    };
    const pluginText = (name, added) => {
        const plugin = pluginOf(name);
        const tools = (plugin.tools ?? []).map((tool) => ({ name: qualify(name, tool.name), tool }));
        const parts = [plugin.instructions, added];
        if (plugin.skills?.length) {
            parts.push(`Skills (load with core__load_skill):\n${plugin.skills.map((s) => `- ${name}__${s.name}: ${s.description}`).join('\n')}`);
        }
        if (tools.length > 0) {
            if (rules.late === 'declared' || isInitial(name))
                parts.push(`Tools: ${tools.map((t) => t.name).join(', ')}`);
            else
                parts.push(`${rules.heading}\n${tools.map((t) => `- ${t.name}: ${t.tool.description}\n  Parameters: ${JSON.stringify(t.tool.parameters)}`).join('\n')}`);
        }
        return redact(`<plugin name="${name}">\n${parts.filter((p) => p?.trim()).join('\n\n')}\n</plugin>`);
    };
    const parseName = (name) => {
        const parsed = catalog.pluginName(name);
        if (!parsed)
            throw new Error(`unknown plugin "${name}"`);
        return parsed;
    };
    const core = {
        name: CORE,
        description: 'Enables plugins and loads skills.',
        tools: [
            {
                name: 'enable_plugin',
                description: 'Enable a plugin from the catalog. Its tools and skills are usable from your next step.',
                parameters: {
                    type: 'object',
                    properties: { name: { type: 'string', description: 'Plugin name from the catalog' } },
                    required: ['name'],
                    additionalProperties: false,
                },
                async execute(args) {
                    const name = catalog.pluginName(String(args.name));
                    if (!name || !(catalog.listed.has(name) || byKind.enabled.has(name)))
                        return errorResult(`No plugin named "${String(args.name)}". Available: ${[...catalog.listed.keys()].join(', ')}.`);
                    const { added, text } = await enablePlugin(name, 'model');
                    if (added.length === 0)
                        return textResult(`${name} is already enabled.`);
                    return textResult(`Enabled ${added.join(', ')}. Usable from your next step.\n\n${text}`);
                },
            },
            {
                name: 'load_skill',
                description: 'Load the full text of a skill listed by an enabled plugin.',
                parameters: {
                    type: 'object',
                    properties: { name: { type: 'string', description: 'Skill name, <plugin>__<skill>' } },
                    required: ['name'],
                    additionalProperties: false,
                },
                async execute(args) {
                    const found = catalog.skills.get(String(args.name));
                    if (!found || !byKind.enabled.has(found.plugin))
                        return errorResult(`No skill named "${String(args.name)}" in an enabled plugin.`);
                    const text = redact(await found.skill.load());
                    append({ kind: 'skill', name: String(args.name) });
                    return textResult(text);
                },
            },
        ],
    };
    const codeTools = createCodeTools({
        timeoutMs: options.codeTimeoutMs,
        maxCalls: options.maxCodeCalls,
        callIdOf: (ctx) => toolContexts.get(ctx)?.callId,
        call: (id, name, raw, route, signal) => runCall(id, name, resolveTarget(name, raw, route), signal),
        commands: () => [...registry.values()].filter((e) => e.plugin === CORE || byKind.enabled.has(e.plugin)).map((e) => e.name),
        redact,
    });
    const registry = new Map([
        ...[...(core.tools ?? []), ...codeTools].map((tool) => [qualify(CORE, tool.name), { name: qualify(CORE, tool.name), plugin: CORE, tool }]),
        ...[...catalog.tools.values()].map((t) => [t.name, t]),
    ]);
    const activeEntry = (name) => {
        const entry = registry.get(name);
        if (entry?.name === RUN_CODE.name || entry?.name === RUN_BASH.name)
            return via?.name === entry.name ? entry : undefined;
        return entry && (entry.plugin === CORE || byKind.enabled.has(entry.plugin)) ? entry : undefined;
    };
    if (options.start.kind === 'resume')
        records.restore(options.start.records.map((value) => parseRecord(value, catalog, redact)));
    // A provider may repeat a call id across responses or put a "/" in one, and the engine nests ids at "/". So each
    // call gets its own id: the provider's with "/" escaped, plus "#<n>" when the session already used it.
    const callIds = new Set([...byKind.calls, ...byKind.delegations].map((r) => r.callId).concat([...byKind.denials.keys()]));
    const callIdFor = (provided) => {
        const base = provided.replaceAll('/', '%2F');
        let id = base;
        for (let n = 2; callIds.has(id); n++)
            id = `${base}#${n}`;
        callIds.add(id);
        return id;
    };
    const given = options.conversationId;
    if (given !== undefined && (typeof given !== 'string' || given === ''))
        throw new Error('conversationId must be a non-empty string');
    if (given !== undefined && byKind.conversation !== undefined && given !== byKind.conversation) {
        throw new Error(`the transcript belongs to conversation "${byKind.conversation}", not "${given}"`);
    }
    // A transcript from before conversation ids gets one on its first resume.
    if (byKind.conversation === undefined)
        append({ kind: 'conversation', id: given ?? randomUUID() });
    const conversationId = byKind.conversation;
    const conversation = conversationAttributes(conversationId);
    const pluginLog = (attributes, live) => {
        const at = (severity) => (line) => (live(), log(severity, line, attributes));
        return Object.assign(at('INFO'), { warn: at('WARN'), error: at('ERROR') });
    };
    /**
     * What a tool or hook of `plugin` gets. `attributes` name the plugin and the call or hook on its log records. Once
     * `lifetime` fires, `log` and `state.update` throw: the engine has stopped waiting, so nothing the plugin does after
     * may land beside its verdict, and the throw ends a hook that kept running past its timeout at its next write.
     */
    const contextFor = (plugin, signal, attributes, lifetime) => {
        const live = () => {
            if (lifetime?.aborted)
                throw new Error(`plugin "${plugin}" used the context of its ${attributes['aigent.hook']} hook after the hook ended`);
        };
        return {
            signal,
            log: pluginLog(attributes, live),
            secret: (name) => {
                if (!catalog.plugins.get(plugin)?.secrets?.includes(name))
                    throw new Error(`plugin "${plugin}" did not declare secret "${name}"`);
                return options.secrets[name];
            },
            state: {
                get: () => byKind.state.get(plugin),
                update: (next) => {
                    live();
                    const current = byKind.state.get(plugin);
                    const value = storableState(plugin, next(current), redact);
                    if (JSON.stringify(value) !== JSON.stringify(current))
                        append({ kind: 'state', plugin, value });
                },
            },
        };
    };
    const each = createHookRunner({ timeoutMs: options.hookTimeoutMs, contextFor: (p, signal, a) => contextFor(p, signal, a, signal), log, redact, spanAttributes: conversation, closing: closing.signal });
    const addedText = (results) => results.flatMap(({ settled }) => (settled.kind === 'ok' && typeof settled.value === 'string' && settled.value.trim() ? [settled.value] : []));
    /** A gate cut off by an abort gave no verdict, so it denies nothing. A reason is redacted, then capped. */
    async function runGates(call, signal, level) {
        const results = await each(activePlugins(), 'beforeToolCall', (h, ctx) => h.beforeToolCall(call, ctx), [closing.signal, signal], level);
        const denials = results.flatMap(({ plugin, settled }) => {
            if (settled.kind === 'aborted')
                return [];
            if (settled.kind === 'failed')
                return [{ plugin, reason: cut(redact(`gate failed: ${settled.reason}`), REASON_CAP) }];
            const verdict = settled.value;
            if (verdict === 'allow')
                return [];
            const deny = typeof verdict === 'object' && verdict !== null ? verdict.deny : undefined;
            return [{ plugin, reason: typeof deny === 'string' ? cut(redact(deny), REASON_CAP) : 'gate returned no verdict' }];
        });
        for (const d of denials)
            instruments().denials.add(1, { 'aigent.plugin': d.plugin });
        return denials;
    }
    /** `level` is undefined for this session's own call, else the level a helper's call reached it at. */
    async function gateCall(call, signal, level) {
        const [own, outer] = await Promise.all([runGates(call, signal, level), options.ancestors?.gate(call, signal, (level ?? 0) + 1) ?? []]);
        return { own, outer };
    }
    async function observeCall(event, level) {
        await Promise.all([each(activePlugins(), 'onToolResult', (h, ctx) => h.onToolResult(event, ctx), [closing.signal], level), options.ancestors?.observe(event, (level ?? 0) + 1)]);
    }
    function ancestorsFor(callId) {
        const lift = (call) => deepFreeze({ ...call, id: `${callId}/${call.id}` });
        return {
            gate: async (call, signal, level) => {
                const { own, outer } = await gateCall(lift(call), signal, level);
                return [...own.map((d) => ({ ...d, outer: level })), ...outer];
            },
            observe: (result, level) => observeCall(deepFreeze({ ...result, call: lift(result.call) }), level),
        };
    }
    /**
     * Commits the `enabled` records before the first await, so a racing enable sees the plugin enabled and adds
     * nothing. onEnable phases run through one promise chain so their text lands in enable order.
     */
    async function enablePlugin(name, cause) {
        const added = catalog.closures.get(name).filter((n) => !byKind.enabled.has(n));
        for (const n of added)
            append({ kind: 'enabled', plugin: n, cause: n === name ? cause : { dependencyOf: name } });
        if (added.length === 0)
            return { added, text: '' };
        const phase = hookPhase.then(async () => {
            const blocks = [];
            for (const n of added) {
                const snapshot = deepFreeze({ plugin: n, cause: byKind.enabled.get(n).cause, enabled: enabled() });
                const [extra] = addedText(await each([pluginOf(n)], 'onEnable', (h, ctx) => h.onEnable(snapshot, ctx)));
                blocks.push(pluginText(n, extra));
            }
            return blocks.join('\n\n');
        });
        hookPhase = phase.catch(() => { });
        return { added, text: await phase };
    }
    function resolve(call) {
        if (via === CALL_TOOL && call.name === CALL_TOOL.name)
            return resolveTarget(String(call.args.tool), call.args.args ?? {}, `through ${CALL_TOOL.name}`);
        const entry = activeEntry(call.name);
        if (!entry)
            return { kind: 'error', requested: call.name, result: errorResult(`Unknown tool "${call.name}".`), type: 'unknown_tool' };
        // The loop validated only what it declared, so a plugin tool this mode never declares is checked as a dispatched one.
        if (entry.plugin !== CORE && !declaresNatively(entry.plugin))
            return resolveTarget(call.name, call.args, 'directly');
        return { kind: 'ok', entry, args: call.args };
    }
    /** A plugin tool named by a call made through a core tool. `route` says how, as in "not through core__call_tool". */
    function resolveTarget(target, raw, route) {
        const unresolved = (type, text) => ({ kind: 'error', requested: target, result: errorResult(text), type });
        const entry = activeEntry(target);
        if (!entry)
            return unresolved('unknown_tool', `Unknown tool "${target}". Enable its plugin first.`);
        if (entry.plugin === CORE)
            return unresolved('invalid_arguments', `Call ${target} directly, not ${route}.`);
        const checked = typeof raw === 'object' && raw !== null && !Array.isArray(raw)
            ? validate(entry.tool.parameters, raw, target)
            : { ok: false, error: '"args" must be an object' };
        if (!checked.ok)
            return unresolved('invalid_arguments', `Invalid arguments for ${target}: ${checked.error}\nParameters: ${JSON.stringify(entry.tool.parameters)}`);
        return { kind: 'ok', entry, args: checked.args };
    }
    /** `failure` is set exactly when the result is an error. Its text is redacted, then capped. */
    async function execute(entry, args, callId, signal, span) {
        try {
            const attribution = { 'aigent.plugin': entry.plugin, 'gen_ai.tool.name': entry.name, 'gen_ai.tool.call.id': callId };
            const ctx = {
                ...contextFor(entry.plugin, signal, attribution),
                progress: (text) => {
                    log('DEBUG', text, attribution, { eventName: 'aigent.progress', span });
                    emit({ type: 'progress', plugin: entry.plugin, callId, text: redact(text), ...traceOf(span) });
                },
            };
            toolContexts.set(ctx, { callId, span });
            const raw = await entry.tool.execute(args, ctx);
            const result = parseResult(raw);
            if (!result)
                return { result: errorResult(`Tool ${entry.name} returned a malformed result.`), failure: 'malformed_result' };
            const content = capText(result.content.map((c) => (c.type === 'text' ? { type: 'text', text: redact(c.text) } : c)), options.maxToolResultChars);
            return result.isError ? { result: { content, isError: true }, failure: 'tool_error' } : { result: { content } };
        }
        catch (error) {
            return { result: { content: capText([{ type: 'text', text: redact(`Tool ${entry.name} failed: ${messageOf(error)}`) }], options.maxToolResultChars), isError: true }, failure: thrownType(error) };
        }
    }
    /**
     * Gates, executes, redacts and observes one resolved call. Never rejects. `requested` names an unresolved call's span.
     * The call belongs to the run it started in, so one that settles after its run ended lands in no later run's turns.
     */
    function runCall(id, requested, resolved, signal) {
        const owner = run;
        const name = resolved.kind === 'ok' ? resolved.entry.name : requested;
        const attributes = { 'gen_ai.operation.name': 'execute_tool', 'gen_ai.tool.name': name, 'gen_ai.tool.call.id': id, 'gen_ai.tool.type': 'function', ...conversation };
        return tracer.startActiveSpan(`execute_tool ${name}`, { kind: SpanKind.INTERNAL, attributes }, async (span) => {
            try {
                if (resolved.kind === 'error') {
                    fail(span.setAttribute('aigent.tool.outcome', 'error'), resolved.type);
                    // The name of a call that resolved to nothing is the model's to choose, so it stays off the metric.
                    instruments().toolCalls.add(1, { 'aigent.tool.outcome': 'error', 'error.type': resolved.type });
                    append({ kind: 'call', callId: id, requested: redact(resolved.requested).slice(0, REQUESTED_CAP), outcome: 'unresolved' });
                    return resolved.result;
                }
                const { entry, args } = resolved;
                span.setAttribute('aigent.plugin', entry.plugin);
                const snapshot = deepFreeze({
                    id,
                    name: entry.name,
                    plugin: entry.plugin,
                    tool: entry.tool.name,
                    args: structuredClone(args),
                });
                if (options.captureContent)
                    span.setAttribute('gen_ai.tool.call.arguments', captured(snapshot.args, redact));
                emit({ type: 'tool_start', call: snapshot, ...traceOf(span) });
                const { own, outer } = await gateCall(snapshot, signal);
                for (const d of own)
                    append({ kind: 'denied', callId: id, tool: entry.name, plugin: d.plugin, reason: d.reason });
                for (const d of outer)
                    append({ kind: 'denied', callId: id, tool: entry.name, plugin: d.plugin, reason: d.reason, outer: d.outer });
                const denials = [...own, ...outer].map(({ plugin, reason }) => ({ plugin, reason }));
                const aborted = [signal, closing.signal].find((s) => s.aborted);
                const { result, failure } = denials.length > 0
                    ? { result: errorResult(`Denied by ${denials.map((d) => `${d.plugin}: ${d.reason}`).join('; ')}`) }
                    : aborted
                        ? { result: errorResult(`Tool ${entry.name} was aborted before it ran.`), failure: thrownType(aborted.reason) }
                        : await execute(entry, snapshot.args, id, signal, span);
                const event = deepFreeze({ call: snapshot, outcome: denials.length > 0 ? { kind: 'denied', denials } : { kind: 'ran', result } });
                append({ kind: 'call', callId: id, tool: entry.name, outcome: denials.length > 0 ? 'denied' : result.isError ? 'error' : 'ran' });
                span.setAttribute('aigent.tool.outcome', event.outcome.kind);
                instruments().toolCalls.add(1, { 'aigent.tool.outcome': event.outcome.kind, 'aigent.plugin': entry.plugin, 'gen_ai.tool.name': name, ...(failure && { 'error.type': failure }) });
                if (event.outcome.kind === 'denied')
                    span.setAttributes({ 'aigent.denial.plugins': denials.map((d) => d.plugin), 'aigent.denial.outer': [...own.map(() => 0), ...outer.map((d) => d.outer)] });
                else if (failure)
                    fail(span, failure);
                else if (options.captureContent) {
                    const content = result.content.map((c) => (c.type === 'image' ? { type: 'image', mimeType: c.mimeType, bytes: decodedBytes(c.data) } : c));
                    span.setAttribute('gen_ai.tool.call.result', captured({ ...result, content }, redact));
                }
                owner.calls.push(event);
                await observeCall(event);
                emit({ type: 'tool_end', result: event, ...traceOf(span) });
                return result;
            }
            finally {
                span.end();
            }
        });
    }
    const queue = (text) => {
        if (text)
            append({ kind: 'pending', text });
    };
    const initialText = [];
    // Enabling a plugin the transcript enabled adds only the dependencies it gained since, so a new gate holds on resume.
    for (const name of [...enabled(), ...options.enabled.map(parseName)]) {
        const { text } = await enablePlugin(name, options.start.kind === 'fresh' ? 'initial' : 'host');
        if (options.start.kind === 'fresh')
            initialText.push(text);
        else
            queue(text);
    }
    let systemPrompt;
    if (options.start.kind === 'fresh') {
        systemPrompt = [redact(options.start.systemPrompt), catalogText(), ...initialText].filter((p) => p.trim()).join('\n\n');
        append({ kind: 'catalog', fingerprint: catalog.fingerprint });
    }
    return {
        systemPrompt,
        conversationId,
        previousRun() {
            return byKind.run && { traceId: byKind.run.traceId, spanId: byKind.run.spanId, traceFlags: byKind.run.traceFlags };
        },
        tools() {
            const declared = enabled().filter(declaresNatively);
            const coreSpecs = (core.tools ?? []).map((tool) => spec(qualify(CORE, tool.name), tool));
            const pluginSpecs = declared.flatMap((name) => (pluginOf(name).tools ?? []).map((tool) => spec(qualify(name, tool.name), tool)));
            return [...coreSpecs, ...(via ? [via] : []), ...pluginSpecs];
        },
        takeRecords() {
            return records.take();
        },
        async beginPrompt(text, signal) {
            if (closed())
                throw new Error('session is closed');
            run = { signal, turns: 0, last: undefined, stoppedBy: undefined, calls: [] };
            const span = trace.getActiveSpan()?.spanContext();
            if (span && isSpanContextValid(span))
                append({ kind: 'run', traceId: span.traceId, spanId: span.spanId, traceFlags: span.traceFlags });
            const parts = [redact(text), ...byKind.undelivered];
            if (byKind.undelivered.length > 0)
                append({ kind: 'delivered' });
            if (byKind.catalog.at(-1)?.fingerprint !== catalog.fingerprint) {
                parts.push(catalogText());
                append({ kind: 'catalog', fingerprint: catalog.fingerprint });
            }
            const snapshot = deepFreeze({ text: parts[0], enabled: enabled() });
            parts.push(...addedText(await each(activePlugins(), 'onUserPrompt', (h, ctx) => h.onUserPrompt(snapshot, ctx))).map(redact));
            return parts.join('\n\n');
        },
        async callTool(call, signal) {
            if (closed())
                return errorResult('The session is closed.');
            return runCall(callIdFor(call.id), call.name, resolve(call), signal);
        },
        async undeclaredCall({ id, name }) {
            if (closed())
                return;
            await runCall(callIdFor(id), name, { kind: 'error', requested: name, result: errorResult(`Unknown tool "${name}".`), type: 'unknown_tool' }, run.signal);
        },
        observeUsage({ input, output, cacheRead, cacheWrite }) {
            append({ kind: 'usage', input, output, cacheRead, cacheWrite });
        },
        async endTurn(turn) {
            run.turns += 1;
            run.last = turn.kind === 'ok' ? { kind: 'ok', text: redact(turn.text) } : turn.kind === 'error' ? { kind: 'error', message: redact(turn.message) } : turn;
            const snapshot = deepFreeze({ turn: run.turns, text: run.last.kind === 'ok' ? run.last.text : '', calls: run.calls });
            run.calls = [];
            await each(activePlugins(), 'onTurnEnd', (h, ctx) => h.onTurnEnd(snapshot, ctx));
            // The adapter's invoke_agent span is active for the whole run.
            emit({ type: 'turn_end', turn: snapshot, ...traceOf() });
            for (const condition of stopConditions) {
                const reason = condition(run, options.maxTurns);
                if (reason) {
                    run.stoppedBy = reason;
                    return 'stop';
                }
            }
            return 'continue';
        },
        endRun() {
            return runOutcome(run);
        },
        async enable(name) {
            if (closed())
                throw new Error('session is closed');
            queue((await enablePlugin(parseName(name), 'host')).text);
        },
        redact,
        close() {
            ended ??= (async () => {
                closing.abort(new Error('session closed'));
                // The close signal has already fired, so onSessionEnd runs under its timeout alone.
                // One usage record per model request, restored ones included, so the count spans every process that ran the session.
                const snapshot = deepFreeze({ turns: byKind.usage.length, enabled: enabled() });
                await each(activePlugins(), 'onSessionEnd', (h, ctx) => h.onSessionEnd(snapshot, ctx), []);
            })();
            return ended;
        },
    };
}
/** Abort first: an aborted run reports aborted even when it also hit max turns on the same turn. */
const stopConditions = [
    (run) => (run.signal.aborted ? 'aborted' : undefined),
    (run, maxTurns) => (run.turns >= maxTurns ? 'max_turns' : undefined),
];
function runOutcome({ turns, last, stoppedBy }) {
    if (stoppedBy === 'aborted' || last?.kind === 'aborted')
        return { stop: 'aborted', turns };
    if (last?.kind === 'error')
        return { stop: 'error', message: last.message, turns };
    const text = last?.kind === 'ok' ? last.text : '';
    return stoppedBy === 'max_turns' ? { stop: 'max_turns', text, turns } : { stop: 'done', text, turns };
}
/** A model can send any string as a tool name, so the history keeps only its start. */
const REQUESTED_CAP = 200;
/** A gate's reason goes into its record, the result the model reads and `session__inspect`, once per denial. */
const REASON_CAP = 1_000;
function cut(text, cap) {
    return text.length > cap ? `${text.slice(0, cap)}…[truncated ${text.length - cap} characters]` : text;
}
/** Plugin output is untrusted shape-wise; a JS plugin can return anything. */
function parseResult(value) {
    if (typeof value !== 'object' || value === null)
        return undefined;
    const { content, isError } = value;
    if (!Array.isArray(content))
        return undefined;
    const blocks = [];
    for (const c of content) {
        const block = c;
        if (block?.type === 'text' && typeof block.text === 'string')
            blocks.push({ type: 'text', text: block.text });
        else if (block?.type === 'image' && typeof block.data === 'string' && typeof block.mimeType === 'string') {
            blocks.push({ type: 'image', data: block.data, mimeType: block.mimeType });
        }
        else
            return undefined;
    }
    return { content: blocks, isError: isError === true };
}
/** Keeps the first `cap` text characters across the blocks, images untouched, and says how many it left out. */
function capText(content, cap) {
    const total = content.reduce((n, c) => n + (c.type === 'text' ? c.text.length : 0), 0);
    if (total <= cap)
        return [...content];
    let left = cap;
    const kept = content.flatMap((c) => {
        if (c.type !== 'text')
            return [c];
        const text = c.text.slice(0, Math.max(0, left));
        left -= c.text.length;
        return text ? [{ type: 'text', text }] : [];
    });
    return [...kept, { type: 'text', text: `…[truncated ${total - cap} characters]` }];
}
function spec(name, tool) {
    return { name, description: tool.description, parameters: tool.parameters };
}
function textResult(text) {
    return { content: [{ type: 'text', text }] };
}
function errorResult(text) {
    return { content: [{ type: 'text', text }], isError: true };
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error);
}
function deepFreeze(value) {
    if (typeof value === 'object' && value !== null && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const child of Object.values(value))
            deepFreeze(child);
    }
    return value;
}
