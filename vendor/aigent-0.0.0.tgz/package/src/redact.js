// Secret redaction, shared by the engine and the host entry. Imports nothing.
/** Known secret values become `[REDACTED:NAME]`, longest first so a secret containing another is replaced whole. */
export function redactor(secrets) {
    const entries = Object.entries(secrets)
        .filter(([, value]) => value.length > 0)
        .sort(([, a], [, b]) => b.length - a.length);
    return (text) => entries.reduce((out, [name, value]) => out.split(value).join(`[REDACTED:${name}]`), text);
}
/**
 * A copy of a JSON-shaped value with `redact` applied to every string and every object key. Anything else, a
 * non-plain object included, comes back as it is. A key that redacts to a name its object already holds takes the
 * next free `<name>_<n>`, so no value drops out.
 */
export function redactJson(value, redact) {
    if (typeof value === 'string')
        return redact(value);
    if (Array.isArray(value))
        return value.map((v) => redactJson(v, redact));
    const proto = typeof value === 'object' && value !== null ? Object.getPrototypeOf(value) : undefined;
    if (proto !== Object.prototype && proto !== null)
        return value;
    const object = value;
    const keys = Object.keys(object);
    const redacted = keys.map((key) => redact(key));
    const taken = new Set(keys.filter((key, i) => redacted[i] === key));
    return Object.fromEntries(keys.map((key, i) => {
        let name = redacted[i];
        if (name !== key) {
            for (let n = 2; taken.has(name); n++)
                name = `${redacted[i]}_${n}`;
            taken.add(name);
        }
        return [name, redactJson(object[key], redact)];
    }));
}
