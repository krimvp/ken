/** The worker's `workerData`: the QuickJS WASM module, compiled once by the main thread. */
export interface Job {
    readonly wasmModule: object;
}
export type ToWorker = {
    readonly kind: 'run';
    readonly code: string;
} | {
    readonly kind: 'settle';
    readonly id: number;
    readonly ok: boolean;
    readonly text: string;
};
export type FromWorker = {
    readonly kind: 'call';
    readonly id: number;
    readonly name: string;
    readonly args: unknown;
} | {
    readonly kind: 'started';
} | {
    readonly kind: 'log';
    readonly text: string;
} | {
    readonly kind: 'returned';
    readonly value?: string;
} | {
    readonly kind: 'threw';
    readonly error: string;
};
