import type { PluginName } from './catalog.ts';
import type { Hooks, MaybePromise, Plugin, PluginContext } from './plugin.ts';
import type { Severity } from './session.ts';
import { type ErrorType } from './tracing.ts';
/** `aborted`: one of the caller's signals fired first. That is neither a verdict nor a failure of the hook. */
export type Settled<T> = {
    readonly kind: 'ok';
    readonly value: T;
} | {
    readonly kind: 'failed';
    readonly reason: string;
    readonly type: ErrorType;
} | {
    readonly kind: 'aborted';
};
/**
 * Calls one hook under the timeout, never rejecting. The hook's signal is its lifetime: it fires on timeout, on any
 * of `extra`, or once the hook has settled, whichever comes first.
 */
export declare function settle<T>(call: (signal: AbortSignal) => MaybePromise<T>, timeoutMs: number, extra: readonly AbortSignal[]): Promise<Settled<T>>;
export interface HookRunnerOptions {
    readonly timeoutMs: number;
    /** What a hook of `plugin` gets. `signal` is the hook's lifetime. `attributes` name the plugin and the hook on its log records. */
    readonly contextFor: (plugin: PluginName, signal: AbortSignal, attributes: Readonly<Record<string, string>>) => PluginContext;
    /** Gets each failure's text unredacted. */
    readonly log: (severity: Severity, body: string, attributes: Readonly<Record<string, string>>) => void;
    readonly redact: (text: string) => string;
    /** On every hook span. */
    readonly spanAttributes: Readonly<Record<string, string>>;
    /** Fires every hook's signal when a caller passes no signals of its own. */
    readonly closing: AbortSignal;
}
/**
 * Runs one hook across the plugins that define it, concurrently, returning results in plugin order, and logs each
 * failure inside its hook span. `extra` fire the hook's signal. `level` is set when a helper's call runs them.
 */
export type RunHook = <T>(plugins: readonly Plugin[], hook: keyof Hooks, invoke: (hooks: Hooks, ctx: PluginContext) => MaybePromise<T>, extra?: readonly AbortSignal[], level?: number) => Promise<{
    readonly plugin: PluginName;
    readonly settled: Settled<T>;
}[]>;
export declare function createHookRunner({ timeoutMs, contextFor, log, redact, spanAttributes, closing }: HookRunnerOptions): RunHook;
