/** One tool call the code makes. `ok` false makes the call throw `Error(text)` in the code. */
export type HostCall = (name: string, args: unknown) => Promise<{
    readonly ok: boolean;
    readonly text: string;
}>;
export type CodeOutcome = 
/** `value` is the JSON text of the returned value, absent for undefined. */
{
    readonly kind: 'returned';
    readonly output: string;
    readonly value?: string;
} | {
    readonly kind: 'threw';
    readonly output: string;
    readonly error: string;
};
interface RunOptions {
    readonly signal: AbortSignal;
    readonly timeoutMs: number;
}
/**
 * Runs `code` as the body of an async function, in QuickJS on a worker thread of its own, so the host's event loop
 * keeps running. The deadline, which starts when the VM starts the code, and the abort end the thread. Every call
 * the code started has settled when this resolves, except one still running GRACE_MS past the deadline or the
 * abort, which is left running. Rejects only when QuickJS itself fails, or fails to start.
 */
export declare function runCode(code: string, call: HostCall, options: RunOptions): Promise<CodeOutcome>;
/**
 * Runs `script` in just-bash, a simulated bash with an in-memory filesystem and no network, host files or host
 * environment. Each name in `commands` becomes a command that takes one JSON object argument and calls the host:
 * its text goes to stdout, or to stderr with exit code 1 when `ok` is false. just-bash is an optional peer
 * dependency, loaded on the first run. Every call the script started has settled when this resolves, except one
 * still running GRACE_MS past the deadline or the abort, which is left running.
 */
export declare function runBash(script: string, call: HostCall, options: RunOptions & {
    readonly commands: readonly string[];
}): Promise<CodeOutcome>;
export {};
