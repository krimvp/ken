// What one model request cost in tokens, and the sums over many. The one definition of prompt tokens and cached ratio.
/** Every token the request sent. */
export function promptTokens(usage) {
    return usage.input + usage.cacheRead + usage.cacheWrite;
}
export function totalUsage(requests) {
    return requests.reduce((a, b) => ({ input: a.input + b.input, output: a.output + b.output, cacheRead: a.cacheRead + b.cacheRead, cacheWrite: a.cacheWrite + b.cacheWrite }), {
        input: 0,
        output: 0,
        cacheRead: 0,
        cacheWrite: 0,
    });
}
/** The share of the requests' prompt tokens served from cache. Undefined when they sent none, since there was nothing to cache. */
export function cachedRatio(requests) {
    const total = totalUsage(requests);
    const prompt = promptTokens(total);
    return prompt > 0 ? total.cacheRead / prompt : undefined;
}
