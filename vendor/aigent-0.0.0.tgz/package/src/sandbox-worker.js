// The worker thread that runs one `runCode` call in a QuickJS VM of its own. It readies the VM before the code
// arrives. The main thread owns the deadline and the abort and ends this thread to enforce them, so nothing here
// stops the code or frees the VM.
import releaseSync from '@jitl/quickjs-wasmfile-release-sync';
import { newQuickJSWASMModuleFromVariant, newVariant } from 'quickjs-emscripten-core';
import { parentPort, workerData } from 'node:worker_threads';
// The package's types describe its CommonJS build, so TypeScript reads the ESM default export as the module.
const variant = releaseSync;
/**
 * The cap on the WASM linear memory, which holds the whole VM. QuickJS's own memory limit undercounts in this build,
 * so this is the limit that holds: an allocation past it throws `InternalError: out of memory` in the code.
 */
const MEMORY_LIMIT = 64 * 1024 * 1024;
const PAGE = 64 * 1024;
const STACK_LIMIT = 256 * 1024;
/** Characters of printed output, of the returned value's JSON and of the error text that leave the worker. */
const TEXT_LIMIT = 64 * 1024;
const cut = (head, length) => (length > TEXT_LIMIT ? `${head.slice(0, TEXT_LIMIT)}…[truncated ${length - TEXT_LIMIT} characters]` : head);
/**
 * Called with the host's call and log functions and the code. Returns a promise of the return value's JSON text,
 * which rejects with the thrown value's text.
 */
const PRELUDE = `(function (call, write, code) {
  const describe = (thrown) => {
    try {
      if (typeof thrown === 'object' && thrown !== null && 'message' in thrown) {
        const { name, message } = thrown
        return name === 'Error' || typeof name !== 'string' ? String(message) : name + ': ' + String(message)
      }
      return typeof thrown === 'string' ? thrown : JSON.stringify(thrown) ?? String(thrown)
    } catch {
      return 'the code threw a value that cannot be shown'
    }
  }
  const show = (value) => {
    if (typeof value === 'string') return value
    if (value instanceof Error) return value.name + ': ' + value.message
    try {
      const json = JSON.stringify(value)
      return json === undefined ? String(value) : json
    } catch {
      return String(value)
    }
  }
  const line = (...values) => write(values.map(show).join(' '))
  globalThis.console = { log: line, info: line, warn: line, error: line }
  const json = (args) => {
    const text = JSON.stringify(args === undefined ? {} : args)
    if (text === undefined) throw new TypeError('tool arguments must be JSON')
    return text
  }
  globalThis.tools = new Proxy({}, { get: (_, name) => (typeof name === 'string' ? async (args) => call(name, json(args)) : undefined) })
  const AsyncFunction = (async () => {}).constructor
  return (async () => new AsyncFunction(code)())()
    .then((value) => (value === undefined ? undefined : JSON.stringify(value)))
    .then(undefined, (error) => Promise.reject(describe(error)))
})`;
const port = parentPort;
const post = (message) => port.postMessage(message);
const { wasmModule } = workerData;
const wasmMemory = new WebAssembly.Memory({ initial: (16 * 1024 * 1024) / PAGE, maximum: MEMORY_LIMIT / PAGE });
const quickjs = await newQuickJSWASMModuleFromVariant(newVariant(variant, { wasmModule, wasmMemory }));
const runtime = quickjs.newRuntime();
runtime.setMaxStackSize(STACK_LIMIT);
const vm = runtime.newContext();
const pump = () => {
    const jobs = runtime.executePendingJobs();
    if (jobs.error)
        jobs.error.dispose();
};
const slice = vm.unwrapResult(vm.evalCode('String.prototype.slice'));
/** A VM value as text, at most TEXT_LIMIT characters plus a note. A long string is cut inside the VM, before the copy. */
const text = (handle) => {
    if (vm.typeof(handle) !== 'string') {
        const shown = vm.getString(handle);
        return cut(shown, shown.length);
    }
    const length = vm.getProp(handle, 'length').consume((h) => vm.getNumber(h));
    if (length <= TEXT_LIMIT)
        return vm.getString(handle);
    return vm.unwrapResult(vm.callFunction(slice, handle, vm.newNumber(0), vm.newNumber(TEXT_LIMIT))).consume((head) => cut(vm.getString(head), length));
};
const pending = new Map();
const callFn = vm.newFunction('call', (nameHandle, argsHandle) => {
    const id = pending.size;
    const deferred = vm.newPromise();
    pending.set(id, (ok, text) => {
        const value = ok ? vm.newString(text) : vm.newError(text);
        if (ok)
            deferred.resolve(value);
        else
            deferred.reject(value);
        pump();
    });
    post({ kind: 'call', id, name: vm.getString(nameHandle), args: JSON.parse(vm.getString(argsHandle)) });
    return deferred.handle;
});
/** Characters of output still allowed, each line counting its newline, or -1 once output was cut. */
let left = TEXT_LIMIT;
const writeFn = vm.newFunction('write', (handle) => {
    if (left < 0)
        return;
    const line = text(handle);
    if (line.length <= left) {
        post({ kind: 'log', text: line });
        left = Math.max(0, left - line.length - 1);
    }
    else {
        post({ kind: 'log', text: `${line.slice(0, left)}\n[output truncated at ${TEXT_LIMIT} characters]` });
        left = -1;
    }
});
const prelude = vm.unwrapResult(vm.evalCode(PRELUDE));
async function run(code) {
    const started = vm.callFunction(prelude, vm.undefined, callFn, writeFn, vm.newString(code));
    if (started.error)
        return { kind: 'threw', error: text(started.error) };
    // Settling must be observed before the jobs run, or a promise that is already rejected never reports.
    const settled = vm.resolvePromise(started.value);
    pump();
    const result = await settled;
    if (result.error)
        return { kind: 'threw', error: text(result.error) };
    return vm.typeof(result.value) === 'string' ? { kind: 'returned', value: text(result.value) } : { kind: 'returned' };
}
port.on('message', (message) => {
    if (message.kind === 'run') {
        post({ kind: 'started' });
        void run(message.code).then(post);
    }
    else
        pending.get(message.id)?.(message.ok, message.text);
});
