import { type SpanContext } from '@opentelemetry/api';
import { type ToolSpec } from './core-tools.ts';
import { type DelegatePort } from './delegate.ts';
import type { JsonObject, JsonSchema, Plugin, ToolCallSnapshot, ToolResult, ToolResultSnapshot } from './plugin.ts';
import type { EngineRecord, LogRecord, RunResult, SessionEvent, ToolMode, Transcript } from './session.ts';
import { type Usage } from './usage.ts';
/** A call as the loop hands it over. For a declared tool, `args` already passed validation. The engine checks any other plugin tool's. */
export interface ToolCall {
    /** The provider's. The engine gives the call its own id, unique in the session, so this one may repeat. */
    readonly id: string;
    readonly name: string;
    readonly args: JsonObject;
}
/** One completed model turn, as the loop saw it. */
export type Turn = {
    readonly kind: 'ok';
    readonly text: string;
} | {
    readonly kind: 'error';
    readonly message: string;
} | {
    readonly kind: 'aborted';
};
/** Validates and coerces `args` against `schema`, as the loop does for declared tools. */
export type Validate = (schema: JsonSchema, args: JsonObject, tool: string) => {
    readonly ok: true;
    readonly args: JsonObject;
} | {
    readonly ok: false;
    readonly error: string;
};
export interface EngineOptions {
    /** The host's plugins. The engine adds its own `core`, `session` and `delegate`, and only the host can enable the last two. */
    readonly plugins: readonly Plugin[];
    /** The model as the loop resolved it. */
    readonly model: {
        readonly id: string;
        readonly provider: string;
        readonly contextWindow: number;
        readonly maxOutputTokens: number;
    };
    readonly toolMode: ToolMode;
    /** Fresh sessions build a system prompt. Resumed ones replay the records a transcript carried, running no hooks. */
    readonly start: {
        readonly kind: 'fresh';
        readonly systemPrompt: string;
    } | {
        readonly kind: 'resume';
        readonly records: readonly unknown[];
    };
    /** Enabled at creation. On resume, each is delivered like a host enable, and so is any dependency a plugin the transcript enabled gained since. */
    readonly enabled: readonly string[];
    readonly secrets: Readonly<Record<string, string>>;
    readonly maxTurns: number;
    readonly hookTimeoutMs: number;
    /** Per `core__run_code` call, its tool calls included. */
    readonly codeTimeoutMs: number;
    /** Tool calls per `core__run_code` or `core__run_bash` call. */
    readonly maxCodeCalls: number;
    /** The most text characters one tool result keeps, counted after redaction. */
    readonly maxToolResultChars: number;
    readonly validate: Validate;
    /** Puts each call's arguments and successful result, redacted and capped, on its `execute_tool` span. Default off. */
    readonly captureContent?: boolean;
    readonly emit: (event: SessionEvent) => void;
    readonly log: (record: LogRecord) => void;
    /** Builds the `delegate` plugin. Absent, there is none, so naming it in `enabled` throws like any unknown name. */
    readonly delegation?: {
        readonly profiles: DelegatePort['profiles'];
        readonly spawn: Spawn;
    };
    /** Present in a helper. Every call of this session is also gated and observed by these. */
    readonly ancestors?: Ancestors;
    /** The host's. A resume keeps the stored one and throws on a different one. */
    readonly conversationId?: string;
}
export interface SpawnRequest {
    /** The `delegate__run` call that opens the helper. */
    readonly callId: string;
    readonly profile: string;
    readonly task: string;
    /** The call's run signal composed with this session's close, so a close reaches the helper. */
    readonly signal: AbortSignal;
    /** Each helper event, which this session hands its host inside a `delegated` event. */
    readonly forward: (event: SessionEvent) => void;
    /** Hand to the helper engine as its `ancestors`. */
    readonly ancestors: Ancestors;
    /** This session's, which the helper's spans carry too. */
    readonly conversationId: string;
}
export interface HelperOutcome {
    /** A helper that could not start ends `error` with 0 turns. */
    readonly result: RunResult;
    /** The helper's requests plus every request of the helpers below it. */
    readonly requests: number;
    readonly usage: Usage;
    /** Redacted. Without messages when the helper never started. */
    readonly transcript: Transcript;
}
/** Opens one helper, prompts it and closes it. Never rejects. The adapter implements it, so the engine never imports pi. */
export type Spawn = (request: SpawnRequest) => Promise<HelperOutcome>;
/** A delegating session's gate denied a helper's call. `outer` counts levels up, 1 for the session that delegated. */
export interface OuterDenial {
    readonly plugin: string;
    readonly reason: string;
    readonly outer: number;
}
/**
 * Every delegating session's tool-call hooks, which a helper runs for each of its own calls, so to those sessions'
 * plugins the call is one of theirs. Only gates and result observers chain. Called only while the delegating call
 * is in flight. Neither function rejects. `level` is the level of the session that runs its hooks, 1 for the
 * session that delegated, and each session passes `level + 1` to its own ancestors. A denial's `outer` is that level.
 */
export interface Ancestors {
    gate(call: ToolCallSnapshot, signal: AbortSignal, level: number): Promise<readonly OuterDenial[]>;
    observe(result: ToolResultSnapshot, level: number): Promise<void>;
}
/**
 * The port. Per prompt a loop calls: beginPrompt, then per model request tools(), observeUsage once its message
 * ends, callTool* and endTurn, then takeRecords to append new records to its transcript; endRun once the run stops.
 * `enable` may be called at any time, including mid-run.
 */
export interface Engine {
    /** The leading system prompt of a fresh session. Undefined on resume, where the transcript already has one. */
    readonly systemPrompt: string | undefined;
    readonly conversationId: string;
    /** The `invoke_agent` span the last run recorded, for the next run to link to. */
    previousRun(): SpanContext | undefined;
    /** Declarations for the next request, in stable order. */
    tools(): readonly ToolSpec[];
    /** Records appended since the last call, each plugin's state record but its last left out. */
    takeRecords(): readonly EngineRecord[];
    /**
     * Starts a run and returns the user message text: the prompt, then queued enable text, catalog drift and
     * onUserPrompt text. Records the active span, the loop's `invoke_agent`, as the run's.
     */
    beginPrompt(text: string, signal: AbortSignal): Promise<string>;
    /** One model request's tokens, before its tool calls run. Every message the model ends counts, errors and aborts included. */
    observeUsage(usage: Usage): void;
    /** Resolve, unwrap, gate, execute, redact, observe. Never rejects. Once the session is closed, an error result and nothing runs. */
    callTool(call: ToolCall, signal: AbortSignal): Promise<ToolResult>;
    /** A call the loop answered itself because it declared no tool by that name. Recorded and traced as unresolved; nothing runs. Never rejects. */
    undeclaredCall(call: Pick<ToolCall, 'id' | 'name'>): Promise<void>;
    /** Runs onTurnEnd observers, then the stop conditions. */
    endTurn(turn: Turn): Promise<'continue' | 'stop'>;
    endRun(): RunResult;
    /** Host enable. Rejects on an unknown name and once the session is closed. */
    enable(name: string): Promise<void>;
    redact(text: string): string;
    /** Fires onSessionEnd once. Later prompts and enables reject. */
    close(): Promise<void>;
}
export declare function createEngine(options: EngineOptions): Promise<Engine>;
