import { type StreamFn } from '@earendil-works/pi-agent-core';
import { type Api, type Model } from '@earendil-works/pi-ai';
import { type Ancestors } from './engine.ts';
import type { Plugin } from './plugin.ts';
import { type EngineRecord, type LogRecord, type ModelSpec, type Session, type SessionOptions } from './session.ts';
/** Engine records ride in pi's transcript under their own role; convertToLlm drops them. */
interface RecordMessage {
    readonly role: 'aigent';
    readonly record: EngineRecord;
    readonly timestamp: number;
}
declare module '@earendil-works/pi-agent-core' {
    interface CustomAgentMessages {
        aigent: RecordMessage;
    }
}
export interface ResolvedModel {
    readonly model: Model<Api>;
    readonly streamFn: StreamFn;
    /** The model's API key under its env var name, so it is redacted like any host secret. */
    readonly secrets: Readonly<Record<string, string>>;
}
/** The one way a session gets a model. `createSession` passes `resolveModel`. The offline tests pass pi's faux provider. */
export type ResolveModel = (spec: ModelSpec) => Promise<ResolvedModel>;
export declare function createSession(options: SessionOptions): Promise<Session>;
/** `delegate` as parsed when the root session is created, and shared by every helper below it. */
interface DelegateTree {
    readonly maxDepth: number;
    readonly profiles: ReadonlyMap<string, Profile>;
    /** The host's secrets and every resolved model key, so every redactor in the tree knows every secret. */
    readonly secrets: Readonly<Record<string, string>>;
    readonly hookTimeoutMs: number;
    readonly maxToolResultChars: number;
    readonly captureContent: boolean;
    readonly log: (record: LogRecord) => void;
}
interface Profile {
    readonly description: string;
    readonly plugins: () => readonly Plugin[];
    readonly model: ModelSpec;
    readonly resolved: ResolvedModel;
    readonly maxTurns: number;
    readonly systemPrompt: string;
}
/** What a helper session inherits. Internal: `SessionOptions` carries no depth or gate chain. */
interface Lineage {
    /** 1 for a helper of the host's own session. */
    readonly depth: number;
    readonly profile: string;
    /** The `delegate__run` call that opened the helper. */
    readonly callId: string;
    readonly ancestors: Ancestors;
    readonly tree: DelegateTree;
}
/** `lineage` is set only when `spawnPort` opens a helper. */
export declare function startSession(options: SessionOptions, resolve: ResolveModel, lineage?: Lineage): Promise<Session>;
/** The longest delay Node's timers hold. Past it, a timer fires after 1 ms, and `AbortSignal.timeout` needs whole ms. */
export declare const MAX_TIMEOUT_MS: number;
export {};
