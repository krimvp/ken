import type { PluginName } from './catalog.ts';
import type { JsonValue, Plugin, ToolCallSnapshot, ToolResultSnapshot, TurnSnapshot } from './plugin.ts';
import type { Usage } from './usage.ts';
/** The engine's only state. Entries ride in the transcript, so a resumed session rebuilds the same engine. */
export type EngineRecord = 
/** The session's `gen_ai.conversation.id`. One per transcript, written when the session first starts. */
{
    readonly kind: 'conversation';
    readonly id: string;
}
/** The `invoke_agent` span of a run, which the next run links to. Written only when an SDK records the span. */
 | {
    readonly kind: 'run';
    readonly traceId: string;
    readonly spanId: string;
    readonly traceFlags: number;
} | {
    readonly kind: 'enabled';
    readonly plugin: PluginName;
    readonly cause: 'initial' | 'host' | 'model' | {
        readonly dependencyOf: PluginName;
    };
}
/** A gate of this session denied. */
 | {
    readonly kind: 'denied';
    readonly callId: string;
    readonly tool: string;
    readonly plugin: PluginName;
    readonly reason: string;
    readonly outer?: never;
}
/**
 * A gate of a delegating session denied one of this helper's calls. `outer` counts levels up, 1 for the session
 * that delegated. `plugin` is a name in that session's plugin set, so a resume never checks it.
 */
 | {
    readonly kind: 'denied';
    readonly callId: string;
    readonly tool: string;
    readonly plugin: string;
    readonly reason: string;
    readonly outer: number;
}
/** What the model was last told about the plugin set. Drives catalog drift detection on resume. */
 | {
    readonly kind: 'catalog';
    readonly fingerprint: string;
}
/** Redacted enable text waiting for the next user message. */
 | {
    readonly kind: 'pending';
    readonly text: string;
}
/** The next user message carried every `pending` text before it. */
 | {
    readonly kind: 'delivered';
}
/** A plugin's state in this session. The last record per plugin wins. */
 | {
    readonly kind: 'state';
    readonly plugin: PluginName;
    readonly value: JsonValue;
}
/**
 * One per tool call, once it finished. `tool` is the resolved `<plugin>__<tool>`. Names are not checked on resume,
 * so a smaller plugin set still resumes.
 */
 | {
    readonly kind: 'call';
    readonly callId: string;
    readonly tool: string;
    readonly requested?: never;
    readonly outcome: 'ran' | 'error' | 'denied';
}
/** A call that never resolved to a tool: an unknown name or dispatch arguments that failed. `requested` is redacted and capped. */
 | {
    readonly kind: 'call';
    readonly callId: string;
    readonly requested: string;
    readonly tool?: never;
    readonly outcome: 'unresolved';
}
/** One per model request, in request order, written before that request's tool calls run. */
 | ({
    readonly kind: 'usage';
} & Usage)
/** A successful `core__load_skill` of `<plugin>__<skill>`. */
 | {
    readonly kind: 'skill';
    readonly name: string;
}
/**
 * One per finished `delegate__run`, before that call's `call` record. The usage is the helper's requests plus every
 * request of the helpers below it, so summing these never counts a request twice. `profile` is a plain string, so
 * a resume with other profiles still rebuilds.
 */
 | ({
    readonly kind: 'delegation';
    readonly callId: string;
    readonly profile: string;
    readonly outcome: RunResult['stop'];
    readonly turns: number;
    readonly requests: number;
} & Usage);
/** The shortest secret value a session and an eval run accept. */
export declare const MIN_SECRET_LENGTH = 8;
export type ModelSpec = 
/** A model from pi's built-in catalog, authenticated the way that provider usually is. */
{
    readonly kind: 'builtin';
    readonly provider: string;
    readonly id: string;
}
/** Any OpenAI-compatible chat-completions endpoint, such as Ollama Cloud at https://ollama.com/v1. */
 | {
    readonly kind: 'openai-compatible';
    readonly baseUrl: string;
    readonly id: string;
    /** Env var holding the API key. Its value is redacted everywhere. */
    readonly apiKeyEnv: string;
    readonly reasoning?: boolean;
    readonly contextWindow?: number;
    readonly maxTokens?: number;
    /** Sent with every request. A parameter left out is not sent, so the server's default applies. */
    readonly sampling?: Sampling;
};
export interface Sampling {
    readonly temperature?: number;
    /** Servers that support it, such as vLLM and llama.cpp, sample the same way for the same seed and request. */
    readonly seed?: number;
}
/**
 * `native` declares every enabled tool with its schema, so each enable changes the request's tool list.
 * `dispatch` keeps the declared list fixed and reaches later-enabled tools through `core__call_tool`.
 * `programmatic` keeps the declared list fixed and reaches later-enabled tools from JavaScript the model runs with
 * `core__run_code`, which gets back only what the code prints and returns.
 * `bash` is the same with a bash script the model runs with `core__run_bash`, where each tool is a command.
 */
export type ToolMode = 'native' | 'dispatch' | 'programmatic' | 'bash';
/** JSON-serializable and redacted. Persist it and pass it back to resume. */
export interface Transcript {
    readonly format: 'aigent-transcript/1';
    readonly messages: readonly JsonValue[];
}
export interface DelegateProfile {
    /** One line. The model reads it in the description of `delegate__run`. */
    readonly description: string;
    /**
     * Called once per delegation, so each helper gets its own plugin objects, such as its own sandbox. Every plugin it
     * returns is enabled when the helper starts, and a declared secret comes from this session's `secrets`. A factory
     * that throws, or plugins that do not parse, make that delegation an error result.
     */
    readonly plugins: () => readonly Plugin[];
    /** Default: this session's model. Resolved when the session is created, so a missing key fails creation. */
    readonly model?: ModelSpec;
    /** Model turns per delegation. Default 10. */
    readonly maxTurns?: number;
    /** Default: a short prompt that asks the helper for the result alone. */
    readonly systemPrompt?: string;
}
export interface DelegateOptions {
    /** Levels of helpers below this session. Default 1, so a helper cannot delegate again. */
    readonly maxDepth?: number;
    /** Names match `[a-z0-9-]+`. At least one. */
    readonly profiles: Readonly<Record<string, DelegateProfile>>;
}
interface CommonOptions {
    readonly model: ModelSpec;
    /** Every plugin the session may enable. */
    readonly plugins: readonly Plugin[];
    /** Enabled at start with their dependencies. On resume, names already enabled are skipped. */
    readonly enabled?: readonly string[];
    /** Default `dispatch`. */
    readonly toolMode?: ToolMode;
    /**
     * NAME to value. Each value becomes `[REDACTED:NAME]` wherever it occurs, so a non-empty value under
     * MIN_SECRET_LENGTH characters is refused: it would rewrite ordinary words. An empty value is never redacted. The
     * model API key is added automatically and checked the same way.
     */
    readonly secrets?: Readonly<Record<string, string>>;
    /** Model turns per `prompt()`, a positive integer. Default 25. */
    readonly maxTurns?: number;
    /**
     * Per hook call, in whole ms from 1 to 2147483647, the longest delay Node's timers hold. A gate past it denies; any
     * other hook past it is ignored. Default 10000.
     */
    readonly hookTimeoutMs?: number;
    /**
     * Per code tool call, its tool calls included, in whole ms from 1 to 2147483647. Code past it stops with a timeout
     * error, at most 1000 ms later when a tool call ignores its abort signal. Default 30000.
     */
    readonly codeTimeoutMs?: number;
    /**
     * Tool calls per `core__run_code` or `core__run_bash` call, a positive integer. Each call past it fails in the code
     * without running, and the result says how many were refused. Default 64.
     */
    readonly maxCodeCalls?: number;
    /**
     * The most text characters a tool result keeps, a positive integer, counted after redaction. The rest is cut with
     * `…[truncated <n> characters]`, so the model knows. Every helper below this session inherits it. Default 50000.
     */
    readonly maxToolResultChars?: number;
    /** Receives every log record. Default: one stderr line per record at INFO and above. */
    readonly log?: (record: LogRecord) => void;
    /** Builds the `delegate` plugin. Only the host can enable it, in `enabled` or with `Session.enable`. */
    readonly delegate?: DelegateOptions;
    /**
     * `gen_ai.conversation.id` on every span, such as the host's chat thread id. Default: a random UUID. The transcript
     * keeps it, so a resume may leave it out, and a resume that passes a different one rejects.
     */
    readonly conversationId?: string;
    /**
     * `captureContent` puts model input and output, system instructions, and tool arguments and results on the GenAI
     * spans, redacted and capped. Default off. Every helper below this session inherits it.
     */
    readonly telemetry?: {
        readonly captureContent?: boolean;
    };
}
/** pi ignores a system prompt when the transcript already starts with one, so a session takes one or the other. */
export type SessionOptions = CommonOptions & ({
    readonly systemPrompt: string;
    readonly transcript?: never;
} | {
    readonly transcript: Transcript;
    readonly systemPrompt?: never;
});
export type RunResult = {
    readonly stop: 'done';
    readonly text: string;
    readonly turns: number;
} | {
    readonly stop: 'max_turns';
    readonly text: string;
    readonly turns: number;
} | {
    readonly stop: 'aborted';
    readonly turns: number;
} | {
    readonly stop: 'error';
    readonly message: string;
    readonly turns: number;
};
/** The W3C trace and span ids of the span an event happened in, so a host can link the event into its trace. */
export interface EventTrace {
    readonly traceId: string;
    readonly spanId: string;
}
export type Severity = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
/**
 * One log record, shaped like the OpenTelemetry Logs Data Model. Redacted. Who logged rides in `attributes`, never in
 * `body`: `aigent.plugin`, then `aigent.hook` for a hook, or `gen_ai.tool.name` and `gen_ai.tool.call.id` for a tool,
 * and `aigent.delegate.profile` when a helper logged. The trace fields name the span active when the record was made,
 * and are absent when no OpenTelemetry SDK is registered.
 */
export interface LogRecord {
    /** The OTel number for `severityText`: 5, 9, 13 or 17. */
    readonly severityNumber: number;
    readonly severityText: Severity;
    readonly body: string;
    readonly attributes: Readonly<Record<string, string>>;
    /** Set on a log-based event, such as `aigent.progress`. */
    readonly eventName?: string;
    readonly traceId?: string;
    readonly spanId?: string;
    /** The W3C flags byte, set only with the ids. 0x01 is sampled. */
    readonly traceFlags?: number;
}
/**
 * Everything a host can watch. Redacted. `trace` is the call's `execute_tool` span on tool and progress events, and
 * the run's `invoke_agent` span on `turn_end`. It is absent when no OpenTelemetry SDK is registered.
 */
export type SessionEvent = {
    readonly type: 'text';
    readonly delta: string;
} | {
    readonly type: 'tool_start';
    readonly call: ToolCallSnapshot;
    readonly trace?: EventTrace;
} | {
    readonly type: 'tool_end';
    readonly result: ToolResultSnapshot;
    readonly trace?: EventTrace;
} | {
    readonly type: 'progress';
    readonly plugin: string;
    readonly callId: string;
    readonly text: string;
    readonly trace?: EventTrace;
} | {
    readonly type: 'record';
    readonly record: EngineRecord;
} | {
    readonly type: 'turn_end';
    readonly turn: TurnSnapshot;
    readonly trace?: EventTrace;
}
/** An event of the helper that the `delegate__run` call `callId` runs, as that helper's own subscribers see it. */
 | {
    readonly type: 'delegated';
    readonly callId: string;
    readonly profile: string;
    readonly event: SessionEvent;
}
/** A `delegate__run` finished. `transcript` is the helper's whole session, redacted. Store it to audit the helper. */
 | {
    readonly type: 'delegation';
    readonly callId: string;
    readonly profile: string;
    readonly transcript: Transcript;
};
export interface Session {
    /** `gen_ai.conversation.id` on every span of this session and of its helpers. */
    readonly conversationId: string;
    /** Runs until the model stops, a stop condition fires, or the run fails. Rejects while another prompt runs. */
    prompt(text: string, options?: {
        readonly signal?: AbortSignal;
    }): Promise<RunResult>;
    /** Enables a plugin and its dependencies, usable from the next model request. Rejects on an unknown name. */
    enable(name: string): Promise<void>;
    subscribe(listener: (event: SessionEvent) => void): () => void;
    /** Complete whenever no prompt is running. */
    transcript(): Transcript;
    /** Aborts any run, fires `onSessionEnd` once, and rejects later prompts and enables. */
    close(): Promise<void>;
}
export {};
