/** One model request's tokens. `input` leaves out the cached ones, so it is never the prompt size on its own. */
export interface Usage {
    readonly input: number;
    readonly output: number;
    readonly cacheRead: number;
    readonly cacheWrite: number;
}
/** Every token the request sent. */
export declare function promptTokens(usage: Usage): number;
export declare function totalUsage(requests: readonly Usage[]): Usage;
/** The share of the requests' prompt tokens served from cache. Undefined when they sent none, since there was nothing to cache. */
export declare function cachedRatio(requests: readonly Usage[]): number | undefined;
