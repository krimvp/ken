#!/usr/bin/env node
// `aigent run` and `aigent check`. The whole shell: argv and the environment in, a result directory and one JSON
// report on stdout out. Progress and problems go to stderr.
import { stat } from 'node:fs/promises';
import { basename, dirname } from 'node:path';
import { parseArgs } from 'node:util';
import { check } from "./eval/checks.js";
import { isToolMode, readRun, RunFileError, runScenario, writeRun } from "./eval/run.js";
import { readScenario, ScenarioError } from "./eval/scenario.js";
import { createSession, MAX_TIMEOUT_MS } from "./index.js";
const USAGE = `usage:
  aigent run <scenario.json> --out <dir> --model <id> [--tool-mode native|dispatch|programmatic|bash]
             [--base-url <url>] [--api-key-env <NAME>] [--prompt-timeout <seconds>] [--timeout <seconds>]
             [--temperature <n>] [--seed <integer>]
  aigent check <dir>

run    runs the scenario on an OpenAI-compatible model, writes the result directory <dir>
       (which must not exist), then checks the files it wrote. SIGINT, SIGTERM or --timeout, the
       budget of the whole run, aborts the running prompt, and the steps that ran are still written.
       defaults: --tool-mode dispatch, --base-url https://ollama.com/v1, --api-key-env OLLAMA_API_KEY,
       --prompt-timeout 240, no --timeout (both rounded to whole ms, at most 2147483.647), and no
       --temperature or --seed, so the request carries neither and the server's default applies
check  checks an existing result directory.

stdout: the report as JSON. exit: 0 complete and every invariant held, 1 an invariant failed,
2 bad usage or input and nothing ran, 3 the run stopped before its last step finished, 4 the runner failed.`;
/** The argv boundary. A string is the problem that makes it exit 2. */
function parseCommand(argv) {
    let parsed;
    try {
        parsed = parseArgs({
            args: [...argv],
            allowPositionals: true,
            strict: true,
            options: {
                out: { type: 'string' },
                model: { type: 'string' },
                'tool-mode': { type: 'string' },
                'base-url': { type: 'string' },
                'api-key-env': { type: 'string' },
                'prompt-timeout': { type: 'string' },
                timeout: { type: 'string' },
                temperature: { type: 'string' },
                seed: { type: 'string' },
            },
        });
    }
    catch (error) {
        return messageOf(error);
    }
    const { values, positionals } = parsed;
    const [command, path, ...extra] = positionals;
    if (!path || extra.length > 0)
        return 'expected a command and one path';
    if (command === 'check')
        return Object.keys(values).length > 0 ? 'check takes no flags' : { kind: 'check', dir: path };
    if (command !== 'run')
        return `unknown command "${command}"`;
    if (!values.out || !values.model)
        return 'run needs --out and --model';
    const toolMode = values['tool-mode'] ?? 'dispatch';
    if (!isToolMode(toolMode))
        return '--tool-mode must be native, dispatch, programmatic or bash';
    const promptTimeoutMs = milliseconds(values['prompt-timeout'] ?? '240');
    if (promptTimeoutMs === undefined)
        return `--prompt-timeout must be a number of seconds from 0.001 to ${MAX_TIMEOUT_MS / 1000}`;
    const timeoutMs = values.timeout === undefined ? undefined : milliseconds(values.timeout);
    if (values.timeout !== undefined && timeoutMs === undefined)
        return `--timeout must be a number of seconds from 0.001 to ${MAX_TIMEOUT_MS / 1000}`;
    const apiKeyEnv = values['api-key-env'] ?? 'OLLAMA_API_KEY';
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(apiKeyEnv))
        return '--api-key-env must name an environment variable';
    const temperature = values.temperature === undefined ? undefined : Number(values.temperature);
    if (temperature !== undefined && !(Number.isFinite(temperature) && temperature >= 0))
        return '--temperature must be a number from 0 up';
    const seed = values.seed === undefined ? undefined : Number(values.seed);
    if (seed !== undefined && !Number.isSafeInteger(seed))
        return '--seed must be an integer';
    const sampling = { ...(temperature !== undefined && { temperature }), ...(seed !== undefined && { seed }) };
    const model = { kind: 'openai-compatible', baseUrl: values['base-url'] ?? 'https://ollama.com/v1', id: values.model, apiKeyEnv, ...(Object.keys(sampling).length > 0 && { sampling }) };
    return { kind: 'run', scenario: path, out: values.out, model, toolMode, promptTimeoutMs, ...(timeoutMs !== undefined && { timeoutMs }) };
}
/** Seconds rounded to whole milliseconds, when a Node timer can hold them. */
function milliseconds(seconds) {
    const ms = Math.round(Number(seconds) * 1000);
    return ms >= 1 && ms <= MAX_TIMEOUT_MS ? ms : undefined;
}
async function main(argv) {
    const command = parseCommand(argv);
    if (typeof command === 'string')
        return refuse(`${command}\n\n${USAGE}`);
    if (command.kind === 'check') {
        const run = await readRun(command.dir).catch(refusal(RunFileError));
        return typeof run === 'number' ? run : print(check(run));
    }
    const problem = await outProblem(command.out);
    if (problem)
        return refuse(`${command.out} ${problem}`);
    const scenario = await readScenario(command.scenario).catch(refusal(ScenarioError));
    if (typeof scenario === 'number')
        return scenario;
    const controller = new AbortController();
    // A supervisor's stop, such as multeval's attempt timeout, ends the run as Ctrl-C does, so the steps that ran are written.
    for (const signal of ['SIGINT', 'SIGTERM'])
        process.once(signal, () => controller.abort());
    const log = await runScenario(scenario, {
        root: dirname(command.scenario),
        open: createSession,
        model: command.model,
        toolMode: command.toolMode,
        promptTimeoutMs: command.promptTimeoutMs,
        signal: command.timeoutMs === undefined ? controller.signal : AbortSignal.any([controller.signal, AbortSignal.timeout(command.timeoutMs)]),
        name: basename(command.scenario, '.json'),
        onStep: (step, ran) => process.stderr.write(`aigent: step ${step}/${scenario.steps.length} ${progress(ran)}\n`),
    }).catch(refusal(ScenarioError));
    if (typeof log === 'number')
        return log;
    await writeRun(command.out, log);
    // The verdict comes from the files, so every run proves they are enough to grade it.
    return print(check(await readRun(command.out)));
}
function progress(step) {
    switch (step.kind) {
        case 'prompt':
            return `prompt: ${step.result.stop} after ${step.result.turns} turns`;
        case 'enable':
        case 'resume':
            return step.kind;
        default:
            return step;
    }
}
function print(report) {
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    if (Object.values(report.invariants).some((verdict) => verdict.kind === 'fail'))
        return 1;
    return report.complete ? 0 : 3;
}
function refuse(problem) {
    process.stderr.write(`aigent: ${problem}\n`);
    return 2;
}
/** Turns a rejection of the boundary's own error class into exit 2, and lets anything else reach exit 4. */
function refusal(kind) {
    return (error) => {
        if (error instanceof kind)
            return refuse(error.message);
        throw error;
    };
}
/** Why `path` cannot become a new result directory, or undefined when it can. */
async function outProblem(path) {
    return stat(path).then(() => 'already exists', (error) => {
        if (error.code === 'ENOENT')
            return undefined;
        if (error.code === 'ENOTDIR')
            return 'is under a file, so no directory can be made there';
        throw error;
    });
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error);
}
// A supervisor killed by SIGKILL takes the readers of both pipes with it. The result directory is the product, so a
// write to a closed pipe must not end the run before it is written.
for (const stream of [process.stdout, process.stderr]) {
    stream.on('error', (error) => {
        if (error.code !== 'EPIPE')
            throw error;
    });
}
process.exitCode = await main(process.argv.slice(2)).catch((error) => {
    process.stderr.write(`aigent: ${error instanceof Error ? (error.stack ?? error.message) : String(error)}\n`);
    return 4;
});
