// Runs model-written code with only a host call to reach the outside: JavaScript in a QuickJS WASM sandbox, or a
// script in just-bash, a simulated bash. Neither has network, host files, host environment, modules or process.
// Knows nothing about the engine.
import { readFile } from 'node:fs/promises';
import { extname } from 'node:path';
import { Worker } from 'node:worker_threads';
// sandbox-worker.ts in the checkout, sandbox-worker.js once built. tsc rewrites import specifiers but not this path.
const WORKER = new URL(`./sandbox-worker${extname(import.meta.url)}`, import.meta.url);
/** How long a run waits past its deadline or its abort for the tool calls it started to settle. */
const GRACE_MS = 1000;
/**
 * Waits for `inflight` to settle, or until GRACE_MS past the deadline or the abort, whichever comes first, so a call
 * that ignores its abort signal cannot hold the run open. Never rejects.
 */
async function settle(inflight, signal, deadline) {
    let timer;
    let onAbort = () => { };
    const cutoff = new Promise((resolve) => {
        const until = (end) => {
            clearTimeout(timer);
            timer = setTimeout(resolve, Math.max(0, end - Date.now()));
        };
        until(deadline + GRACE_MS);
        onAbort = () => until(Math.min(deadline, Date.now()) + GRACE_MS);
        if (signal.aborted)
            onAbort();
        else
            signal.addEventListener('abort', onAbort, { once: true });
    });
    try {
        await Promise.race([Promise.allSettled(inflight), cutoff]);
    }
    finally {
        clearTimeout(timer);
        signal.removeEventListener('abort', onAbort);
    }
}
/** A worker boot slowed by load counts against this, not against the code's deadline. */
const BOOT_LIMIT_MS = 10_000;
let compiled;
/** A worker started ahead of the next run, so a run does not wait for a thread to boot. */
let spare;
function startWorker(wasmModule) {
    const worker = new Worker(WORKER, { workerData: { wasmModule } });
    worker.unref();
    // A spare that fails while idle is dropped, and the run that would have used it starts its own worker instead.
    worker.on('error', () => { });
    worker.once('exit', () => spare === worker && (spare = undefined));
    return worker;
}
/**
 * Runs `code` as the body of an async function, in QuickJS on a worker thread of its own, so the host's event loop
 * keeps running. The deadline, which starts when the VM starts the code, and the abort end the thread. Every call
 * the code started has settled when this resolves, except one still running GRACE_MS past the deadline or the
 * abort, which is left running. Rejects only when QuickJS itself fails, or fails to start.
 */
export async function runCode(code, call, options) {
    const wasmModule = await (compiled ??= readFile(new URL(import.meta.resolve('@jitl/quickjs-wasmfile-release-sync/wasm'))).then((bytes) => WebAssembly.compile(bytes)));
    const worker = spare ?? startWorker(wasmModule);
    spare = startWorker(wasmModule);
    const lines = [];
    const inflight = [];
    const answer = (message) => worker.postMessage(message);
    let deadline = Date.now() + options.timeoutMs;
    let timer;
    let onAbort = () => { };
    try {
        return await new Promise((resolve, reject) => {
            answer({ kind: 'run', code });
            const stop = (error) => resolve({ kind: 'threw', output: lines.join('\n'), error });
            onAbort = () => stop('aborted');
            options.signal.addEventListener('abort', onAbort, { once: true });
            if (options.signal.aborted)
                onAbort();
            timer = setTimeout(() => reject(new Error(`the sandbox worker did not start within ${BOOT_LIMIT_MS}ms`)), BOOT_LIMIT_MS);
            worker.on('error', reject);
            worker.on('exit', () => reject(new Error('the sandbox worker exited before the code finished')));
            worker.on('message', (message) => {
                if (message.kind === 'started') {
                    clearTimeout(timer);
                    deadline = Date.now() + options.timeoutMs;
                    timer = setTimeout(() => stop(`timed out after ${options.timeoutMs}ms`), options.timeoutMs);
                }
                else if (message.kind === 'log')
                    lines.push(message.text);
                else if (message.kind === 'call') {
                    const { id, name, args } = message;
                    inflight.push(Promise.resolve()
                        .then(() => call(name, args))
                        .then(({ ok, text }) => answer({ kind: 'settle', id, ok, text }), (error) => answer({ kind: 'settle', id, ok: false, text: error instanceof Error ? error.message : String(error) })));
                }
                else
                    resolve({ ...message, output: lines.join('\n') });
            });
        });
    }
    finally {
        clearTimeout(timer);
        options.signal.removeEventListener('abort', onAbort);
        worker.removeAllListeners('message');
        await worker.terminate();
        await settle(inflight, options.signal, deadline);
    }
}
/**
 * Runs `script` in just-bash, a simulated bash with an in-memory filesystem and no network, host files or host
 * environment. Each name in `commands` becomes a command that takes one JSON object argument and calls the host:
 * its text goes to stdout, or to stderr with exit code 1 when `ok` is false. just-bash is an optional peer
 * dependency, loaded on the first run. Every call the script started has settled when this resolves, except one
 * still running GRACE_MS past the deadline or the abort, which is left running.
 */
export async function runBash(script, call, options) {
    const { Bash, defineCommand } = await (bash ??= import('just-bash').catch((error) => {
        bash = undefined;
        throw new Error(`the bash tool mode needs the just-bash package installed: ${error instanceof Error ? error.message : String(error)}`);
    }));
    const deadline = Date.now() + options.timeoutMs;
    const inflight = [];
    const customCommands = options.commands.map((name) => defineCommand(name, async (args) => {
        let parsed;
        try {
            if (args.length > 1)
                throw new Error('too many arguments');
            parsed = JSON.parse(args[0] ?? '{}');
        }
        catch {
            return { stdout: '', stderr: `${name}: pass the arguments as one JSON object, such as ${name} '{"key":"value"}'\n`, exitCode: 2 };
        }
        const pending = call(name, parsed);
        inflight.push(pending);
        const { ok, text } = await pending;
        const line = text === '' || text.endsWith('\n') ? text : `${text}\n`;
        return ok ? { stdout: line, stderr: '', exitCode: 0 } : { stdout: '', stderr: line, exitCode: 1 };
    }));
    const shell = new Bash({ customCommands, executionLimits: { maxExecutionTimeMs: options.timeoutMs, maxOutputSize: BASH_OUTPUT_LIMIT } });
    try {
        const { stdout, stderr, exitCode } = await shell.exec(script, { signal: options.signal, rawScript: true });
        const output = [stdout, stderr].map((s) => s.replace(/\n+$/, '')).filter((s) => s !== '').join('\n');
        if (options.signal.aborted)
            return { kind: 'threw', output, error: 'aborted' };
        if (exitCode === 124 && Date.now() >= deadline)
            return { kind: 'threw', output, error: `timed out after ${options.timeoutMs}ms` };
        return exitCode === 0 ? { kind: 'returned', output } : { kind: 'threw', output, error: `exit code ${exitCode}` };
    }
    finally {
        await settle(inflight, options.signal, deadline);
    }
}
const BASH_OUTPUT_LIMIT = 1024 * 1024;
let bash;
