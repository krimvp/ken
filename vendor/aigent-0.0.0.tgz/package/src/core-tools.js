// What each tool mode declares, the core tools that reach late plugins, and the two of them that run model code in
// the sandbox. Each call the code makes goes back through the host it is given.
import { CORE, qualify } from "./catalog.js";
import { runBash, runCode } from "./sandbox.js";
export const CALL_TOOL = {
    name: qualify(CORE, 'call_tool'),
    description: 'Call a tool of a plugin enabled during this conversation. Its name and parameters are listed where it was enabled.',
    parameters: {
        type: 'object',
        properties: {
            tool: { type: 'string', description: 'Full tool name, <plugin>__<tool>' },
            args: { type: 'object', description: "Arguments matching the tool's parameters" },
        },
        required: ['tool'],
        additionalProperties: false,
    },
};
export const RUN_CODE = {
    name: qualify(CORE, 'run_code'),
    description: 'Run JavaScript, the body of an async function. `await tools.<plugin>__<tool>(args)` calls any tool of an enabled plugin, declared or not, returns its text, and throws on an error or a denial. What the code prints with console and the value it returns come back. There is no network, files, timers or modules.',
    parameters: {
        type: 'object',
        properties: { code: { type: 'string', description: 'The body of an async function' } },
        required: ['code'],
        additionalProperties: false,
    },
};
export const RUN_BASH = {
    name: qualify(CORE, 'run_bash'),
    description: "Run a bash script in a simulated shell with an in-memory filesystem. Each tool of an enabled plugin, declared or not, is a command that takes one JSON object argument, such as <plugin>__<tool> '{\"key\":\"value\"}'. It prints the tool's text, or on an error or a denial prints it to stderr and exits 1. Pipes, grep, jq, sed, awk and files work. What the script prints comes back. There is no network and no host files.",
    parameters: {
        type: 'object',
        properties: { script: { type: 'string', description: 'The bash script' } },
        required: ['script'],
        additionalProperties: false,
    },
};
/** The longest `core__run_code` or `core__run_bash` result. */
const CODE_RESULT_CAP = 8_000;
export const MODES = {
    native: { late: 'declared' },
    dispatch: { late: 'reached', via: CALL_TOOL, heading: `Tools (call with ${CALL_TOOL.name}):` },
    programmatic: { late: 'reached', via: RUN_CODE, heading: `Tools (call from ${RUN_CODE.name} as \`await tools.<name>(args)\`):` },
    bash: { late: 'reached', via: RUN_BASH, heading: `Tools (run as commands in ${RUN_BASH.name}: <name> '<JSON arguments>'):` },
};
/** Tool calls of one code tool call that run at once. The rest wait for a slot, in the order the code made them. */
const CONCURRENT_CALLS = 8;
/** `core__run_code` and `core__run_bash`. Each call the code makes is `<call id>/<n>`. */
export function createCodeTools(host) {
    const limits = { timeoutMs: host.timeoutMs };
    return [
        sandboxTool(host, RUN_CODE, 'code', (code, call, signal) => runCode(code, call, { ...limits, signal })),
        sandboxTool(host, RUN_BASH, 'script', (script, call, signal) => runBash(script, call, { ...limits, signal, commands: host.commands() })),
    ];
}
function sandboxTool(host, via, source, run) {
    return {
        name: via.name.slice(`${CORE}__`.length),
        description: via.description,
        parameters: via.parameters,
        async execute(args, ctx) {
            const callId = host.callIdOf(ctx);
            if (callId === undefined)
                return errorResult('the call context is not one this session made');
            const signal = AbortSignal.any([ctx.signal, AbortSignal.timeout(host.timeoutMs)]);
            let n = 0;
            let refused = 0;
            const running = new Map();
            const waiting = [];
            signal.addEventListener('abort', () => waiting.splice(0).forEach((wake) => wake()), { once: true });
            const outcome = await run(String(args[source]), async (name, raw) => {
                if (n >= host.maxCalls) {
                    refused++;
                    return { ok: false, text: `Over the limit of ${host.maxCalls} tool calls per ${via.name} run.` };
                }
                const id = `${callId}/${++n}`;
                while (running.size >= CONCURRENT_CALLS && !signal.aborted)
                    await new Promise((wake) => waiting.push(wake));
                if (signal.aborted)
                    return { ok: false, text: 'aborted' };
                running.set(id, name);
                try {
                    const result = await host.call(id, name, raw, `from ${via.name}`, signal);
                    return { ok: !result.isError, text: result.content.map((c) => (c.type === 'text' ? c.text : '[image]')).join('\n') };
                }
                finally {
                    running.delete(id);
                    waiting.shift()?.();
                }
            }, ctx.signal);
            for (const [id, name] of running)
                ctx.log.warn(`${id} ${name} ignored its abort signal and was still running when ${via.name} returned`);
            if (refused === 0)
                return codeResult(outcome, host.redact);
            const note = `Refused ${refused} of ${n + refused} tool calls, over the limit of ${host.maxCalls} per ${via.name} run.`;
            return codeResult({ ...outcome, output: [note, outcome.output].filter((part) => part !== '').join('\n') }, host.redact);
        },
    };
}
/** What the code printed, then what it returned or threw, redacted and then capped. */
function codeResult(outcome, redact) {
    const end = outcome.kind === 'threw' ? [`Error: ${outcome.error}`] : outcome.value === undefined ? [] : [`Returned: ${outcome.value}`];
    const text = redact([outcome.output, ...end].filter((part) => part !== '').join('\n') || 'No output and no return value.');
    const capped = text.length > CODE_RESULT_CAP ? `${text.slice(0, CODE_RESULT_CAP)}…[truncated ${text.length - CODE_RESULT_CAP} characters]` : text;
    return outcome.kind === 'threw' ? errorResult(capped) : textResult(capped);
}
function textResult(text) {
    return { content: [{ type: 'text', text }] };
}
function errorResult(text) {
    return { content: [{ type: 'text', text }], isError: true };
}
