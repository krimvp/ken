// Plugin-author vocabulary, published as `aigent/plugin`. Types only, so a plugin depends on nothing at runtime.
export {};
