export type JsonValue = null | boolean | number | string | readonly JsonValue[] | JsonObject;
export type JsonObject = {
    readonly [key: string]: JsonValue;
};
/** Plain JSON Schema with an object root. Hand-written, TypeBox or zod output all fit. */
export type JsonSchema = {
    readonly type: 'object';
} & JsonObject;
export type MaybePromise<T> = T | Promise<T>;
export type Content = {
    readonly type: 'text';
    readonly text: string;
} | {
    readonly type: 'image';
    readonly data: string;
    readonly mimeType: string;
};
export interface ToolResult {
    readonly content: readonly Content[];
    readonly isError?: boolean;
}
/** What the engine hands a tool or hook for one call. */
export interface PluginContext {
    /**
     * Fires on the hook timeout, on session close, and for tools when the run is aborted. A hook's also fires once the
     * hook settles: its invocation has ended, and from then on its `log` and `state.update` throw.
     */
    readonly signal: AbortSignal;
    readonly log: PluginLog;
    /** The host's value for a name this plugin declared in `secrets`. An undeclared name throws. */
    secret(name: string): string;
    /** This plugin's own state in this session. It survives resume and the model never sees it. Not for secrets. */
    readonly state: PluginState;
}
/**
 * Sends a line to the host's `log` as one record: redacted, attributed to this plugin and the call or hook that logged,
 * and correlated with its span. For operators.
 */
export interface PluginLog {
    /** At INFO. */
    (line: string): void;
    warn(line: string): void;
    error(line: string): void;
}
/** One JSON value per plugin per session, kept in the transcript. */
export interface PluginState {
    /** This plugin's value in this session, deep-frozen, or undefined before the first update. */
    get(): JsonValue | undefined;
    /** Replaces the value with what `next` returns. `next` runs synchronously, so parallel calls cannot lose an update between awaits. Strings are redacted before the value is stored, and the serialized value is capped at 16 KB. */
    update(next: (prev: JsonValue | undefined) => JsonValue): void;
}
/** What the engine hands a tool for one call. */
export interface ToolContext extends PluginContext {
    /** Tells the end user what a slow tool is doing. Redacted and sent to the host as a `progress` event, never to the model or the transcript. Use `log` for operators. */
    progress(text: string): void;
}
export interface Tool {
    /** `[A-Za-z0-9_-]+`. The model sees `<plugin>__<name>`. */
    readonly name: string;
    readonly description: string;
    readonly parameters: JsonSchema;
    /** `args` passed validation against `parameters` and every gate saw the same frozen object. A throw becomes an error result. */
    execute(args: JsonObject, ctx: ToolContext): Promise<ToolResult>;
}
export interface Skill {
    /** `[a-z0-9_-]+`. The model loads it as `<plugin>__<name>`. */
    readonly name: string;
    /** Visible once the plugin is enabled. */
    readonly description: string;
    /** Read only when the model asks for it. */
    load(): MaybePromise<string>;
}
export type GateVerdict = 'allow' | {
    readonly deny: string;
};
export type EnableCause = 'initial' | 'host' | 'model' | {
    readonly dependencyOf: string;
};
export interface EnableSnapshot {
    readonly plugin: string;
    readonly cause: EnableCause;
    /** Every enabled plugin, this one included, in enable order. */
    readonly enabled: readonly string[];
}
export interface PromptSnapshot {
    readonly text: string;
    readonly enabled: readonly string[];
}
export interface ToolCallSnapshot {
    /** The engine's, unique in this session and one segment: the provider's id with `/` escaped, plus `#<n>` once the session has used it. A helper's call reaches this session's hooks as `<delegate__run call id>/<its id>`, one segment per level. */
    readonly id: string;
    /** The resolved `<plugin>__<tool>` name, never `core__call_tool`. */
    readonly name: string;
    readonly plugin: string;
    readonly tool: string;
    readonly args: JsonObject;
}
export interface Denial {
    readonly plugin: string;
    readonly reason: string;
}
export type ToolOutcome = {
    readonly kind: 'ran';
    readonly result: ToolResult;
} | {
    readonly kind: 'denied';
    readonly denials: readonly Denial[];
};
export interface ToolResultSnapshot {
    readonly call: ToolCallSnapshot;
    readonly outcome: ToolOutcome;
}
export interface TurnSnapshot {
    /** 1-based within the current prompt. */
    readonly turn: number;
    readonly text: string;
    readonly calls: readonly ToolResultSnapshot[];
}
export interface SessionEndSnapshot {
    /** Model requests over the session's whole life, resumes included. A transcript from before usage records adds none of its turns. */
    readonly turns: number;
    readonly enabled: readonly string[];
}
/**
 * Hooks observe, add, or gate. The return types are the whole capability: an add hook can only return text to
 * append, a gate can only allow or deny, an observer has nothing to return. Each hook gets a deep-frozen snapshot
 * and a context that lives until the hook settles, times out, or is cut off by an abort or session close.
 */
export interface Hooks {
    /** Add. Fires once, when this plugin is enabled. */
    onEnable?(event: EnableSnapshot, ctx: PluginContext): MaybePromise<string | undefined>;
    /** Add. Text is appended to the user message, after the prompt, in plugin enable order. */
    onUserPrompt?(event: PromptSnapshot, ctx: PluginContext): MaybePromise<string | undefined>;
    /** Gate. Runs before every tool call of every plugin, core included. Any deny wins. A throw or timeout denies. */
    beforeToolCall?(call: ToolCallSnapshot, ctx: PluginContext): MaybePromise<GateVerdict>;
    onToolResult?(event: ToolResultSnapshot, ctx: PluginContext): MaybePromise<void>;
    onTurnEnd?(event: TurnSnapshot, ctx: PluginContext): MaybePromise<void>;
    onSessionEnd?(event: SessionEndSnapshot, ctx: PluginContext): MaybePromise<void>;
}
export interface Plugin {
    /** `[a-z0-9-]+`, unique. `core`, `session` and `delegate` are reserved. */
    readonly name: string;
    /** One line, shown in the catalog. */
    readonly description: string;
    /** Enabled first, in this order. Names only. */
    readonly dependsOn?: readonly string[];
    /** Names of host `secrets` this plugin reads through `ctx.secret`. Session creation fails when the host did not pass one. */
    readonly secrets?: readonly string[];
    /** Shown to the model once, when the plugin is enabled. */
    readonly instructions?: string;
    readonly tools?: readonly Tool[];
    readonly skills?: readonly Skill[];
    readonly hooks?: Hooks;
}
