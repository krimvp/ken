// The only module that imports @earendil-works/*. It binds the engine port to pi's Agent, resolves models, and
// carries engine records inside pi's transcript. Every plugin rule lives behind the Engine port.
import { Agent } from '@earendil-works/pi-agent-core';
import { envApiKeyAuth, validateToolArguments } from '@earendil-works/pi-ai';
import { openAICompletionsApi } from '@earendil-works/pi-ai/api/openai-completions.lazy';
import { createModels, createProvider } from '@earendil-works/pi-ai/models';
import { builtinModels } from '@earendil-works/pi-ai/providers/all';
import { context, SpanKind, trace } from '@opentelemetry/api';
import { DELEGATE } from "./catalog.js";
import { createEngine } from "./engine.js";
import { redactJson } from "./redact.js";
import { MIN_SECRET_LENGTH } from "./session.js";
import { captured, capturedHistory, conversationAttributes, decodedBytes, fail, instruments, logRecord, thrownType, tracer, usageAttributes, writeStderr } from "./tracing.js";
import { promptTokens, totalUsage } from "./usage.js";
const TRANSCRIPT_FORMAT = 'aigent-transcript/1';
export async function createSession(options) {
    return startSession(options, resolveModel);
}
/** `lineage` is set only when `spawnPort` opens a helper. */
export async function startSession(options, resolve, lineage) {
    if (options.systemPrompt !== undefined && options.transcript !== undefined)
        throw new Error('pass systemPrompt or transcript, not both');
    const limits = parseLimits(options);
    const resolved = await resolve(options.model);
    const resumed = options.transcript && parseTranscript(options.transcript);
    const listeners = new Set();
    const writeLog = options.log ?? writeStderr;
    const tree = lineage?.tree ?? (options.delegate && (await parseDelegate(options.delegate, options, limits, resolved, resolve, writeLog)));
    // Nobody can subscribe before createSession returns, so this never runs before `engine` exists.
    const dispatch = (event) => {
        for (const listener of listeners) {
            try {
                listener(redactEvent(event, engine.redact));
            }
            catch (error) {
                writeLog(logRecord('WARN', engine.redact(`listener threw: ${messageOf(error)}`)));
            }
        }
    };
    const secrets = tree?.secrets ?? { ...options.secrets, ...resolved.secrets };
    const short = shortSecrets(secrets);
    if (short.length > 0)
        throw new Error(`invalid session options:\n- ${short.join('\n- ')}`);
    const captureContent = options.telemetry?.captureContent === true;
    const delegation = tree && spawnPort(tree, lineage?.depth ?? 0);
    const engine = await createEngine({
        plugins: options.plugins,
        model: { id: resolved.model.id, provider: resolved.model.provider, contextWindow: resolved.model.contextWindow, maxOutputTokens: resolved.model.maxTokens },
        toolMode: options.toolMode ?? 'dispatch',
        start: resumed ? { kind: 'resume', records: resumed.records } : { kind: 'fresh', systemPrompt: options.systemPrompt ?? '' },
        enabled: options.enabled ?? [],
        secrets,
        ...limits,
        validate: piValidate,
        captureContent,
        emit: dispatch,
        log: writeLog,
        ...(delegation && { delegation }),
        ...(lineage && { ancestors: lineage.ancestors }),
        conversationId: options.conversationId,
    });
    const conversation = conversationAttributes(engine.conversationId);
    // The names pi resolves calls against: those of the list it was last handed. It answers any other name itself.
    let offered = new Set();
    const agentTools = () => {
        const specs = engine.tools();
        offered = new Set(specs.map((spec) => spec.name));
        return specs.map((spec) => ({
            name: spec.name,
            label: spec.name,
            description: spec.description,
            parameters: spec.parameters,
            execute: async (toolCallId, params, signal) => {
                const result = await engine.callTool({ id: toolCallId, name: spec.name, args: params }, signal ?? new AbortController().signal);
                return toAgentResult(result);
            },
        }));
    };
    const wrap = (record) => ({ role: 'aigent', record, timestamp: Date.now() });
    // The last assistant message finishTurn reported, so a run pi ends without calling it still gets its turn.
    let reported;
    const agent = new Agent({
        initialState: { model: resolved.model, systemPrompt: engine.systemPrompt, tools: agentTools(), messages: resumed?.messages ?? [] },
        streamFn: traced(resolved.streamFn, engine.redact, conversation, captureContent, writeLog),
        convertToLlm: (messages) => messages.filter((m) => m.role !== 'aigent'),
        // Runs before pi declares tool changes, so the new declarations land ahead of the request that can use them.
        prepareNextTurnWithContext: (turn) => ({ context: { ...turn.context, tools: agentTools() }, messages: engine.takeRecords().map(wrap) }),
        finishTurn: async (turn) => {
            reported = turn.message;
            return (await engine.endTurn(toTurn(turn.message))) === 'stop' ? { action: 'end' } : undefined;
        },
    });
    const text = holdBack(Math.max(0, ...Object.values(secrets).map((v) => v.length)), engine.redact, (delta) => dispatch({ type: 'text', delta }));
    agent.subscribe(async (event) => {
        if (event.type === 'message_update' && event.assistantMessageEvent.type === 'text_delta')
            text.push(event.assistantMessageEvent.delta);
        // pi has no catch-all tool, so a call it found no tool for reaches the engine only from here, after pi answered it.
        else if (event.type === 'tool_execution_end' && !offered.has(event.toolName))
            await engine.undeclaredCall({ id: event.toolCallId, name: event.toolName });
        // pi ends every assistant message this way, whether it finished, errored or was aborted, and awaits this listener
        // before it runs the message's tool calls.
        else if (event.type === 'message_end') {
            text.flush();
            if (event.message.role === 'assistant')
                engine.observeUsage(usageOf(event.message));
        }
    });
    const flush = () => {
        const records = engine.takeRecords();
        if (records.length > 0)
            agent.state.messages = [...agent.state.messages, ...records.map(wrap)];
    };
    flush();
    let running;
    let closed;
    return {
        conversationId: engine.conversationId,
        async prompt(text, { signal } = {}) {
            if (closed)
                throw new Error('session is closed');
            if (running)
                throw new Error('a prompt is already running');
            const controller = new AbortController();
            running = controller;
            const runSignal = signal ? AbortSignal.any([signal, controller.signal]) : controller.signal;
            const onAbort = () => agent.abort();
            runSignal.addEventListener('abort', onAbort, { once: true });
            // Active for the whole run, so pi's loop, the engine's tool calls and their hooks all open spans under it.
            const agentName = lineage?.profile ?? 'aigent';
            const attributes = { 'gen_ai.operation.name': 'invoke_agent', 'gen_ai.agent.name': agentName, ...conversation, ...(lineage && { 'aigent.delegate.depth': lineage.depth, 'aigent.delegate.call_id': lineage.callId }) };
            const previous = engine.previousRun();
            return tracer.startActiveSpan(`invoke_agent ${agentName}`, { kind: SpanKind.INTERNAL, attributes, ...(previous && { links: [{ context: previous }] }) }, async (span) => {
                try {
                    const content = await engine.beginPrompt(text, runSignal);
                    agent.state.tools = agentTools();
                    reported = undefined;
                    const run = agent.prompt([...engine.takeRecords().map(wrap), { role: 'user', content, timestamp: Date.now() }]);
                    // agent.prompt registers its run synchronously, so an abort that fired before it started still lands.
                    if (runSignal.aborted)
                        agent.abort();
                    await run;
                    const last = agent.state.messages.at(-1);
                    if (last?.role === 'assistant' && last !== reported)
                        await engine.endTurn(toTurn(last));
                    flush();
                    const result = engine.endRun();
                    span.setAttributes({ 'aigent.run.stop': result.stop, 'aigent.run.turns': result.turns });
                    if (result.stop === 'error')
                        fail(span, 'model_error', result.message);
                    return result;
                }
                catch (error) {
                    fail(span, thrownType(error), engine.redact(messageOf(error)));
                    throw error;
                }
                finally {
                    runSignal.removeEventListener('abort', onAbort);
                    running = undefined;
                    span.end();
                }
            });
        },
        async enable(name) {
            if (closed)
                throw new Error('session is closed');
            await engine.enable(name);
            if (!running)
                flush();
        },
        subscribe(listener) {
            listeners.add(listener);
            return () => listeners.delete(listener);
        },
        transcript() {
            const messages = JSON.parse(JSON.stringify(agent.state.messages));
            return { format: TRANSCRIPT_FORMAT, messages: messages.map((m) => exportMessage(m, engine.redact)) };
        },
        close() {
            closed ??= (async () => {
                running?.abort();
                await agent.waitForIdle();
                flush();
                await engine.close();
            })();
            return closed;
        },
    };
}
/** The longest delay Node's timers hold. Past it, a timer fires after 1 ms, and `AbortSignal.timeout` needs whole ms. */
export const MAX_TIMEOUT_MS = 2 ** 31 - 1;
/** Host-input boundary. Throws with every problem in the limits. */
function parseLimits(options) {
    const problems = [];
    const limit = (value, fallback, at, max, rule) => {
        if (value === undefined)
            return fallback;
        if (!Number.isInteger(value) || value < 1 || value > max)
            problems.push(`${at} must be ${rule}`);
        return value;
    };
    const timeout = `a whole number of milliseconds from 1 to ${MAX_TIMEOUT_MS}`;
    const limits = {
        maxTurns: limit(options.maxTurns, 25, 'maxTurns', Number.MAX_SAFE_INTEGER, 'a positive integer'),
        hookTimeoutMs: limit(options.hookTimeoutMs, 10_000, 'hookTimeoutMs', MAX_TIMEOUT_MS, timeout),
        codeTimeoutMs: limit(options.codeTimeoutMs, 30_000, 'codeTimeoutMs', MAX_TIMEOUT_MS, timeout),
        maxCodeCalls: limit(options.maxCodeCalls, 64, 'maxCodeCalls', Number.MAX_SAFE_INTEGER, 'a positive integer'),
        maxToolResultChars: limit(options.maxToolResultChars, 50_000, 'maxToolResultChars', Number.MAX_SAFE_INTEGER, 'a positive integer'),
    };
    problems.push(...shortSecrets(options.secrets ?? {}));
    if (problems.length > 0)
        throw new Error(`invalid session options:\n- ${problems.join('\n- ')}`);
    return limits;
}
/** Names only: the message must not carry the value it refuses. */
function shortSecrets(secrets) {
    return Object.entries(secrets)
        .filter(([, value]) => value.length > 0 && value.length < MIN_SECRET_LENGTH)
        .map(([name]) => `secret ${name} must be empty or at least ${MIN_SECRET_LENGTH} characters, or redacting it rewrites ordinary text`);
}
const PROFILE_NAME = /^[a-z0-9-]+$/;
const HELPER_PROMPT = 'You are a helper agent. Do the task you are given with your tools, then reply with the result alone.';
/**
 * Host-input boundary. Throws with every problem in the options. Resolves each profile's model once per spec, so a
 * missing key fails here and not inside a tool call, and adds every key to the tree's secrets.
 */
async function parseDelegate(delegate, options, limits, main, resolve, log) {
    const problems = [];
    const count = (value, at, fallback) => {
        if (value === undefined)
            return fallback;
        if (!Number.isInteger(value) || value < 1)
            problems.push(`${at} must be a positive integer`);
        return value;
    };
    const maxDepth = count(delegate.maxDepth, 'delegate.maxDepth', 1);
    const named = Object.entries(delegate.profiles ?? {});
    if (named.length === 0)
        problems.push('delegate.profiles must name at least one profile');
    const turns = named.map(([name, p]) => {
        const at = `delegate profile "${name}"`;
        if (!PROFILE_NAME.test(name))
            problems.push(`${at}: name must match [a-z0-9-]+`);
        if (typeof p.description !== 'string' || p.description.trim() === '' || /[\r\n]/.test(p.description))
            problems.push(`${at}: description must be one non-empty line`);
        if (typeof p.plugins !== 'function')
            problems.push(`${at}: plugins must be a function that returns plugins`);
        return count(p.maxTurns, `${at}: maxTurns`, 10);
    });
    if (problems.length > 0)
        throw new Error(`invalid delegate options:\n- ${problems.join('\n- ')}`);
    const models = new Map([[JSON.stringify(options.model), Promise.resolve(main)]]);
    const resolvedFor = (spec) => {
        const key = JSON.stringify(spec);
        if (!models.has(key))
            models.set(key, resolve(spec));
        return models.get(key);
    };
    const profiles = new Map();
    for (const [i, [name, p]] of named.entries()) {
        const model = p.model ?? options.model;
        profiles.set(name, { description: p.description, plugins: p.plugins, model, resolved: await resolvedFor(model), maxTurns: turns[i], systemPrompt: p.systemPrompt ?? HELPER_PROMPT });
    }
    const keys = await Promise.all(models.values());
    const secrets = mergeSecrets({ ...options.secrets, ...main.secrets }, keys.map((k) => k.secrets));
    return { maxDepth, profiles, secrets, hookTimeoutMs: limits.hookTimeoutMs, maxToolResultChars: limits.maxToolResultChars, captureContent: options.telemetry?.captureContent === true, log };
}
/** Every value stays a redaction target. A key whose name another value holds gets the next free `<name>_<n>`. */
function mergeSecrets(base, more) {
    const merged = { ...base };
    for (const secrets of more) {
        for (const [name, value] of Object.entries(secrets)) {
            let at = name;
            for (let n = 2; Object.hasOwn(merged, at) && merged[at] !== value; n++)
                at = `${name}_${n}`;
            merged[at] = value;
        }
    }
    return merged;
}
/** The engine's spawn port, or undefined at the depth limit, which leaves that session without the delegate plugin. */
function spawnPort(tree, depth) {
    if (depth >= tree.maxDepth)
        return undefined;
    const spawn = async ({ callId, profile, task, signal, forward, ancestors, conversationId }) => {
        const p = tree.profiles.get(profile);
        const usages = [];
        let requests = 0;
        let helper;
        let result;
        try {
            const plugins = p.plugins();
            helper = await startSession({
                model: p.model,
                plugins,
                enabled: [...plugins.map((plugin) => plugin.name), ...(depth + 1 < tree.maxDepth ? [DELEGATE] : [])],
                toolMode: 'native',
                systemPrompt: p.systemPrompt,
                secrets: tree.secrets,
                maxTurns: p.maxTurns,
                hookTimeoutMs: tree.hookTimeoutMs,
                maxToolResultChars: tree.maxToolResultChars,
                telemetry: { captureContent: tree.captureContent },
                log: (record) => tree.log({ ...record, attributes: { ...record.attributes, 'aigent.delegate.profile': profile } }),
                conversationId,
            }, async () => p.resolved, { depth: depth + 1, profile, callId, ancestors, tree });
            helper.subscribe((event) => {
                if (event.type === 'record' && (event.record.kind === 'usage' || event.record.kind === 'delegation')) {
                    usages.push(event.record);
                    requests += event.record.kind === 'usage' ? 1 : event.record.requests;
                }
                forward(event);
            });
            result = await helper.prompt(task, { signal });
        }
        catch (error) {
            result = { stop: 'error', message: messageOf(error), turns: 0 };
        }
        finally {
            await helper?.close();
        }
        return { result, requests, usage: totalUsage(usages), transcript: helper?.transcript() ?? { format: TRANSCRIPT_FORMAT, messages: [] } };
    };
    return { profiles: [...tree.profiles].map(([name, p]) => ({ name, description: p.description })), spawn };
}
async function resolveModel(spec) {
    if (spec.kind === 'openai-compatible') {
        const key = process.env[spec.apiKeyEnv];
        if (!key)
            throw new Error(`${spec.apiKeyEnv} is not set`);
        const models = createModels();
        models.setProvider(createProvider({
            id: 'openai-compatible',
            baseUrl: spec.baseUrl,
            auth: { apiKey: envApiKeyAuth(spec.apiKeyEnv, [spec.apiKeyEnv]) },
            models: [
                {
                    id: spec.id,
                    name: spec.id,
                    api: 'openai-completions',
                    baseUrl: spec.baseUrl,
                    provider: 'openai-compatible',
                    type: 'chat',
                    reasoning: spec.reasoning ?? true,
                    input: ['text'],
                    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
                    contextWindow: spec.contextWindow ?? 131_072,
                    maxTokens: spec.maxTokens ?? 8192,
                    // pi merges these into the request body of an OpenAI-compatible API, where both are top-level fields.
                    ...(spec.sampling && Object.keys(spec.sampling).length > 0 && { samplingParams: { ...spec.sampling } }),
                    // Some servers, Ollama Cloud among them, silently drop a developer-role message, and with it the system prompt.
                    // Others, LiteLLM in front of Claude among them, reject the OpenAI-only `store` field pi sends by default.
                    compat: { supportsDeveloperRole: false, supportsStore: false },
                },
            ],
            api: openAICompletionsApi(),
        }));
        const model = models.getModel('openai-compatible', spec.id);
        if (!model)
            throw new Error(`model ${spec.id} did not register`);
        return { model, streamFn: (m, context, o) => models.streamSimple(m, context, o), secrets: { [spec.apiKeyEnv]: key } };
    }
    const models = builtinModels();
    const model = models.getModel(spec.provider, spec.id);
    if (!model)
        throw new Error(`unknown model ${spec.provider}/${spec.id}`);
    const key = (await models.getAuth(model))?.auth.apiKey;
    return { model, streamFn: (m, context, o) => models.streamSimple(m, context, o), secrets: key ? { MODEL_API_KEY: key } : {} };
}
/** pi provider ids whose `gen_ai.provider.name` has a well-known value. Any other id is used as it is. */
const PROVIDER_NAMES = {
    'amazon-bedrock': 'aws.bedrock',
    anthropic: 'anthropic',
    google: 'gcp.gemini',
    'google-vertex': 'gcp.vertex_ai',
    openai: 'openai',
    azure: 'azure.ai.openai',
    deepseek: 'deepseek',
    xai: 'x_ai',
    groq: 'groq',
    mistral: 'mistral_ai',
};
/**
 * One `chat` span per model request, active while the request starts so the provider's own HTTP span nests under it,
 * and the request's duration and token metrics.
 */
function traced(streamFn, redact, conversation, captureContent, log) {
    return async (model, llmContext, options) => {
        const started = performance.now();
        const attributes = { 'gen_ai.operation.name': 'chat', 'gen_ai.provider.name': PROVIDER_NAMES[model.provider] ?? model.provider, 'gen_ai.request.model': model.id };
        const span = tracer.startSpan(`chat ${model.id}`, { kind: SpanKind.CLIENT, attributes: { ...attributes, ...conversation } });
        const measure = (measured) => instruments().duration.record((performance.now() - started) / 1000, measured);
        // A host's meter or a malformed message must not reach the run, and the span ends however the telemetry went.
        const finish = (write) => {
            try {
                write();
            }
            catch (error) {
                fail(span, thrownType(error), redact(messageOf(error)));
                log(logRecord('WARN', redact(`chat telemetry failed: ${messageOf(error)}`), {}, { span }));
            }
            finally {
                span.end();
            }
        };
        try {
            if (captureContent)
                span.setAttributes(inputContent(llmContext.messages, redact));
            const stream = await context.with(trace.setSpan(context.active(), span), () => streamFn(model, llmContext, options));
            void stream.result().then((message) => finish(() => {
                const usage = usageOf(message);
                const responseModel = message.responseModel ?? message.model;
                const response = { ...attributes, 'gen_ai.response.model': responseModel };
                span.setAttributes({ 'gen_ai.response.model': responseModel, 'gen_ai.response.finish_reasons': [message.stopReason], ...usageAttributes(usage) });
                if (captureContent)
                    span.setAttribute('gen_ai.output.messages', captured([{ role: 'assistant', parts: parts(message.content), finish_reason: FINISH_REASONS[message.stopReason] ?? message.stopReason }], redact));
                instruments().tokens.record(promptTokens(usage), { ...response, 'gen_ai.token.type': 'input' });
                instruments().tokens.record(usage.output, { ...response, 'gen_ai.token.type': 'output' });
                if (message.stopReason === 'error')
                    fail(span, 'model_error', redact(message.errorMessage ?? 'model request failed'));
                measure(message.stopReason === 'error' ? { ...response, 'error.type': 'model_error' } : response);
            }));
            return stream;
        }
        catch (error) {
            finish(() => {
                fail(span, thrownType(error), redact(messageOf(error)));
                measure({ ...attributes, 'error.type': thrownType(error) });
            });
            throw error;
        }
    };
}
/**
 * The v1.41.0 content attributes of a request. The leading system message is the system prompt, which providers send
 * apart from the history. Engine records never get here: `convertToLlm` drops them before the request.
 */
function inputContent(messages, redact) {
    const [first] = messages;
    const history = capturedHistory((first?.role === 'system' ? messages.slice(1) : messages).map(chatMessage), redact);
    return {
        ...(first?.role === 'system' && { 'gen_ai.system_instructions': captured(systemParts(first), redact) }),
        'gen_ai.input.messages': history.json,
        ...(history.omitted > 0 && { 'aigent.content.omitted_messages': history.omitted }),
    };
}
function chatMessage(message) {
    switch (message.role) {
        case 'system':
            return { role: 'system', parts: systemParts(message) };
        case 'user':
        case 'assistant':
            return { role: message.role, parts: parts(message.content) };
        case 'toolResult':
            return { role: 'tool', parts: [{ type: 'tool_call_response', id: message.toolCallId, response: parts(message.content) }] };
        default:
            return message;
    }
}
function systemParts(message) {
    const sections = Object.values(message.sections ?? {}).flatMap((text) => (text === null ? [] : [{ type: 'text', content: text }]));
    return [...parts(message.content), ...sections];
}
function parts(content) {
    if (typeof content === 'string')
        return [{ type: 'text', content }];
    return content.map((c) => {
        switch (c.type) {
            case 'text':
                return { type: 'text', content: c.text };
            case 'image':
                return { type: 'blob_omitted', modality: 'image', mime_type: c.mimeType, bytes: decodedBytes(c.data) };
            case 'thinking':
                return { type: 'reasoning', content: c.thinking };
            case 'toolCall':
                return { type: 'tool_call', id: c.id, name: c.name, arguments: c.arguments };
            default:
                return c;
        }
    });
}
/** pi stop reasons whose v1.41.0 `finish_reason` differs or is well-known. Any other passes through. */
const FINISH_REASONS = { stop: 'stop', length: 'length', toolUse: 'tool_call', error: 'error' };
const piValidate = (schema, args, name) => {
    try {
        const tool = { name, description: '', parameters: schema };
        const valid = validateToolArguments(tool, { type: 'toolCall', id: '', name, arguments: args });
        return { ok: true, args: valid };
    }
    catch (error) {
        return { ok: false, error: messageOf(error) };
    }
};
function toAgentResult(result) {
    return { content: result.content.map((c) => ({ ...c })), details: undefined, ...(result.isError ? { isError: true } : {}) };
}
/** The only reader of pi's usage shape. */
function usageOf({ usage }) {
    return { input: usage.input, output: usage.output, cacheRead: usage.cacheRead, cacheWrite: usage.cacheWrite };
}
function toTurn(message) {
    if (message.stopReason === 'aborted')
        return { kind: 'aborted' };
    if (message.stopReason === 'error')
        return { kind: 'error', message: message.errorMessage ?? 'model request failed' };
    return { kind: 'ok', text: message.content.flatMap((c) => (c.type === 'text' ? [c.text] : [])).join('') };
}
/** Resume boundary: the format tag and a role on every message. Records are parsed by the engine. */
function parseTranscript(transcript) {
    if (transcript?.format !== TRANSCRIPT_FORMAT || !Array.isArray(transcript.messages))
        throw new Error(`not an ${TRANSCRIPT_FORMAT} transcript`);
    const messages = transcript.messages.map((m, i) => {
        if (typeof m !== 'object' || m === null || Array.isArray(m) || typeof m.role !== 'string') {
            throw new Error(`transcript message ${i} has no role`);
        }
        return m;
    });
    return { messages, records: messages.flatMap((m) => (m.role === 'aigent' ? [m.record] : [])) };
}
/** Text fields only. Opaque provider fields such as thinking and text signatures pass through untouched. */
function exportMessage(message, redact) {
    const text = (c) => (c.type === 'text' ? { ...c, text: redact(c.text) } : c);
    switch (message.role) {
        case 'system':
            return {
                ...message,
                content: typeof message.content === 'string' ? redact(message.content) : message.content.map(text),
                ...(message.sections ? { sections: Object.fromEntries(Object.entries(message.sections).map(([k, v]) => [k, v === null ? v : redact(v)])) } : {}),
            };
        case 'user':
            return { ...message, content: typeof message.content === 'string' ? redact(message.content) : message.content.map(text) };
        case 'assistant':
            return {
                ...message,
                content: message.content.map((c) => c.type === 'text' ? text(c) : c.type === 'thinking' ? { ...c, thinking: redact(c.thinking) } : { ...c, arguments: redactJson(c.arguments, redact) }),
                ...(message.errorMessage ? { errorMessage: redact(message.errorMessage) } : {}),
            };
        case 'toolResult':
            return { ...message, content: message.content.map(text) };
        case 'aigent': {
            const { record } = message;
            switch (record.kind) {
                case 'denied':
                    return { ...message, record: { ...record, reason: redact(record.reason) } };
                case 'pending':
                    return { ...message, record: { ...record, text: redact(record.text) } };
                case 'call':
                    return record.outcome === 'unresolved' ? { ...message, record: { ...record, requested: redact(record.requested) } } : message;
                case 'conversation':
                case 'run':
                case 'enabled':
                case 'catalog':
                case 'delivered':
                case 'state':
                case 'usage':
                case 'skill':
                case 'delegation':
                    return message;
                default:
                    return record;
            }
        }
        default:
            return message;
    }
}
/** `type` and record `kind` are the engine's own constants, so keeping them whole reveals nothing of any secret. */
function redactEvent(event, redact) {
    switch (event.type) {
        case 'text':
        case 'tool_start':
        case 'tool_end':
        case 'progress':
        case 'turn_end':
            return { ...redactJson(event, redact), type: event.type };
        case 'record':
            return { type: 'record', record: { ...redactJson(event.record, redact), kind: event.record.kind } };
        case 'delegated':
        case 'delegation':
            return { ...event, callId: redact(event.callId), profile: redact(event.profile) };
        default:
            return event;
    }
}
/**
 * Redacting each delta alone lets a listener rejoin a secret split across deltas. Any secret that could still be
 * completing starts within the last `longest - 1` characters, so those wait for more text or the message's end.
 */
function holdBack(longest, redact, emit) {
    let held = '';
    return {
        push(delta) {
            held = redact(held + delta);
            let cut = held.length - Math.max(0, longest - 1);
            // Never strand half of a surrogate pair at the end of a delta.
            if (cut > 0 && /[\uD800-\uDBFF]/.test(held[cut - 1]))
                cut -= 1;
            if (cut <= 0)
                return;
            emit(held.slice(0, cut));
            held = held.slice(cut);
        },
        flush() {
            if (held)
                emit(held);
            held = '';
        },
    };
}
function messageOf(error) {
    return error instanceof Error ? error.message : String(error);
}
