# aigent

aigent is a small agent engine for Node. Its only extension point is the plugin, a named bundle of tools, skills and hooks that the model or the host enables mid-conversation. The agent loop and model access come from the pi agent SDK (`@earendil-works/pi-agent-core` and `pi-ai`), so a session runs on any of pi's built-in providers or on any OpenAI-compatible endpoint, including open-weight models on Ollama Cloud.

## Status

aigent is not released. `package.json` marks it `private` at version `0.0.0`, and no license is chosen yet. [#76](https://github.com/krimvp/aigents/issues/76) tracks the license. aigent runs on Node 22.19 or later.

A checkout runs the `.ts` files directly, and Node strips the types as it loads each file. Node refuses to strip types under `node_modules`, so another project installs a built tarball instead. To build it, run this in the checkout:

```bash
npm ci
npm run package
```

`npm run package` compiles `src/` to JavaScript and `.d.ts` files in `dist/`. It writes a `package.json` there that points `exports` and `bin` at the built files, then packs `dist/` into `aigent-0.0.0.tgz` at the repository root. The tarball holds that `package.json`, this README and the built `src/`, and nothing else.

There is no registry. Commit the tarball in the consumer's repository and install it by its path, which npm records as a `file:` dependency:

```bash
npm install ./vendor/aigent-0.0.0.tgz
```

To take a new build, replace the tarball and run that `npm install` again. The consumer's lockfile pins the tarball's hash, so `npm ci` alone either fails with `EINTEGRITY` or installs the old build from the npm cache.

The consumer's host and plugins can stay TypeScript, because Node strips types outside `node_modules`. They import `aigent` and `aigent/plugin` the same way as the example in the next section. To type-check them with `tsc`, set `skipLibCheck` to `true`, because the declarations of `@google/genai`, a dependency of pi-ai, fail a full check. `just-bash` is an optional peer dependency, so install it beside the tarball to use the `bash` tool mode. npm applies `overrides` only in the root project, so the `undici` override in aigent's `package.json` does not reach the consumer.

## Run an agent from a checkout

Install the dependencies:

```bash
npm ci
```

Inside the checkout, a file can import `aigent` and `aigent/plugin` by name. Create a plugin in `my-agent/plugins/weather.ts`:

```ts
import type { Plugin } from 'aigent/plugin'

export default {
	name: 'weather',
	description: 'Current weather lookups for any city.',
	instructions: 'Report temperatures in Celsius.',
	tools: [{
		name: 'get_weather',
		description: 'Current weather for a city.',
		parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'], additionalProperties: false },
		async execute({ city }) {
			return { content: [{ type: 'text', text: `${String(city)}: 21 C, clear` }] }
		},
	}],
} satisfies Plugin
```

A plugin imports `aigent/plugin` and nothing else from aigent. When `loadPlugins` imports a plugin, it refuses the plugin's imports of the rest of aigent and of other plugins. Create the host in `my-agent/host.ts`:

```ts
import { createSession, loadPlugins } from 'aigent'

const session = await createSession({
	model: { kind: 'openai-compatible', baseUrl: 'https://ollama.com/v1', id: 'gpt-oss:120b', apiKeyEnv: 'OLLAMA_API_KEY' },
	plugins: await loadPlugins(new URL('./plugins/', import.meta.url)),
	systemPrompt: 'You are a helpful agent. Enable a plugin when you need a capability you lack.',
})
session.subscribe((e) => { if (e.type === 'text') process.stdout.write(e.delta) })
const result = await session.prompt('Weather in Lisbon?', { signal: AbortSignal.timeout(60_000) })
console.log(`\n[${result.stop}]`)
await session.close()
```

Put `OLLAMA_API_KEY=<your key>` in `.env`, then run the host:

```bash
node --env-file=.env my-agent/host.ts
```

The system prompt lists the weather plugin in its catalog. The model enables it with `core__enable_plugin` and calls `weather__get_weather` through `core__call_tool`. When the model answers, the last line is `[done]`. `session.transcript()` returns JSON that you can store and pass back as `transcript` to resume. [The plugin engine design](docs/design/plugin-engine.md) covers hooks, gates, plugin state, secrets, delegation and tracing.

## Pick a tool mode

`toolMode` on `createSession` sets how the model reaches plugin tools. The default is `dispatch`. Gates, redaction and records are the same in every mode, because each call resolves to the real `<plugin>__<tool>` name before the gates run.

| Mode | The model gets | Limits and cost |
|---|---|---|
| `native` | Every enabled plugin's tools, declared with their real schemas. | Each enable changes the declared tool list, which costs one full prompt-cache miss. |
| `dispatch` | A fixed list: `core__enable_plugin`, `core__load_skill` and `core__call_tool { tool, args }`, plus the tools of plugins enabled at creation. Later plugins' schemas arrive in the enable text. | The declared list never changes, so the prompt cache survives enables. The engine validates `args` against the target schema and returns the schema with the error. |
| `programmatic` | The dispatch list with `core__run_code { code }` instead of `core__call_tool`. The code calls `await tools.<plugin>__<tool>(args)`. | The code runs in QuickJS compiled to WASM, on its own worker thread, with no network, modules, timers or `process`. Each run gets a fresh VM with 64 MiB of WASM memory and a 256 KiB stack. Output, the returned value and the error text are each cut at 65,536 characters in the worker. The model gets at most 8,000 characters. `codeTimeoutMs` (default 30,000) bounds the run, its tool calls included. A run makes at most `maxCodeCalls` tool calls (default 64), 8 at a time. |
| `bash` | The dispatch list with `core__run_bash { script }`. Each tool is a command that takes one JSON object argument. | The script runs in [just-bash](https://github.com/vercel-labs/just-bash), a simulated bash with an in-memory filesystem and no network. It runs in the host process, not a VM, so it is a weaker boundary than QuickJS. `just-bash` is an optional peer dependency. A host must install it, and without it `core__run_bash` returns an error result. `codeTimeoutMs` is its deadline, output is capped at 1 MiB, and the model gets at most 8,000 characters. The same `maxCodeCalls` cap applies. |

## Develop

`npm run check` runs `tsc --noEmit`, then every `test/**/*.test.ts` file with `node --test`. It makes no model calls and needs no model key.

```bash
npm ci
npm run check
node --test test/catalog.test.ts
```

The last command runs one test file. `npm run test:coverage` runs the suite with Node's coverage over `src/` and `integrations/`, prints a per-file table, and fails when line or branch coverage drops below the floor set in `package.json`.

`npm run test:package` builds the tarball, installs it in a new project outside the checkout, and uses it there. It type-checks a TypeScript host and plugin, runs the host against a local scripted model endpoint until the model has called the plugin's tool through the `programmatic` sandbox, and runs the `aigent` bin. It installs the dependencies with npm, so it needs the registry or a warm npm cache.

`AIGENT_LIVE=1 npm run test:live` runs every scenario live on Ollama Cloud, in `native` and `dispatch` mode, on gpt-oss:120b, glm-5.3 and kimi-k2.6 unless `AIGENT_LIVE_MODELS` lists others. Each trial is a paid model call. Without `AIGENT_LIVE=1` in the environment it refuses to start, even when a key is set, and `.env` cannot set it. It reads `OLLAMA_API_KEY` from the environment or from `.env`, and refuses to start without it.

CI runs these workflows from `.github/workflows/`:

- `ci.yml` runs `npm ci`, `npm run check` and `npm run test:package` on Node 22.19.x and 22.x, and once more on 22.x with `TRACEPARENT` set, on every pull request and every push to `main`. The 22.19.x leg also runs `npm run test:coverage`.
- `audit.yml` runs `npm audit --omit=dev` every Monday and when `package-lock.json` changes.
- `vendor-check.yml` runs `scripts/vendor-skills.sh --check` every Monday and on pull requests that touch `.agents/`, `third_party/` or the script.

The skills in `.agents/skills/` are vendored at the refs pinned in `.agents/skills.lock`. To check that the tree matches the pins, run this:

```bash
scripts/vendor-skills.sh --check
```

Agents that work in this repo follow [AGENTS.md](AGENTS.md).

## Run the evals

The eval scenarios in `test/scenarios/` are JSON files that drive a session through prompts, enables and resumes, then check the result. `aigent run` runs one scenario on an OpenAI-compatible model and writes a result directory. `aigent check` judges an existing one. Every name in the scenario's `secrets` must be set to a value of at least 8 characters, which the run treats as a canary that must never leak:

```bash
WEATHER_API_KEY=sk-canary-1234 npm run aigent -- run test/scenarios/weather.json --out runs/w1 --model gpt-oss:120b
npm run aigent -- check runs/w1
```

`npm run eval` runs every scenario through [multeval](integrations/multeval/README.md) across the subjects in `integrations/multeval/spec.json`, and fails unless every invariant held on every attempt. It needs `uv`, a model key as `OLLAMA_API_KEY` in `.env`, and SSH access to the krimvp/multeval repository, because `integrations/multeval/requirements.lock.txt` pins multeval with `git+ssh` URLs. The scenario judge uses the same key on Ollama Cloud unless `OPENAI_BASE_URL` and `OPENAI_API_KEY` are set.

```bash
npm run eval
```

## Read further

- [Plugin engine v1](docs/design/plugin-engine.md) is the engine design. It covers records, tool modes, hooks, redaction, delegation and tracing.
- [Eval scenarios and checks](docs/design/eval-scenarios.md) is the design of the scenario format, the CLI and the checks.
- [GLOSSARY.md](GLOSSARY.md) defines the terms both designs use.
- [SECURITY.md](SECURITY.md) says how to report a vulnerability and what counts as one.
- [AGENTS.md](AGENTS.md) is the guide for coding agents that work in this repo.
- [#79](https://github.com/krimvp/aigents/issues/79) tracks the November 2026 code and architecture review and its open work.
